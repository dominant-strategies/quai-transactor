import { WordlistOwlA } from './wordlist-owla.js';
/**
 * The [French wordlist](https://github.com/bitcoin/bips/blob/master/bip-0039/french.txt) for [mnemonic
 * phrases](https://en.bitcoin.it/wiki/BIP_0039).
 */
export declare class LangFr extends WordlistOwlA {
    /**
     * Creates a new instance of the French language Wordlist.
     *
     * This should be unnecessary most of the time as the exported {@link langFr} should suffice.
     *
     * @ignore
     */
    constructor();
    /**
     * Returns a singleton instance of a `LangFr`, creating it if this is the first time being called.
     */
    static wordlist(): LangFr;
}
//# sourceMappingURL=lang-fr.d.ts.map