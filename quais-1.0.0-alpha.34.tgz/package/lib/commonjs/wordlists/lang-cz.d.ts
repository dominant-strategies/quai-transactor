import { WordlistOwl } from './wordlist-owl.js';
/**
 * The [Czech wordlist](https://github.com/bitcoin/bips/blob/master/bip-0039/czech.txt) for [mnemonic
 * phrases](https://en.bitcoin.it/wiki/BIP_0039).
 */
export declare class LangCz extends WordlistOwl {
    /**
     * Creates a new instance of the Czech language Wordlist.
     *
     * Using the constructor should be unnecessary, instead use the {@link wordlist | **wordlist**} singleton method.
     *
     * @ignore
     */
    constructor();
    /**
     * Returns a singleton instance of a `LangCz`, creating it if this is the first time being called.
     */
    static wordlist(): LangCz;
}
//# sourceMappingURL=lang-cz.d.ts.map