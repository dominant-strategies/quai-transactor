import { WordlistOwl } from './wordlist-owl.js';
/**
 * The [Italian wordlist](https://github.com/bitcoin/bips/blob/master/bip-0039/italian.txt) for [mnemonic
 * phrases](https://en.bitcoin.it/wiki/BIP_0039).
 */
export declare class LangIt extends WordlistOwl {
    /**
     * Creates a new instance of the Italian language Wordlist.
     *
     * This should be unnecessary most of the time as the exported {@link langIt} should suffice.
     *
     * @ignore
     */
    constructor();
    /**
     * Returns a singleton instance of a `LangIt`, creating it if this is the first time being called.
     */
    static wordlist(): LangIt;
}
//# sourceMappingURL=lang-it.d.ts.map