import { WordlistOwl } from './wordlist-owl.js';
/**
 * The [Portuguese wordlist](https://github.com/bitcoin/bips/blob/master/bip-0039/portuguese.txt) for [mnemonic
 * phrases](https://en.bitcoin.it/wiki/BIP_0039).
 */
export declare class LangPt extends WordlistOwl {
    /**
     * Creates a new instance of the Portuguese language Wordlist.
     *
     * This should be unnecessary most of the time as the exported {@link langPt} should suffice.
     *
     * @ignore
     */
    constructor();
    /**
     * Returns a singleton instance of a `LangPt`, creating it if this is the first time being called.
     */
    static wordlist(): LangPt;
}
//# sourceMappingURL=lang-pt.d.ts.map