import { Wordlist } from './wordlist.js';
/**
 * The [Korean wordlist](https://github.com/bitcoin/bips/blob/master/bip-0039/korean.txt) for [mnemonic
 * phrases](https://en.bitcoin.it/wiki/BIP_0039).
 */
export declare class LangKo extends Wordlist {
    /**
     * Creates a new instance of the Korean language Wordlist.
     *
     * This should be unnecessary most of the time as the exported {@link langKo} should suffice.
     *
     * @ignore
     */
    constructor();
    getWord(index: number): string;
    getWordIndex(word: string): number;
    /**
     * Returns a singleton instance of a `LangKo`, creating it if this is the first time being called.
     */
    static wordlist(): LangKo;
}
//# sourceMappingURL=lang-ko.d.ts.map