import { Wordlist } from './wordlist.js';
/**
 * The [Tradional Chinese wordlist](https://github.com/bitcoin/bips/blob/master/bip-0039/chinese_traditional.txt) and
 * [Simplified Chinese wordlist](https://github.com/bitcoin/bips/blob/master/bip-0039/chinese_simplified.txt) for
 * [mnemonic phrases](https://en.bitcoin.it/wiki/BIP_0039)).
 */
export declare class LangZh extends Wordlist {
    /**
     * Creates a new instance of the Chinese language Wordlist for the `dialect`, either `"cn"` or `"tw"` for simplified
     * or traditional, respectively.
     *
     * This should be unnecessary most of the time as the exported langZhCn and langZhTw should suffice.
     *
     * @ignore
     */
    constructor(dialect: string);
    getWord(index: number): string;
    getWordIndex(word: string): number;
    split(phrase: string): Array<string>;
    /**
     * Returns a singleton instance of a `LangZh` for `dialect`, creating it if this is the first time being called.
     *
     * Use the `dialect` `"cn"` or `"tw"` for simplified or traditional, respectively.
     */
    static wordlist(dialect: string): LangZh;
}
//# sourceMappingURL=lang-zh.d.ts.map