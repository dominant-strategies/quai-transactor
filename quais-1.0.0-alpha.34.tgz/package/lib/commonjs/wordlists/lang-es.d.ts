import { WordlistOwlA } from './wordlist-owla.js';
/**
 * The [Spanish wordlist](https://github.com/bitcoin/bips/blob/master/bip-0039/spanish.txt) for [mnemonic
 * phrases](https://en.bitcoin.it/wiki/BIP_0039).
 *
 * @category Wordlists
 */
export declare class LangEs extends WordlistOwlA {
    /**
     * Creates a new instance of the Spanish language Wordlist.
     *
     * This should be unnecessary most of the time as the exported {@link langEs} should suffice.
     *
     * @ignore
     */
    constructor();
    /**
     * Returns a singleton instance of a `LangEs`, creating it if this is the first time being called.
     */
    static wordlist(): LangEs;
}
//# sourceMappingURL=lang-es.d.ts.map