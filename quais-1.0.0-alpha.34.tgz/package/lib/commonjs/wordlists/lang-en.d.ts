import { WordlistOwl } from './wordlist-owl.js';
/**
 * The [English wordlist](https://github.com/bitcoin/bips/blob/master/bip-0039/english.txt) for [mnemonic
 * phrases](https://en.bitcoin.it/wiki/BIP_0039).
 *
 * @category Wordlists
 */
export declare class LangEn extends WordlistOwl {
    /**
     * Creates a new instance of the English language Wordlist.
     *
     * This should be unnecessary most of the time as the exported {@link langEn} should suffice.
     *
     * @ignore
     */
    constructor();
    /**
     * Returns a singleton instance of a `LangEn`, creating it if this is the first time being called.
     */
    static wordlist(): LangEn;
}
//# sourceMappingURL=lang-en.d.ts.map