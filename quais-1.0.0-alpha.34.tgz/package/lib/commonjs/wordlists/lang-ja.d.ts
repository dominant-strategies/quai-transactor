import { Wordlist } from './wordlist.js';
/**
 * The [Japanese wordlist](https://github.com/bitcoin/bips/blob/master/bip-0039/japanese.txt) for [mnemonic
 * phrases](https://en.bitcoin.it/wiki/BIP_0039).
 */
export declare class LangJa extends Wordlist {
    /**
     * Creates a new instance of the Japanese language Wordlist.
     *
     * This should be unnecessary most of the time as the exported {@link langJa} should suffice.
     *
     * @ignore
     */
    constructor();
    getWord(index: number): string;
    getWordIndex(word: string): number;
    split(phrase: string): Array<string>;
    join(words: Array<string>): string;
    /**
     * Returns a singleton instance of a `LangJa`, creating it if this is the first time being called.
     */
    static wordlist(): LangJa;
}
//# sourceMappingURL=lang-ja.d.ts.map