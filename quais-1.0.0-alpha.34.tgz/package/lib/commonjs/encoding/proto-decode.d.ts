import { ProtoTransaction } from '../transaction/abstract-transaction.js';
import { ProtoWorkObject } from '../transaction/work-object.js';
/**
 * @category Encoding
 * @param {Uint8Array} bytes - The Protobuf encoded transaction
 * @returns {ProtoTransaction} - The decoded transaction
 */
export declare function decodeProtoTransaction(bytes: Uint8Array): ProtoTransaction;
/**
 * @category Encoding
 * @param {Uint8Array} bytes - The Protobuf encoded work object
 * @returns {ProtoWorkObject} - The decoded work object
 */
export declare function decodeProtoWorkObject(bytes: Uint8Array): ProtoWorkObject;
//# sourceMappingURL=proto-decode.d.ts.map