import { ProtoTransaction } from '../transaction/abstract-transaction.js';
import { ProtoWorkObject } from '../transaction/work-object.js';
/**
 * @category Encoding
 * @param {ProtoTransaction} protoTx - The signed constructed transaction
 * @returns {string} - The Protobuf encoded transaction
 */
export declare function encodeProtoTransaction(protoTx: ProtoTransaction): string;
/**
 * @category Encoding
 * @param {ProtoWorkObject} protoWo - The constructed WorkObject
 * @returns {string} - The Protobuf encoded WorkObject
 */
export declare function encodeProtoWorkObject(protoWo: ProtoWorkObject): string;
//# sourceMappingURL=proto-encode.d.ts.map