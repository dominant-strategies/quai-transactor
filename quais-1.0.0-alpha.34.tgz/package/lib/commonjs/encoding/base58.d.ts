/**
 * The [Base58 Encoding](https://en.bitcoinwiki.org/wiki/Base58) scheme allows a **numeric** value to be encoded as a
 * compact string using a radix of 58 using only alpha-numeric characters. Confusingly similar characters are omitted
 * (i.e. `"l0O"`).
 *
 * Note that Base58 encodes a **numeric** value, not arbitrary bytes, since any zero-bytes on the left would get
 * removed. To mitigate this issue most schemes that use Base58 choose specific high-order values to ensure non-zero
 * prefixes.
 */
import type { BytesLike } from '../utils/index.js';
/**
 * Encode `value` as a Base58-encoded string.
 *
 * @category Encoding
 * @param {BytesLike} _value - The value to encode.
 * @returns {string} The Base58-encoded string.
 */
export declare function encodeBase58(_value: BytesLike): string;
/**
 * Decode the Base58-encoded `value`.
 *
 * @category Encoding
 * @param {string} value - The Base58-encoded value.
 * @returns {bigint} The decoded value.
 */
export declare function decodeBase58(value: string): bigint;
//# sourceMappingURL=base58.d.ts.map