/**
 * Provides utility functions for encoding and decoding strings in the Bytes32 format.
 *
 * @category Application Binary Interface
 */
import type { BytesLike } from '../utils/index.js';
/**
 * Encodes a string as a Bytes32 string. This is used to encode ABI data.
 *
 * @category Encoding
 * @param {string} text - The string to encode.
 * @returns {string} The Bytes32-encoded string.
 * @throws {Error} If the string is too long to fit in a Bytes32 format.
 */
export declare function encodeBytes32(text: string): string;
/**
 * Decodes a Bytes32-encoded string into a regular string. This is used to decode ABI-encoded data.
 *
 * @category Encoding
 * @param {BytesLike} _bytes - The Bytes32-encoded data.
 * @returns {string} The decoded string.
 * @throws {Error} If the input is not exactly 32 bytes long or lacks a null terminator.
 */
export declare function decodeBytes32(_bytes: BytesLike): string;
//# sourceMappingURL=bytes32.d.ts.map