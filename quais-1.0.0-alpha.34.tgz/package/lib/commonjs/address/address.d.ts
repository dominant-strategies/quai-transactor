import { SigningKey } from '../crypto/index.js';
import { BytesLike, BigNumberish } from '../utils/index.js';
import type { SignatureLike } from '../crypto/index.js';
export declare function formatMixedCaseChecksumAddress(address: string): string;
/**
 * Returns a normalized and checksumed address for `address`. This accepts non-checksum addressesa and checksum
 * addresses.
 *
 * The checksum in Quai uses the capitalization (upper-case vs lower-case) of the characters within an address to encode
 * its checksum, which offers, on average, a checksum of 15-bits.
 *
 * If `address` contains both upper-case and lower-case, it is assumed to already be a checksum address and its checksum
 * is validated, and if the address fails its expected checksum an error is thrown.
 *
 * If you wish the checksum of `address` to be ignore, it should be converted to lower-case (i.e. `.toLowercase()`)
 * before being passed in. This should be a very rare situation though, that you wish to bypass the safeguards in place
 * to protect against an address that has been incorrectly copied from another source.
 *
 * @category Address
 * @example
 *
 * ```js
 * // Adds the checksum (via upper-casing specific letters)
 * getAddress('0x8ba1f109551bd432803012645ac136ddd64dba72');
 *
 * // Throws an error if an address contains mixed case,
 * // but the checksum fails
 * getAddress('0x8Ba1f109551bD432803012645Ac136ddd64DBA72');
 * ```
 */
export declare function getAddress(address: string): string;
export declare function getContractAddress(from: string, nonce: BigNumberish, data: BytesLike): string;
/**
 * Returns the address for the `key`.
 *
 * The key may be any standard form of public key or a private key.
 *
 * @category Address
 * @param {string | SigningKey} key - The key to compute the address for.
 * @returns {string} The address.
 */
export declare function computeAddress(key: string | SigningKey): string;
/**
 * Returns the recovered address for the private key that was used to sign `digest` that resulted in `signature`.
 *
 * @category Address
 * @param {BytesLike} digest - The digest of the message.
 * @param {SignatureLike} signature - The signature.
 * @returns {string} The address.
 */
export declare function recoverAddress(digest: BytesLike, signature: SignatureLike): string;
//# sourceMappingURL=address.d.ts.map