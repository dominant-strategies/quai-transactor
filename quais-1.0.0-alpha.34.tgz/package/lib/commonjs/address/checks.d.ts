import type { Addressable, AddressLike } from './index.js';
/**
 * Returns true if `value` is an object which implements the [**Addressable**](../interfaces/Addressable) interface.
 *
 * @category Address
 * @example
 *
 * ```js
 * // Wallets and AbstractSigner sub-classes
 * isAddressable(Wallet.createRandom());
 *
 * // Contracts
 * contract = new Contract('0x643aA0A61eADCC9Cc202D1915D942d35D005400C', [], provider);
 * isAddressable(contract);
 * ```
 *
 * @param {any} value - The value to check.
 * @returns {boolean} True if the value is an Addressable.
 */
export declare function isAddressable(value: any): value is Addressable;
/**
 * Returns true if `value` is a valid address.
 *
 * @category Address
 * @example
 *
 * ```js
 * // Valid address
 * isAddress('0x8ba1f109551bD432803012645Ac136ddd64DBA72');
 *
 * // Invalid checksum
 * isAddress('0x8Ba1f109551bD432803012645Ac136ddd64DBa72');
 * ```
 *
 * @param {any} value - The value to check.
 * @returns {boolean} True if the value is a valid address.
 */
export declare function isAddress(value: any): value is string;
/**
 * Resolves to an address for the `target`, which may be any supported address type, an
 * [**Addressable**](../interfaces/Addressable) or a Promise which resolves to an address.
 *
 * @category Address
 * @example
 *
 * ```js
 * addr = '0x6B175474E89094C44Da98b954EedeAC495271d0F';
 *
 * // Addresses are return synchronously
 * resolveAddress(addr, provider);
 *
 * // Address promises are resolved asynchronously
 * resolveAddress(Promise.resolve(addr));
 *
 * // Addressable objects are resolved asynchronously
 * contract = new Contract(addr, []);
 * resolveAddress(contract, provider);
 * ```
 *
 * @param {AddressLike} target - The target to resolve to an address.
 * @returns {string | Promise<string>} The resolved address.
 */
export declare function resolveAddress(target: AddressLike): string | Promise<string>;
/**
 * Checks if the address is a valid mixed case checksummed address.
 *
 * @category Address
 * @param address - The address to validate.
 * @returns True if the address is a valid mixed case checksummed address.
 */
export declare function validateAddress(address: string): void;
/**
 * Checks whether a given address is in the Qi ledger scope by checking the 9th bit of the address.
 *
 * @category Address
 * @param {string} address - The address to check
 * @returns {boolean} True if the address is in the Qi ledger scope, false otherwise.
 */
export declare function isQiAddress(address: string): boolean;
/**
 * Checks whether a given address is in the Quai ledger scope by checking the 9th bit of the address.
 *
 * @category Address
 * @param {string} address - The address to check
 * @returns {boolean} True if the address is in the Quai ledger scope, false otherwise.
 */
export declare function isQuaiAddress(address: string): boolean;
//# sourceMappingURL=checks.d.ts.map