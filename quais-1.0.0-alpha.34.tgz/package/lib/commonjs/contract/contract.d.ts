import { Interface } from '../abi/index.js';
import { Log, QuaiTransactionResponse } from '../providers/provider.js';
import { ContractTransactionResponse, EventLog } from './wrappers.js';
import type { EventFragment, FunctionFragment, InterfaceAbi, ParamType } from '../abi/index.js';
import type { Addressable } from '../address/index.js';
import type { EventEmitterable, Listener } from '../utils/index.js';
import type { BlockTag } from '../providers/index.js';
import type { ContractEventName, ContractInterface, ContractMethod, ContractEvent, ContractTransaction, ContractRunner, WrappedFallback } from './types.js';
/**
 * @ignore Copy Overrides and validate them.
 * @param {any} arg - The argument containing overrides.
 * @param {string[]} [allowed] - The allowed override keys.
 * @returns {Promise<Omit<ContractTransaction, O>>} The copied and validated overrides.
 * @throws {Error} If the overrides are invalid.
 */
export declare function copyOverrides<O extends string = 'data' | 'to'>(arg: any, allowed?: Array<string>): Promise<Omit<ContractTransaction, O>>;
/**
 * @ignore Resolve Arguments for a contract runner.
 * @param {null | ContractRunner} _runner - The contract runner.
 * @param {ReadonlyArray<ParamType>} inputs - The input parameter types.
 * @param {any[]} args - The arguments to resolve.
 * @returns {Promise<any[]>} The resolved arguments.
 */
export declare function resolveArgs(_runner: null | ContractRunner, inputs: ReadonlyArray<ParamType>, args: Array<any>): Promise<Array<any>>;
declare const internal: unique symbol;
/**
 * Creates a new contract connected to target with the abi and optionally connected to a runner to perform operations on
 * behalf of.
 *
 * @category Contract
 */
export declare class BaseContract implements Addressable, EventEmitterable<ContractEventName> {
    /**
     * The target to connect to.
     *
     * This can be an address or any [Addressable](../interfaces/Addressable), such as another contract. To get the
     * resolved address, use the `getAddress` method.
     */
    readonly target: string | Addressable;
    /**
     * The contract Interface.
     */
    readonly interface: Interface;
    /**
     * The connected runner. This is generally a [**Provider**](../interfaces/Provider) or a
     * [**Signer**](../interfaces/Signer), which dictates what operations are supported.
     *
     * For example, a **Contract** connected to a [**Provider**](../interfaces/Provider) may only execute read-only
     * operations.
     */
    readonly runner: null | ContractRunner;
    /**
     * All the Events available on this contract.
     */
    readonly filters: Record<string, ContractEvent>;
    /**
     * @ignore
     */
    readonly [internal]: any;
    /**
     * The fallback or receive function if any.
     */
    readonly fallback: null | WrappedFallback;
    /**
     * Creates a new contract connected to `target` with the `abi` and optionally connected to a `runner` to perform
     * operations on behalf of.
     *
     * @ignore
     */
    constructor(target: string | Addressable, abi: Interface | InterfaceAbi, runner?: null | ContractRunner, _deployTx?: null | QuaiTransactionResponse);
    /**
     * Return a new Contract instance with the same target and ABI, but a different `runner`.
     *
     * @param {null | ContractRunner} runner - The runner to use.
     * @returns {BaseContract} The new contract instance.
     */
    connect(runner: null | ContractRunner): BaseContract;
    /**
     * Return a new Contract instance with the same ABI and runner, but a different `target`.
     *
     * @param {string | Addressable} target - The target to connect to.
     * @returns {BaseContract} The new contract instance.
     */
    attach(target: string | Addressable): BaseContract;
    /**
     * Return the resolved address of this Contract.
     *
     * @returns {Promise<string>} The resolved address.
     */
    getAddress(): Promise<string>;
    /**
     * Return the deployed bytecode or null if no bytecode is found.
     *
     * @returns {Promise<null | string>} The deployed bytecode or null.
     * @throws {Error} If the runner does not support .provider.
     */
    getDeployedCode(): Promise<null | string>;
    /**
     * Resolve to this Contract once the bytecode has been deployed, or resolve immediately if already deployed.
     *
     * @returns {Promise<this>} The contract instance.
     * @throws {Error} If the contract runner does not support .provider.
     */
    waitForDeployment(): Promise<this>;
    /**
     * Return the transaction used to deploy this contract.
     *
     * This is only available if this instance was returned from a [**ContractFactor**](../classes/ContractFactory).
     *
     * @returns The transaction used to deploy this contract or `null`.
     */
    deploymentTransaction(): null | ContractTransactionResponse;
    /**
     * Return the function for a given name. This is useful when a contract method name conflicts with a JavaScript name
     * such as `prototype` or when using a Contract programatically.
     *
     * @param {string | FunctionFragment} key - The name of the function to return.
     * @returns The function for the given name.
     */
    getFunction<T extends ContractMethod = ContractMethod>(key: string | FunctionFragment): T;
    /**
     * Return the event for a given name. This is useful when a contract event name conflicts with a JavaScript name
     * such as `prototype` or when using a Contract programatically.
     *
     * @param {string | EventFragment} key - The name of the event to return.
     * @returns The event for the given name.
     */
    getEvent(key: string | EventFragment): ContractEvent;
    /**
     * @ignore
     */
    queryTransaction(hash: string): Promise<Array<EventLog>>;
    /**
     * Provide historic access to event data for `event` in the range `fromBlock` (default: `0`) to `toBlock` (default:
     * `"latest"`) inclusive.
     *
     * @param {Zone} zone - The zone to query.
     * @param {ContractEventName} event - The event to query.
     * @param {BlockTag} fromBlock - The block to start querying from.
     * @param {BlockTag} toBlock - The block to stop querying at.
     * @returns An array of event logs.
     */
    queryFilter(event: ContractEventName, fromBlock?: BlockTag, toBlock?: BlockTag): Promise<Array<EventLog | Log>>;
    /**
     * Add an event `listener` for the `event`.
     *
     * @param {ContractEventName} event - The event to listen for.
     * @param {Listener} listener - The listener to call when the event is emitted.
     * @returns This contract instance.
     */
    on(event: ContractEventName, listener: Listener): Promise<this>;
    /**
     * Add an event `listener` for the `event`, but remove the listener after it is fired once.
     *
     * @param {ContractEventName} event - The event to listen for.
     * @param {Listener} listener - The listener to call when the event is emitted.
     */
    once(event: ContractEventName, listener: Listener): Promise<this>;
    /**
     * Emit an `event` calling all listeners with `args`.
     *
     * Resolves to `true` if any listeners were called.
     *
     * @param {ContractEventName} event - The event to emit.
     * @param {any[]} args - The arguments to pass to the listeners.
     * @returns `true` if any listeners were called.
     */
    emit(event: ContractEventName, ...args: Array<any>): Promise<boolean>;
    /**
     * Resolves to the number of listeners of `event` or the total number of listeners if unspecified.
     *
     * @param {ContractEventName} event - The event to count listeners for.
     * @returns {number} The number of listeners.
     */
    listenerCount(event?: ContractEventName): Promise<number>;
    /**
     * Resolves to the listeners subscribed to `event` or all listeners if unspecified.
     *
     * @param {ContractEventName} event - The event to get listeners for.
     * @returns {Listener[]} The listeners.
     */
    listeners(event?: ContractEventName): Promise<Array<Listener>>;
    /**
     * Remove the `listener` from the listeners for `event` or remove all listeners if unspecified.
     *
     * @param {ContractEventName} event - The event to remove the listener from.
     * @param {Listener} listener - The listener to remove.
     * @returns This contract instance.
     */
    off(event: ContractEventName, listener?: Listener): Promise<this>;
    /**
     * Remove all the listeners for `event` or remove all listeners if unspecified.
     *
     * @param {ContractEventName} event - The event to remove the listeners from.
     * @returns This contract instance.
     */
    removeAllListeners(event?: ContractEventName): Promise<this>;
    /**
     * Alias for {@link BaseContract.on | **on**}.
     *
     * @param {ContractEventName} event - The event to listen for.
     * @param {Listener} listener - The listener to call when the event is emitted.
     */
    addListener(event: ContractEventName, listener: Listener): Promise<this>;
    /**
     * Alias for {@link BaseContract.off | **off**}.
     *
     * @param {ContractEventName} event - The event to remove the listener from.
     * @param {Listener} listener - The listener to remove.
     */
    removeListener(event: ContractEventName, listener: Listener): Promise<this>;
    /**
     * Create a new Class for the `abi`.
     *
     * @param {Interface | InterfaceAbi} abi - The ABI to create the class from.
     * @returns The new Class for the ABI.
     */
    static buildClass<T = ContractInterface>(abi: Interface | InterfaceAbi): new (target: string, runner?: null | ContractRunner) => BaseContract & Omit<T, keyof BaseContract>;
    /**
     * Create a new BaseContract with a specified Interface.
     *
     * @param {string} target - The target to connect to.
     * @param {Interface | InterfaceAbi} abi - The ABI to use.
     * @param {null | ContractRunner} runner - The runner to use.
     * @returns The new BaseContract.
     */
    static from<T = ContractInterface>(target: string, abi: Interface | InterfaceAbi, runner?: null | ContractRunner): BaseContract & Omit<T, keyof BaseContract>;
}
declare const Contract_base: new (target: string, abi: Interface | InterfaceAbi, runner?: ContractRunner | null | undefined) => BaseContract & Omit<ContractInterface, keyof BaseContract>;
/**
 * A {@link BaseContract | **BaseContract**} with no type guards on its methods or events.
 *
 * @category Contract
 */
export declare class Contract extends Contract_base {
}
export {};
//# sourceMappingURL=contract.d.ts.map