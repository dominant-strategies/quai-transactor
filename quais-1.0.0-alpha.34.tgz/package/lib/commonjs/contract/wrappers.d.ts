import { Block, Log, QuaiTransactionResponse, TransactionReceipt, TransactionResponse } from '../providers/provider.js';
import { EventPayload } from '../utils/index.js';
import type { EventFragment, Interface, Result } from '../abi/index.js';
import type { Listener } from '../utils/index.js';
import type { Provider } from '../providers/index.js';
import type { BaseContract } from './contract.js';
import type { ContractEventName } from './types.js';
import { Shard } from '../constants/index.js';
/**
 * An **EventLog** contains additional properties parsed from the {@link Log | **Log**}.
 *
 * @category Contract
 */
export declare class EventLog extends Log {
    /**
     * The Contract Interface.
     */
    readonly interface: Interface;
    /**
     * The matching event.
     */
    readonly fragment: EventFragment;
    /**
     * The parsed arguments passed to the event by `emit`.
     */
    readonly args: Result;
    /**
     * @ignore
     */
    constructor(log: Log, iface: Interface, fragment: EventFragment);
    /**
     * The name of the event.
     */
    get eventName(): string;
    /**
     * The signature of the event.
     */
    get eventSignature(): string;
}
/**
 * An **EventLog** contains additional properties parsed from the {@link Log | **Log**}.
 *
 * @category Contract
 */
export declare class UndecodedEventLog extends Log {
    /**
     * The error encounted when trying to decode the log.
     */
    readonly error: Error;
    /**
     * @ignore
     */
    constructor(log: Log, error: Error);
}
/**
 * A **ContractTransactionReceipt** includes the parsed logs from a {@link TransactionReceipt | **TransactionReceipt**}.
 *
 * @category Contract
 */
export declare class ContractTransactionReceipt extends TransactionReceipt {
    #private;
    /**
     * @ignore
     */
    constructor(iface: Interface, provider: Provider, tx: TransactionReceipt);
    /**
     * The parsed logs for any {@link Log | **Log**} which has a matching event in the Contract ABI.
     */
    get logs(): Array<EventLog | Log>;
}
/**
 * A **ContractTransactionResponse** will return a {@link ContractTransactionReceipt | **ContractTransactionReceipt**}
 * when waited on.
 *
 * @category Contract
 */
export declare class ContractTransactionResponse extends QuaiTransactionResponse {
    #private;
    /**
     * @ignore
     */
    constructor(iface: Interface, provider: Provider, tx: QuaiTransactionResponse);
    /**
     * Resolves once this transaction has been mined and has `confirms` blocks including it (default: `1`) with an
     * optional `timeout`.
     *
     * This can resolve to `null` only if `confirms` is `0` and the transaction has not been mined, otherwise this will
     * wait until enough confirmations have completed.
     *
     * @param {number} confirms - The number of confirmations to wait for.
     * @returns {Promise<ContractTransactionReceipt | null>} The transaction receipt, or `null` if `confirms` is `0`.
     */
    wait(confirms?: number): Promise<null | ContractTransactionReceipt>;
}
/**
 * A **ContractUnknownEventPayload** is included as the last parameter to Contract Events when the event does not match
 * any events in the ABI.
 *
 * @category Contract
 */
export declare class ContractUnknownEventPayload extends EventPayload<ContractEventName> {
    /**
     * The log with no matching events.
     */
    readonly log: Log;
    /**
     * @ignore
     */
    constructor(contract: BaseContract, listener: null | Listener, filter: ContractEventName, log: Log);
    /**
     * Resolves to the block the event occured in.
     *
     * @param {Shard} shard - The shard to get the block from.
     * @returns {Promise<Block>} A promise resolving to the block the event occured in.
     */
    getBlock(shard: Shard): Promise<Block>;
    /**
     * Resolves to the transaction the event occured in.
     *
     * @returns {Promise<TransactionResponse>} A promise resolving to the transaction the event occured in.
     */
    getTransaction(): Promise<TransactionResponse>;
    /**
     * Resolves to the transaction receipt the event occured in.
     *
     * @returns {Promise<TransactionReceipt>} A promise resolving to the transaction receipt the event occured in.
     */
    getTransactionReceipt(): Promise<TransactionReceipt>;
}
/**
 * A **ContractEventPayload** is included as the last parameter to Contract Events when the event is known.
 *
 * @category Contract
 */
export declare class ContractEventPayload extends ContractUnknownEventPayload {
    /**
     * The matching event.
     */
    readonly fragment: EventFragment;
    /**
     * The log, with parsed properties.
     */
    readonly log: EventLog;
    /**
     * The parsed arguments passed to the event by `emit`.
     */
    readonly args: Result;
    /**
     * @ignore
     */
    constructor(contract: BaseContract, listener: null | Listener, filter: ContractEventName, fragment: EventFragment, _log: Log);
    /**
     * The event name.
     */
    get eventName(): string;
    /**
     * The event signature.
     */
    get eventSignature(): string;
}
//# sourceMappingURL=wrappers.d.ts.map