import type { SignatureLike } from '../crypto/index.js';
import type { BigNumberish, BytesLike } from '../utils/index.js';
/**
 * The domain for an [EIP-712](https://eips.ethereum.org/EIPS/eip-712) payload.
 *
 * @category Hash
 */
export interface TypedDataDomain {
    /**
     * The human-readable name of the signing domain.
     */
    name?: null | string;
    /**
     * The major version of the signing domain.
     */
    version?: null | string;
    /**
     * The chain ID of the signing domain.
     */
    chainId?: null | BigNumberish;
    /**
     * The the address of the contract that will verify the signature.
     */
    verifyingContract?: null | string;
    /**
     * A salt used for purposes decided by the specific domain.
     */
    salt?: null | BytesLike;
}
/**
 * A specific field of a structured [EIP-712](https://eips.ethereum.org/EIPS/eip-712) type.
 *
 * @category Hash
 */
export interface TypedDataField {
    /**
     * The field name.
     */
    name: string;
    /**
     * The type of the field.
     */
    type: string;
}
/**
 * A **TypedDataEncode** prepares and encodes [EIP-712](https://eips.ethereum.org/EIPS/eip-712) payloads for signed
 * typed data.
 *
 * This is useful for those that wish to compute various components of a typed data hash, primary types, or
 * sub-components, but generally the higher level [`Signer.signTypedData`](../classes/Signer#signTypedData) is more
 * useful.
 *
 * @category Hash
 */
export declare class TypedDataEncoder {
    #private;
    /**
     * The primary type for the structured {@link types | **types**}.
     *
     * This is derived automatically from the {@link types | **types**}, since no recursion is possible, once the DAG for
     * the types is consturcted internally, the primary type must be the only remaining type with no parent nodes.
     */
    readonly primaryType: string;
    /**
     * The types.
     */
    get types(): Record<string, Array<TypedDataField>>;
    /**
     * Create a new **TypedDataEncoder** for `types`.
     *
     * This performs all necessary checking that types are valid and do not violate the
     * [EIP-712](https://eips.ethereum.org/EIPS/eip-712) structural constraints as well as computes the
     * {@link primaryType | **primaryType**}.
     */
    constructor(types: Record<string, Array<TypedDataField>>);
    /**
     * Returnthe encoder for the specific `type`.
     *
     * @param {string} type - The type to get the encoder for.
     * @returns {(value: any) => string} The encoder for the type.
     */
    getEncoder(type: string): (value: any) => string;
    /**
     * Return the full type for `name`.
     *
     * @param {string} name - The name to get the full type for.
     * @returns {string} The full type.
     */
    encodeType(name: string): string;
    /**
     * Return the encoded `value` for the `type`.
     *
     * @param {string} type - The type to encode the value for.
     * @param {any} value - The value to encode.
     * @returns {string} The encoded value.
     */
    encodeData(type: string, value: any): string;
    /**
     * Returns the hash of `value` for the type of `name`.
     *
     * @param {string} name - The name of the type.
     * @param {Record<string, any>} value - The value to hash.
     * @returns {string} The hash of the value.
     */
    hashStruct(name: string, value: Record<string, any>): string;
    /**
     * Return the fulled encoded `value` for the {@link types | **types**}.
     *
     * @param {Record<string, any>} value - The value to encode.
     * @returns {string} The encoded value.
     */
    encode(value: Record<string, any>): string;
    /**
     * Return the hash of the fully encoded `value` for the {@link types | **types**}.
     *
     * @param {Record<string, any>} value - The value to hash.
     * @returns {string} The hash of the value.
     */
    hash(value: Record<string, any>): string;
    /**
     * @ignore
     */
    _visit(type: string, value: any, callback: (type: string, data: any) => any): any;
    /**
     * Call `calback` for each value in `value`, passing the type and component within `value`.
     *
     * This is useful for replacing addresses or other transformation that may be desired on each component, based on
     * its type.
     *
     * @param {Record<string, any>} value - The value to visit.
     * @param {(type: string, data: any) => any} callback - The callback to call for each value.
     * @returns {any} The result of the callback.
     */
    visit(value: Record<string, any>, callback: (type: string, data: any) => any): any;
    /**
     * Create a new **TypedDataEncoder** for `types`.
     *
     * @param {Record<string, TypedDataField[]>} types - The types to encode.
     * @returns {TypedDataEncoder} The encoder for the types.
     * @throws {Error} If the types are invalid.
     */
    static from(types: Record<string, Array<TypedDataField>>): TypedDataEncoder;
    /**
     * Return the primary type for `types`.
     *
     * @param {Record<string, TypedDataField[]>} types - The types to get the primary type for.
     * @returns {string} The primary type.
     * @throws {Error} If the types are invalid.
     */
    static getPrimaryType(types: Record<string, Array<TypedDataField>>): string;
    /**
     * Return the hashed struct for `value` using `types` and `name`.
     *
     * @param {string} name - The name of the type.
     * @param {Record<string, TypedDataField[]>} types - The types to hash.
     * @param {Record<string, any>} value - The value to hash.
     * @returns {string} The hash of the value.
     */
    static hashStruct(name: string, types: Record<string, Array<TypedDataField>>, value: Record<string, any>): string;
    /**
     * Return the domain hash for `domain`.
     *
     * @param {TypedDataDomain} domain - The domain to hash.
     * @returns {string} The hash of the domain.
     * @throws {Error} If the domain is invalid.
     */
    static hashDomain(domain: TypedDataDomain): string;
    /**
     * Return the fully encoded [EIP-712](https://eips.ethereum.org/EIPS/eip-712) `value` for `types` with `domain`.
     *
     * @param {TypedDataDomain} domain - The domain to use.
     * @param {Record<string, TypedDataField[]>} types - The types to encode.
     * @param {Record<string, any>} value - The value to encode.
     * @returns {string} The encoded value.
     */
    static encode(domain: TypedDataDomain, types: Record<string, Array<TypedDataField>>, value: Record<string, any>): string;
    /**
     * Return the hash of the fully encoded [EIP-712](https://eips.ethereum.org/EIPS/eip-712) `value` for `types` with
     * `domain`.
     *
     * @param {TypedDataDomain} domain - The domain to use.
     * @param {Record<string, TypedDataField[]>} types - The types to hash.
     * @param {Record<string, any>} value - The value to hash.
     * @returns {string} The hash of the value.
     */
    static hash(domain: TypedDataDomain, types: Record<string, Array<TypedDataField>>, value: Record<string, any>): string;
    /**
     * Returns the JSON-encoded payload expected by nodes which implement the JSON-RPC
     * [EIP-712](https://eips.ethereum.org/EIPS/eip-712) method.
     *
     * @param {TypedDataDomain} domain - The domain to use.
     * @param {Record<string, TypedDataField[]>} types - The types to encode.
     * @param {Record<string, any>} value - The value to encode.
     * @returns {any} The JSON-encoded payload.
     */
    static getPayload(domain: TypedDataDomain, types: Record<string, Array<TypedDataField>>, value: Record<string, any>): any;
}
/**
 * Compute the address used to sign the typed data for the `signature`.
 *
 * @category Hash
 * @param {TypedDataDomain} domain - The domain of the typed data.
 * @param {Record<string, TypedDataField[]>} types - The types of the typed data.
 * @param {Record<string, any>} value - The value of the typed data.
 * @param {SignatureLike} signature - The signature to verify.
 * @returns {string} The address that signed the typed data.
 */
export declare function verifyTypedData(domain: TypedDataDomain, types: Record<string, Array<TypedDataField>>, value: Record<string, any>, signature: SignatureLike): string;
//# sourceMappingURL=typed-data.d.ts.map