/**
 * A simple hashing function which operates on UTF-8 strings to compute an 32-byte identifier.
 *
 * This simply computes the {@link toUtf8Bytes | **UTF-8 bytes**} and computes the {@link keccak256 | **keccak256**}.
 *
 * @category Hash
 * @example
 *
 * ```ts
 * id('hello world');
 * ```
 *
 * @param {string} value - The string to hash.
 * @returns {string} The 32-byte identifier.
 */
export declare function id(value: string): string;
//# sourceMappingURL=id.d.ts.map