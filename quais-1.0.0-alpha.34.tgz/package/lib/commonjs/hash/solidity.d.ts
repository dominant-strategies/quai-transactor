/**
 * Computes the [Non-Standard Packed
 * Mode](https://docs.soliditylang.org/en/v0.8.14/abi-spec.html#non-standard-packed-mode) representation of `values`
 * respectively to their `types`.
 *
 * @category Hash
 * @example
 *
 * ```ts
 * addr = '0x8ba1f109551bd432803012645ac136ddd64dba72';
 * solidityPacked(['address', 'uint'], [addr, 45]);
 * ```
 *
 * @param {string[]} types - The types of the values.
 * @param {ReadonlyArray<any>} values - The values to pack.
 * @returns {string} The packed values.
 */
export declare function solidityPacked(types: ReadonlyArray<string>, values: ReadonlyArray<any>): string;
/**
 * Computes the [Non-Standard Packed
 * Mode](https://docs.soliditylang.org/en/v0.8.14/abi-spec.html#non-standard-packed-mode)
 * [**keccak256**](../functions/keccak256) hash of `values` respectively to their `types`.
 *
 * @category Hash
 * @example
 *
 * ```ts
 * addr = '0x8ba1f109551bd432803012645ac136ddd64dba72';
 * solidityPackedKeccak256(['address', 'uint'], [addr, 45]);
 * ```
 *
 * @param {ReadonlyArray<string>} types - The types of the values.
 * @param {ReadonlyArray<any>} values - The values to hash.
 * @returns {string} The hash of the packed values.
 */
export declare function solidityPackedKeccak256(types: ReadonlyArray<string>, values: ReadonlyArray<any>): string;
/**
 * Computes the [Non-Standard Packed
 * Mode](https://docs.soliditylang.org/en/v0.8.14/abi-spec.html#non-standard-packed-mode) [sha256](../functions/sha256)
 * hash of `values` respectively to their `types`.
 *
 * @category Hash
 * @example
 *
 * ```ts
 * addr = '0x8ba1f109551bd432803012645ac136ddd64dba72';
 * solidityPackedSha256(['address', 'uint'], [addr, 45]);
 * ```
 *
 * @param {ReadonlyArray<string>} types - The types of the values.
 * @param {ReadonlyArray<any>} values - The values to hash.
 * @returns {string} The hash of the packed values.
 */
export declare function solidityPackedSha256(types: ReadonlyArray<string>, values: ReadonlyArray<any>): string;
//# sourceMappingURL=solidity.d.ts.map