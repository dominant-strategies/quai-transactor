import type { BytesLike } from '../utils/index.js';
/**
 * Compute the cryptographic RIPEMD-160 hash of `data`.
 *
 * @category Crypto
 * @example
 *
 * ```ts
 * ripemd160('0x');
 *
 * ripemd160('0x1337');
 *
 * ripemd160(new Uint8Array([0x13, 0x37]));
 * ```
 *
 * @param {BytesLike} _data - The data to hash.
 * @returns DataHexstring
 * @returns {string} The hash of the data.
 */
export declare function ripemd160(_data: BytesLike): string;
export declare namespace ripemd160 {
    var _: (data: Uint8Array) => Uint8Array;
    var lock: () => void;
    var register: (func: (data: Uint8Array) => BytesLike) => void;
}
//# sourceMappingURL=ripemd160.d.ts.map