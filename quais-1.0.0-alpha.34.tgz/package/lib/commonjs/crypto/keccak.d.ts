/**
 * Cryptographic hashing functions
 */
import type { BytesLike } from '../utils/index.js';
/**
 * Compute the cryptographic KECCAK256 hash of `data`.
 *
 * The `data` **must** be a data representation, to compute the hash of UTF-8 data use the [**id**}(../functions/id)
 * function.
 *
 * @category Crypto
 * @example
 *
 * ```ts
 * keccak256('0x');
 *
 * keccak256('0x1337');
 *
 * keccak256(new Uint8Array([0x13, 0x37]));
 *
 * // Strings are assumed to be DataHexString, otherwise it will
 * // throw. To hash UTF-8 data, see the note above.
 * keccak256('Hello World');
 * ```
 *
 * @param {BytesLike} _data - The data to hash.
 * @returns DataHexstring
 * @returns {string} The hash of the data.
 */
export declare function keccak256(_data: BytesLike): string;
export declare namespace keccak256 {
    var _: (data: Uint8Array) => Uint8Array;
    var lock: () => void;
    var register: (func: (data: Uint8Array) => BytesLike) => void;
}
//# sourceMappingURL=keccak.d.ts.map