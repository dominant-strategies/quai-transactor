/**
 * Add details about signing here.
 */
import { Signature } from './signature.js';
import type { BytesLike } from '../utils/index.js';
import type { SignatureLike } from './index.js';
/**
 * A **SigningKey** provides high-level access to the elliptic curve cryptography (ECC) operations and key management.
 *
 * @category Crypto
 */
export declare class SigningKey {
    #private;
    /**
     * Creates a new **SigningKey** for `privateKey`.
     */
    constructor(privateKey: BytesLike);
    /**
     * The private key.
     */
    get privateKey(): string;
    /**
     * The uncompressed public key.
     *
     * This will always begin with the prefix `0x04` and be 132 characters long (the `0x` prefix and 130 hexadecimal
     * nibbles).
     */
    get publicKey(): string;
    /**
     * The compressed public key.
     *
     * This will always begin with either the prefix `0x02` or `0x03` and be 68 characters long (the `0x` prefix and 33
     * hexadecimal nibbles)
     */
    get compressedPublicKey(): string;
    /**
     * Return the signature of the signed `digest`.
     *
     * @param {BytesLike} digest - The data to sign.
     * @returns {Signature} The signature of the data.
     * @throws {Error} If the digest is not 32 bytes long.
     */
    sign(digest: BytesLike): Signature;
    /**
     * Returns the [ECDH](https://en.wikipedia.org/wiki/Elliptic-curve_Diffie-Hellman) shared secret between this
     * private key and the `other` key.
     *
     * The `other` key may be any type of key, a raw public key, a compressed/uncompressed pubic key or aprivate key.
     *
     * Best practice is usually to use a cryptographic hash on the returned value before using it as a symetric secret.
     *
     * @example
     *
     * ```ts
     * sign1 = new SigningKey(id('some-secret-1'));
     * sign2 = new SigningKey(id('some-secret-2'));
     *
     * // Notice that privA.computeSharedSecret(pubB)...
     * sign1.computeSharedSecret(sign2.publicKey);
     *
     * // ...is equal to privB.computeSharedSecret(pubA).
     * sign2.computeSharedSecret(sign1.publicKey);
     * ```
     *
     * @param {BytesLike} other - The other key to compute the shared secret with.
     * @returns {string} The shared secret.
     */
    computeSharedSecret(other: BytesLike): string;
    /**
     * Compute the public key for `key`, optionally `compressed`.
     *
     * The `key` may be any type of key, a raw public key, a compressed/uncompressed public key or private key.
     *
     * @example
     *
     * ```ts
     * sign = new SigningKey(id('some-secret'));
     *
     * // Compute the uncompressed public key for a private key
     * SigningKey.computePublicKey(sign.privateKey);
     *
     * // Compute the compressed public key for a private key
     * SigningKey.computePublicKey(sign.privateKey, true);
     *
     * // Compute the uncompressed public key
     * SigningKey.computePublicKey(sign.publicKey, false);
     *
     * // Compute the Compressed a public key
     * SigningKey.computePublicKey(sign.publicKey, true);
     * ```
     *
     * @param {BytesLike} key - The key to compute the public key for.
     * @param {boolean} [compressed] - Whether to return the compressed public key.
     * @returns {string} The public key.
     */
    static computePublicKey(key: BytesLike, compressed?: boolean): string;
    /**
     * Returns the public key for the private key which produced the `signature` for the given `digest`.
     *
     * @example
     *
     * ```ts
     * key = new SigningKey(id('some-secret'));
     * digest = id('hello world');
     * sig = key.sign(digest);
     *
     * // Notice the signer public key...
     * key.publicKey;
     *
     * // ...is equal to the recovered public key
     * SigningKey.recoverPublicKey(digest, sig);
     * ```
     *
     * @param {BytesLike} digest - The data that was signed.
     * @param {SignatureLike} signature - The signature of the data.
     * @returns {string} The public key.
     */
    static recoverPublicKey(digest: BytesLike, signature: SignatureLike): string;
    /**
     * Returns the point resulting from adding the ellipic curve points `p0` and `p1`.
     *
     * This is not a common function most developers should require, but can be useful for certain privacy-specific
     * techniques.
     *
     * For example, it is used by [**QuaiHDWallet**](../classes/QuaiHDWallet) to compute child addresses from parent
     * public keys and chain codes.
     *
     * @param {BytesLike} p0 - The first point to add.
     * @param {BytesLike} p1 - The second point to add.
     * @param {boolean} [compressed] - Whether to return the compressed public key.
     * @returns {string} The sum of the points.
     */
    static addPoints(p0: BytesLike, p1: BytesLike, compressed?: boolean): string;
}
//# sourceMappingURL=signing-key.d.ts.map