import type { BytesLike } from '../utils/index.js';
/**
 * Compute the cryptographic SHA2-256 hash of `data`.
 *
 * @category Crypto
 * @example
 *
 * ```ts
 * sha256('0x');
 *
 * sha256('0x1337');
 *
 * sha256(new Uint8Array([0x13, 0x37]));
 * ```
 *
 * @param {BytesLike} _data - The data to hash.
 * @returns {string} The hash of the data.
 */
export declare function sha256(_data: BytesLike): string;
export declare namespace sha256 {
    var _: (data: Uint8Array) => Uint8Array;
    var lock: () => void;
    var register: (func: (data: Uint8Array) => BytesLike) => void;
}
/**
 * Compute the cryptographic SHA2-512 hash of `data`.
 *
 * @category Crypto
 * @example
 *
 * ```ts
 * sha512('0x');
 *
 * sha512('0x1337');
 *
 * sha512(new Uint8Array([0x13, 0x37]));
 * ```
 *
 * @param {BytesLike} _data - The data to hash.
 * @returns {string} The hash of the data.
 */
export declare function sha512(_data: BytesLike): string;
export declare namespace sha512 {
    var _: (data: Uint8Array) => Uint8Array;
    var lock: () => void;
    var register: (func: (data: Uint8Array) => BytesLike) => void;
}
//# sourceMappingURL=sha2.d.ts.map