/**
 * Return `length` bytes of cryptographically secure random data.
 *
 * @category Crypto
 * @example
 *
 * ```ts
 * randomBytes(8);
 * ```
 *
 * @param {number} length - The number of bytes to generate.
 * @returns {Uint8Array} The random bytes.
 */
export declare function randomBytes(length: number): Uint8Array;
export declare namespace randomBytes {
    var _: (length: number) => Uint8Array;
    var lock: () => void;
    var register: (func: (length: number) => Uint8Array) => void;
}
//# sourceMappingURL=random.d.ts.map