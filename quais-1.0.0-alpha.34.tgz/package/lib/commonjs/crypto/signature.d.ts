import type { BigNumberish, BytesLike } from '../utils/index.js';
/**
 * A SignatureLike
 *
 * @category Crypto
 */
export type SignatureLike = Signature | string | {
    r: string;
    s: string;
    v: BigNumberish;
    yParity?: 0 | 1;
    yParityAndS?: string;
} | {
    r: string;
    yParityAndS: string;
    yParity?: 0 | 1;
    s?: string;
    v?: number;
} | {
    r: string;
    s: string;
    yParity: 0 | 1;
    v?: BigNumberish;
    yParityAndS?: string;
};
/**
 * A Signature @TODO
 *
 * @category Crypto
 */
export declare class Signature {
    #private;
    /**
     * The `r` value for a signautre.
     *
     * This represents the `x` coordinate of a "reference" or challenge point, from which the `y` can be computed.
     */
    get r(): string;
    set r(value: BytesLike);
    /**
     * The `s` value for a signature.
     */
    get s(): string;
    set s(_value: BytesLike);
    /**
     * The `v` value for a signature.
     *
     * Since a given `x` value for `r` has two possible values for its correspondin `y`, the `v` indicates which of the
     * two `y` values to use.
     *
     * It is normalized to the values `27` or `28` for legacy purposes.
     */
    get v(): 27 | 28;
    set v(value: BigNumberish);
    /**
     * The EIP-155 `v` for legacy transactions. For non-legacy transactions, this value is `null`.
     */
    get networkV(): null | bigint;
    /**
     * The chain ID for EIP-155 legacy transactions. For non-legacy transactions, this value is `null`.
     */
    get legacyChainId(): null | bigint;
    /**
     * The `yParity` for the signature.
     *
     * See `v` for more details on how this value is used.
     */
    get yParity(): 0 | 1;
    /**
     * The [EIP-2098](https://eips.ethereum.org/EIPS/eip-2098) compact representation of the `yParity` and `s` compacted
     * into a single `bytes32`.
     */
    get yParityAndS(): string;
    /**
     * The [EIP-2098](https://eips.ethereum.org/EIPS/eip-2098) compact representation.
     */
    get compactSerialized(): string;
    /**
     * The serialized representation.
     */
    get serialized(): string;
    /**
     * @ignore
     */
    constructor(guard: any, r: string, s: string, v: 27 | 28);
    /**
     * Returns a new identical {@link Signature | **Signature**}.
     */
    clone(): Signature;
    /**
     * Returns a representation that is compatible with `JSON.stringify`.
     */
    toJSON(): any;
    /**
     * Compute the chain ID from the `v` in a legacy EIP-155 transactions.
     *
     * @example
     *
     * ```ts
     * Signature.getChainId(45);
     *
     * Signature.getChainId(46);
     * ```
     *
     * @param {BigNumberish} v - The `v` value from the signature.
     * @returns {bigint} The chain ID.
     */
    static getChainId(v: BigNumberish): bigint;
    /**
     * Compute the `v` for a chain ID for a legacy EIP-155 transactions.
     *
     * Legacy transactions which use [EIP-155](https://eips.ethereum.org/EIPS/eip-155) hijack the `v` property to
     * include the chain ID.
     *
     * @example
     *
     * ```ts
     * Signature.getChainIdV(5, 27);
     *
     * Signature.getChainIdV(5, 28);
     * ```
     *
     * @param {BigNumberish} chainId - The chain ID.
     * @param {27 | 28} v - The `v` value.
     * @returns {bigint} The `v` value.
     */
    static getChainIdV(chainId: BigNumberish, v: 27 | 28): bigint;
    /**
     * Compute the normalized legacy transaction `v` from a `yParirty`, a legacy transaction `v` or a legacy
     * [EIP-155](https://eips.ethereum.org/EIPS/eip-155) transaction.
     *
     * @example
     *
     * ```ts
     * // The values 0 and 1 imply v is actually yParity
     * Signature.getNormalizedV(0);
     *
     * // Legacy non-EIP-1559 transaction (i.e. 27 or 28)
     * Signature.getNormalizedV(27);
     *
     * // Legacy EIP-155 transaction (i.e. >= 35)
     * Signature.getNormalizedV(46);
     *
     * // Invalid values throw
     * Signature.getNormalizedV(5);
     * ```
     *
     * @param {BigNumberish} v - The `v` value.
     * @returns {27 | 28} The normalized `v` value.
     * @throws {Error} Thrown if the `v` is invalid.
     */
    static getNormalizedV(v: BigNumberish): 27 | 28;
    /**
     * Creates a new {@link Signature | **Signature**}.
     *
     * If no `sig` is provided, a new {@link Signature | **Signature**} is created with default values.
     *
     * If `sig` is a string, it is parsed.
     *
     * @param {SignatureLike} [sig] - The signature to create.
     * @returns {Signature} The new signature.
     */
    static from(sig?: SignatureLike): Signature;
}
//# sourceMappingURL=signature.d.ts.map