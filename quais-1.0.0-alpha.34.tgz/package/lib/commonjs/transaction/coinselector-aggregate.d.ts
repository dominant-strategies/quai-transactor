import { AbstractCoinSelector, CoinSelectionConfig, SelectedCoinsResult } from './abstract-coinselector.js';
/**
 * A coin selector that aggregates multiple UTXOs into larger denominations. It attempts to combine smaller denomination
 * UTXOs into the largest possible denominations.
 */
export declare class AggregateCoinSelector extends AbstractCoinSelector {
    /**
     * Performs coin selection by aggregating UTXOs into larger denominations. This implementation combines smaller
     * denomination UTXOs into the largest possible denominations up to maxDenomination, while ensuring enough value
     * remains to cover the transaction fee.
     *
     * @param {CoinSelectionConfig} config - The configuration object containing:
     * @param {boolean} [config.includeLocked=false] - Whether to include locked UTXOs in the selection. Default is
     *   `false`
     * @param {bigint} [config.fee=0n] - The fee amount to account for. Default is `0n`
     * @param {number} [config.maxDenomination=6] - The maximum denomination to aggregate up to (default 6 = 1 Qi).
     *   Default is `6`
     * @returns {SelectedCoinsResult} The selected UTXOs and aggregated outputs
     * @throws {Error} If no eligible UTXOs are available for aggregation
     */
    performSelection(config: CoinSelectionConfig): SelectedCoinsResult;
    /**
     * Helper method to calculate the optimal denomination distribution for a given value.
     *
     * @param {bigint} value - The value to optimize denominations for
     * @returns {UTXO[]} Array of UTXOs with optimal denomination distribution
     */
    private createOptimalDenominations;
    private getInputsForFee;
    private getInputsToAggregate;
}
//# sourceMappingURL=coinselector-aggregate.d.ts.map