import { AbstractTransaction, TransactionLike, TxInput, TxOutput } from './index.js';
import { ProtoTransaction } from './abstract-transaction.js';
import { Zone } from '../constants/index.js';
/**
 * Interface representing a QiTransaction.
 *
 * @category Transaction
 */
export interface QiTransactionLike extends TransactionLike {
    /**
     * Transaction inputs.
     *
     * @type {TxInput[] | null}
     */
    txInputs?: null | TxInput[];
    /**
     * Transaction outputs.
     *
     * @type {TxOutput[] | null}
     */
    txOutputs?: null | TxOutput[];
}
/**
 * Class representing a QiTransaction.
 *
 * @category Transaction
 * @extends {AbstractTransaction<string>}
 * @implements {QiTransactionLike}
 */
export declare class QiTransaction extends AbstractTransaction<string> implements QiTransactionLike {
    #private;
    /**
     * Get transaction inputs.
     *
     * @returns {TxInput[]} The transaction inputs.
     */
    get txInputs(): TxInput[];
    /**
     * Set transaction inputs.
     *
     * @param {TxInput[] | null} value - The transaction inputs.
     * @throws {Error} If the value is not an array.
     */
    set txInputs(value: TxInput[] | null);
    /**
     * Get transaction outputs.
     *
     * @returns {TxOutput[]} The transaction outputs.
     */
    get txOutputs(): TxOutput[];
    /**
     * Set transaction outputs.
     *
     * @param {TxOutput[] | null} value - The transaction outputs.
     * @throws {Error} If the value is not an array.
     */
    set txOutputs(value: TxOutput[] | null);
    /**
     * Get the permuted hash of the transaction as specified by QIP-0010.
     *
     * @returns {string | null} The transaction hash.
     * @throws {Error} If the transaction has no inputs or outputs, or if cross-zone & cross-ledger transactions are not
     *   supported.
     * @see {@link [QIP0010](https://github.com/quai-network/qips/blob/master/qip-0010.md)}
     */
    get hash(): null | string;
    /**
     * Get the zone of the sender address.
     *
     * @returns {Zone | undefined} The origin zone.
     */
    get originZone(): Zone | undefined;
    /**
     * Get the zone of the recipient address.
     *
     * @returns {Zone | undefined} The destination zone.
     */
    get destZone(): Zone | undefined;
    /**
     * Creates a new Transaction with default values.
     */
    constructor();
    /**
     * Validates the explicit properties and returns a list of compatible transaction types.
     *
     * @returns {number[]} The compatible transaction types.
     */
    inferTypes(): Array<number>;
    /**
     * Create a copy of this transaction.
     *
     * @returns {QiTransaction} The cloned transaction.
     */
    clone(): QiTransaction;
    /**
     * Return a JSON-friendly object.
     *
     * @returns {QiTransactionLike} The JSON-friendly object.
     */
    toJSON(): TransactionLike;
    /**
     * Return a protobuf-friendly JSON object.
     *
     * @param {boolean} [includeSignature=true] - Whether to include the signature. Default is `true`
     * @returns {ProtoTransaction} The protobuf-friendly JSON object.
     */
    toProtobuf(includeSignature?: boolean): ProtoTransaction;
    /**
     * Create a Transaction from a serialized transaction or a Transaction-like object.
     *
     * @param {string | QiTransactionLike} tx - The transaction to decode.
     * @returns {QiTransaction} The decoded transaction.
     * @throws {Error} If the transaction is unsigned and defines a hash.
     */
    static from(tx: string | QiTransactionLike): QiTransaction;
    /**
     * Create a Transaction from a ProtoTransaction object.
     *
     * @param {ProtoTransaction} protoTx - The transaction to decode.
     * @returns {QiTransaction} The decoded transaction.
     */
    static fromProto(protoTx: ProtoTransaction): QiTransaction;
}
//# sourceMappingURL=qi-transaction.d.ts.map