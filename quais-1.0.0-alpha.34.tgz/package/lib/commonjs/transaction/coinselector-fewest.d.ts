import { AbstractCoinSelector, CoinSelectionConfig, SelectedCoinsResult } from './abstract-coinselector.js';
import { UTXO } from './utxo.js';
/**
 * The FewestCoinSelector class provides a coin selection algorithm that selects the fewest UTXOs required to meet the
 * target amount. This algorithm is useful for minimizing the size of the transaction and the fees associated with it.
 *
 * This class is a sub-class of {@link AbstractCoinSelector | **AbstractCoinSelector** } and implements the
 * {@link AbstractCoinSelector.performSelection | **performSelection** } method to provide the actual coin selection
 * logic.
 *
 * @category Transaction
 */
export declare class FewestCoinSelector extends AbstractCoinSelector {
    /**
     * Performs coin selection to meet the target amount plus fee, using the smallest possible denominations and
     * minimizing the number of inputs and outputs.
     *
     * @param {bigint} target - The target amount to spend.
     * @param {bigint} fee - The fee amount to include in the selection.
     * @returns {SelectedCoinsResult} The selected UTXOs and outputs.
     */
    performSelection(config: CoinSelectionConfig): SelectedCoinsResult;
    /**
     * Finds the minimal set of UTXOs that can cover the total required amount.
     *
     * @param {UTXO[]} sortedUTXOs - Available UTXOs sorted by denomination (ascending).
     * @param {bigint} totalRequired - The total amount required (target + fee).
     * @returns {UTXO[]} The minimal set of UTXOs.
     */
    protected findMinimalUTXOSet(sortedUTXOs: UTXO[], totalRequired: bigint): UTXO[];
    /**
     * Creates spend outputs based on the target amount and input denominations.
     *
     * @param {bigint} amount - The target amount to spend.
     * @param {UTXO[]} inputs - The selected inputs.
     * @returns {UTXO[]} The spend outputs.
     */
    protected createSpendOutputs(amount: bigint): UTXO[];
    /**
     * Creates change outputs based on the change amount and input denominations.
     *
     * @param {bigint} change - The change amount to return.
     * @param {UTXO[]} inputs - The selected inputs.
     * @returns {UTXO[]} The change outputs.
     */
    protected createChangeOutputs(change: bigint): UTXO[];
    /**
     * Calculates the total value of outputs (spend + change).
     *
     * @returns {bigint} The total output value.
     */
    protected calculateTotalOutputValue(): bigint;
    /**
     * Gets the maximum denomination value from the selected UTXOs.
     *
     * @returns {bigint} The maximum input denomination value.
     */
    protected getMaxInputDenomination(): bigint;
    /**
     * Gets the maximum denomination value from the spend and change outputs.
     *
     * @returns {bigint} The maximum output denomination value.
     */
    protected getMaxOutputDenomination(): bigint;
    /**
     * Gets the maximum denomination value from a list of UTXOs.
     *
     * @param {UTXO[]} utxos - The list of UTXOs.
     * @returns {bigint} The maximum denomination value.
     */
    protected getMaxDenomination(utxos: UTXO[]): bigint;
    /**
     * Increases the total fee by first reducing change outputs, then selecting additional inputs if necessary.
     *
     * @param {bigint} additionalFeeNeeded - The additional fee needed.
     * @returns {boolean} Returns true if successful, false if insufficient funds.
     */
    increaseFee(additionalFeeNeeded: bigint): SelectedCoinsResult;
    /**
     * Decreases the fee by removing inputs if possible and adjusting change outputs.
     *
     * @param {bigint} feeReduction - The amount by which the fee has decreased.
     * @returns {void}
     */
    decreaseFee(feeReduction: bigint): SelectedCoinsResult;
    /**
     * Helper method to adjust change outputs.
     *
     * @param {bigint} changeAmount - The amount to adjust change outputs by.
     */
    protected adjustChangeOutputs(changeAmount: bigint): void;
}
//# sourceMappingURL=coinselector-fewest.d.ts.map