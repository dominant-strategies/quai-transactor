import { UTXO } from './utxo.js';
/**
 * Represents a target for spending.
 *
 * @typedef {Object} SpendTarget
 * @property {string} address - The address to send to.
 * @property {bigint} value - The amount to send.
 */
export type SpendTarget = {
    address: string;
    value: bigint;
};
/**
 * Represents the result of selected coins.
 *
 * @typedef {Object} SelectedCoinsResult
 * @property {UTXO[]} inputs - The selected UTXOs.
 * @property {UTXO[]} spendOutputs - The outputs for spending.
 * @property {UTXO[]} changeOutputs - The outputs for change.
 */
export type SelectedCoinsResult = {
    inputs: UTXO[];
    spendOutputs: UTXO[];
    changeOutputs: UTXO[];
};
/**
 * An **AbstractCoinSelector** provides a base class for other sub-classes to implement the functionality for selecting
 * UTXOs for a spend and to properly handle spend and change outputs.
 *
 * This class is abstract and should not be used directly. Sub-classes should implement the
 * {@link AbstractCoinSelector#performSelection | **performSelection**} method to provide the actual coin selection
 * logic.
 *
 * @category Transaction
 * @abstract
 */
export interface CoinSelectionConfig {
    target?: bigint;
    fee?: bigint;
    includeLocked?: boolean;
    maxDenomination?: number;
}
export declare abstract class AbstractCoinSelector {
    availableUTXOs: UTXO[];
    totalInputValue: bigint;
    spendOutputs: UTXO[];
    changeOutputs: UTXO[];
    selectedUTXOs: UTXO[];
    target: bigint | null;
    /**
     * Constructs a new AbstractCoinSelector instance with an empty UTXO array.
     *
     * @param {UTXO[]} [availableUXTOs=[]] - The initial available UTXOs. Default is `[]`
     */
    constructor(availableUTXOs?: UTXO[]);
    /**
     * This method should be implemented by sub-classes to provide the actual coin selection logic. It should select
     * UTXOs from the available UTXOs that sum to the target amount and return the selected UTXOs as well as the spend
     * and change outputs.
     *
     * @abstract
     * @param {CoinSelectionConfig} config - The configuration for coin selection.
     * @returns {SelectedCoinsResult} The selected UTXOs and outputs.
     */
    abstract performSelection(config: CoinSelectionConfig): SelectedCoinsResult;
    /**
     * Validates the provided UTXO instance. In order to be valid for coin selection, the UTXO must have a valid address
     * and denomination.
     *
     * @param {UTXO} utxo - The UTXO to validate.
     * @throws {Error} If the UTXO is invalid.
     * @protected
     */
    protected _validateUTXO(utxo: UTXO): void;
    /**
     * Validates the available UTXOs.
     *
     * @throws Will throw an error if there are no available UTXOs.
     */
    protected validateUTXOs(): void;
    /**
     * Sorts UTXOs by their denomination.
     *
     * @param {UTXO[]} utxos - The UTXOs to sort.
     * @param {'asc' | 'desc'} direction - The direction to sort ('asc' for ascending, 'desc' for descending).
     * @returns {UTXO[]} The sorted UTXOs.
     */
    protected sortUTXOsByDenomination(utxos: UTXO[], direction: 'asc' | 'desc'): UTXO[];
}
//# sourceMappingURL=abstract-coinselector.d.ts.map