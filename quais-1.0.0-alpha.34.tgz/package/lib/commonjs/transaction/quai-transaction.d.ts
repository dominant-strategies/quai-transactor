import { Signature } from '../crypto/index.js';
import { AccessList, AccessListish, AbstractTransaction, TransactionLike } from './index.js';
import { BigNumberish, BytesLike } from '../utils/index.js';
import { ProtoTransaction } from './abstract-transaction.js';
import { Zone } from '../constants/index.js';
/**
 * A **QuaiTransactionLike** is a JSON representation of a Quai transaction.
 *
 * @category Transaction
 */
export interface QuaiTransactionLike extends TransactionLike {
    /**
     * The recipient address or `null` for an `init` transaction.
     */
    to?: null | string;
    /**
     * The sender.
     */
    from?: string;
    /**
     * The nonce.
     */
    nonce?: null | number;
    /**
     * The maximum amount of gas that can be used.
     */
    gasLimit?: null | BigNumberish;
    /**
     * The maximum total fee per gas for london transactions.
     */
    gasPrice?: null | BigNumberish;
    /**
     * The data.
     */
    data?: null | string;
    /**
     * The value (in wei) to send.
     */
    value?: null | BigNumberish;
    /**
     * The access list for berlin and london transactions.
     */
    accessList?: null | AccessListish;
}
/**
 * Parses a signature from an array of fields.
 *
 * @ignore
 * @param {string[]} fields - The fields to parse.
 * @returns {Signature} The parsed signature.
 */
export declare function _parseSignature(fields: Array<string>): Signature;
/**
 * Represents a Quai transaction.
 *
 * @category Transaction
 */
export declare class QuaiTransaction extends AbstractTransaction<Signature> implements QuaiTransactionLike {
    #private;
    from?: string;
    /**
     * The `to` address for the transaction or `null` if the transaction is an `init` transaction.
     *
     * @type {null | string}
     */
    get to(): null | string;
    set to(value: null | string);
    /**
     * The permuted hash of the transaction as specified by
     * [QIP-0010](https://github.com/quai-network/qips/blob/master/qip-0010.md).
     *
     * @type {null | string}
     * @throws {Error} If the transaction is not signed.
     */
    get hash(): null | string;
    /**
     * The zone of the sender address
     *
     * @type {Zone | undefined}
     */
    get originZone(): Zone | undefined;
    /**
     * The zone of the recipient address
     *
     * @type {Zone | undefined}
     */
    get destZone(): Zone | undefined;
    /**
     * The transaction nonce.
     *
     * @type {number}
     */
    get nonce(): number;
    set nonce(value: BigNumberish);
    /**
     * The gas limit.
     *
     * @type {bigint}
     */
    get gasLimit(): bigint;
    set gasLimit(value: BigNumberish);
    /**
     * The maximum total fee per unit of gas to pay. On legacy networks this should be `null`.
     *
     * @type {null | bigint}
     */
    get gasPrice(): null | bigint;
    set gasPrice(value: null | BigNumberish);
    /**
     * The transaction data. For `init` transactions this is the deployment code.
     *
     * @type {string}
     */
    get data(): string;
    set data(value: BytesLike);
    /**
     * The amount of ether to send in this transactions.
     *
     * @type {bigint}
     */
    get value(): bigint;
    set value(value: BigNumberish);
    /**
     * The access list.
     *
     * An access list permits discounted (but pre-paid) access to bytecode and state variable access within contract
     * execution.
     *
     * @type {null | AccessList}
     */
    get accessList(): null | AccessList;
    set accessList(value: null | AccessListish);
    /**
     * Creates a new Transaction with default values.
     *
     * @param {string} [from] - The sender address.
     */
    constructor(from?: string);
    /**
     * Validates the explicit properties and returns a list of compatible transaction types.
     *
     * @returns {number[]} The compatible transaction types.
     */
    inferTypes(): Array<number>;
    /**
     * Create a copy of this transaction.
     *
     * @returns {QuaiTransaction} The cloned transaction.
     */
    clone(): QuaiTransaction;
    /**
     * Return a JSON-friendly object.
     *
     * @returns {QuaiTransactionLike} The JSON-friendly object.
     */
    toJSON(): QuaiTransactionLike;
    /**
     * Return a protobuf-friendly JSON object.
     *
     * @param {boolean} [includeSignature=true] - Whether to include the signature. Default is `true`
     * @returns {ProtoTransaction} The protobuf-friendly JSON object.
     */
    toProtobuf(includeSignature?: boolean): ProtoTransaction;
    /**
     * Create a **Transaction** from a serialized transaction or a Transaction-like object.
     *
     * @param {string | QuaiTransactionLike} tx - The transaction to decode.
     * @returns {QuaiTransaction} The decoded transaction.
     */
    static from(tx: string | QuaiTransactionLike): QuaiTransaction;
    /**
     * Create a **Transaction** from a ProtoTransaction object.
     *
     * @param {ProtoTransaction} protoTx - The transaction to decode.
     * @returns {QuaiTransaction} The decoded transaction.
     */
    static fromProto(protoTx: ProtoTransaction): QuaiTransaction;
}
//# sourceMappingURL=quai-transaction.d.ts.map