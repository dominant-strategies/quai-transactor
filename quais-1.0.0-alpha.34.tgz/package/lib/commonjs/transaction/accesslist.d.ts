import type { AccessList, AccessListish } from './index.js';
/**
 * Returns an {@link AccessList | **AccessList**} from any quasi-supported access-list structure.
 *
 * @category Transaction
 * @param {AccessListish} value - The value to convert to an access list.
 * @returns {AccessList} The access list.
 * @throws {Error} If the value is not a valid access list.
 */
export declare function accessListify(value: AccessListish): AccessList;
//# sourceMappingURL=accesslist.d.ts.map