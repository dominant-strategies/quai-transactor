/**
 * Represents an a spendable transaction outpoint.
 *
 * @ignore
 * @category Transaction
 */
export type Outpoint = {
    txhash: string;
    index: number;
    denomination: number;
    lock?: number;
};
/**
 * Represents a UTXO entry.
 *
 * @ignore
 * @category Transaction
 */
export interface UTXOEntry {
    denomination: null | number;
    address: string;
}
/**
 * Represents a UTXO-like object.
 *
 * @ignore
 * @category Transaction
 */
export interface UTXOLike extends UTXOEntry {
    txhash?: null | string;
    index?: null | number;
}
/**
 * Represents a Qi transaction input.
 *
 * @category Transaction
 */
export type TxInput = {
    txhash: string;
    index: number;
    pubkey: string;
};
/**
 * Represents a Qi transaction output.
 *
 * @category Transaction
 */
export type TxOutput = {
    address: string;
    denomination: number;
    lock?: string;
};
type PreviousOutpointJson = {
    txHash: string;
    index: string;
};
export type TxInputJson = {
    previousOutpoint: PreviousOutpointJson;
    pubkey: string;
};
export type TxOutputJson = {
    address: string;
    denomination: string;
    lock?: string;
};
export interface OutpointDeltas {
    [address: string]: {
        created: Outpoint[];
        deleted: Outpoint[];
    };
}
/**
 * List of supported Qi denominations.
 *
 * @category Transaction
 */
export declare const denominations: bigint[];
/**
 * Given a value, returns an array of supported denominations that sum to the value.
 *
 * @category Transaction
 * @param {bigint} value - The value to denominate.
 * @returns {bigint[]} An array of denominations that sum to the value.
 * @throws {Error} If the value is less than or equal to 0 or cannot be matched with available denominations.
 */
export declare function denominate(value: bigint, maxDenomination?: bigint): bigint[];
/**
 * Represents a UTXO (Unspent Transaction Output).
 *
 * @category Transaction
 * @implements {UTXOLike}
 */
export declare class UTXO implements UTXOLike {
    #private;
    /**
     * Gets the transaction hash.
     *
     * @returns {null | string} The transaction hash.
     */
    get txhash(): null | string;
    /**
     * Sets the transaction hash.
     *
     * @param {null | string} value - The transaction hash.
     */
    set txhash(value: null | string);
    /**
     * Gets the index.
     *
     * @returns {null | number} The index.
     */
    get index(): null | number;
    /**
     * Sets the index.
     *
     * @param {null | number} value - The index.
     */
    set index(value: null | number);
    /**
     * Gets the address.
     *
     * @returns {string} The address.
     */
    get address(): string;
    /**
     * Sets the address.
     *
     * @param {string} value - The address.
     * @throws {Error} If the address is invalid.
     */
    set address(value: string);
    /**
     * Gets the denomination.
     *
     * @returns {null | number} The denomination.
     */
    get denomination(): null | number;
    /**
     * Sets the denomination.
     *
     * @param {null | number} value - The denomination.
     * @throws {Error} If the denomination value is invalid.
     */
    set denomination(value: null | number);
    get lock(): null | number;
    set lock(value: null | number);
    /**
     * Constructs a new UTXO instance with null properties.
     */
    constructor();
    /**
     * Converts the UTXO instance to a JSON object.
     *
     * @returns {any} A JSON representation of the UTXO instance.
     */
    toJSON(): any;
    /**
     * Creates a UTXO instance from a UTXOLike object.
     *
     * @param {UTXOLike} utxo - The UTXOLike object to convert.
     * @returns {UTXO} The UTXO instance.
     */
    static from(utxo: UTXOLike): UTXO;
}
export {};
//# sourceMappingURL=utxo.d.ts.map