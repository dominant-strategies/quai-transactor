import type { AbstractProvider, Subscriber } from './abstract-provider.js';
import { type EventFilter } from './provider.js';
import type { JsonRpcApiProvider } from './provider-jsonrpc.js';
import { Zone } from '../constants/index.js';
/**
 * Some backends support subscribing to events using a Filter ID.
 *
 * When subscribing with this technique, the node issues a unique **Filter ID**. At this point the node dedicates
 * resources to the filter, so that periodic calls to follow up on the **Filter ID** will receive any events since the
 * last call.
 *
 * @category Providers
 */
export declare class FilterIdSubscriber implements Subscriber {
    #private;
    protected zone: Zone;
    /**
     * @ignore Creates A new **FilterIdSubscriber** which will use {@link FilterIdSubscriber._subscribe | **_subscribe**}
     *   and {@link FilterIdSubscriber._emitResults | **_emitResults**} to setup the subscription and provide the event
     *   to the `provider`.
     * @param {JsonRpcApiProvider<any>} provider - The provider to use.
     */
    constructor(provider: JsonRpcApiProvider<any>, zone: Zone);
    /**
     * Sub-classes **must** override this to begin the subscription.
     *
     * @ignore
     * @param {JsonRpcApiProvider} provider - The provider to use.
     * @returns {Promise<string>} A promise that resolves to the subscription ID.
     * @throws {Error} If the method is not overridden.
     */
    _subscribe(provider: JsonRpcApiProvider): Promise<string>;
    /**
     * Sub-classes **must** override this to handle the events.
     *
     * @ignore
     * @param {AbstractProvider} provider - The provider to use.
     * @param {any[]} result - The results to handle.
     * @returns {Promise<void>} A promise that resolves when the results are handled.
     * @throws {Error} If the method is not overridden.
     */
    _emitResults(provider: AbstractProvider, result: Array<any>): Promise<void>;
    /**
     * Sub-classes **must** override this to handle recovery on errors.
     *
     * @ignore
     * @param {AbstractProvider} provider - The provider to use.
     * @returns {Subscriber} The recovered subscriber.
     * @throws {Error} If the method is not overridden.
     */
    _recover(provider: AbstractProvider): Subscriber;
    /**
     * Starts the subscriber.
     */
    start(): void;
    /**
     * Stops the subscriber.
     */
    stop(): void;
    /**
     * Pauses the subscriber.
     *
     * @param {boolean} [dropWhilePaused] - Whether to drop the subscription while paused.
     */
    pause(dropWhilePaused?: boolean): void;
    /**
     * Resumes the subscriber.
     */
    resume(): void;
}
/**
 * A **FilterIdSubscriber** for receiving contract events.
 *
 * @category Providers
 */
export declare class FilterIdEventSubscriber extends FilterIdSubscriber {
    #private;
    /**
     * @ignore Creates A new **FilterIdEventSubscriber** attached to `provider` listening for `filter`.
     * @param {JsonRpcApiProvider<any>} provider - The provider to use.
     * @param {EventFilter} filter - The event filter to use.
     */
    constructor(provider: JsonRpcApiProvider<any>, filter: EventFilter);
    /**
     * Recovers the subscriber.
     *
     * @ignore
     * @param {AbstractProvider<any>} provider - The provider to use.
     * @returns {Subscriber} The recovered subscriber.
     */
    _recover(provider: AbstractProvider<any>): Subscriber;
    /**
     * Subscribes to the event filter.
     *
     * @ignore
     * @param {JsonRpcApiProvider<any>} provider - The provider to use.
     * @returns {Promise<string>} A promise that resolves to the subscription ID.
     */
    _subscribe(provider: JsonRpcApiProvider<any>): Promise<string>;
    /**
     * Emits the results of the event filter.
     *
     * @ignore
     * @param {JsonRpcApiProvider<any>} provider - The provider to use.
     * @param {any[]} results - The results to emit.
     * @returns {Promise<void>} A promise that resolves when the results are emitted.
     */
    _emitResults(provider: JsonRpcApiProvider<any>, results: Array<any>): Promise<void>;
}
/**
 * A **FilterIdSubscriber** for receiving pending transactions events.
 *
 * @category Providers
 */
export declare class FilterIdPendingSubscriber extends FilterIdSubscriber {
    /**
     * Subscribes to the pending transactions filter.
     *
     * @ignore
     * @param {JsonRpcApiProvider<any>} provider - The provider to use.
     * @returns {Promise<string>} A promise that resolves to the subscription ID.
     */
    _subscribe(provider: JsonRpcApiProvider<any>): Promise<string>;
    /**
     * Emits the results of the pending transactions filter.
     *
     * @ignore
     * @param {JsonRpcApiProvider<any>} provider - The provider to use.
     * @param {any[]} results - The results to emit.
     * @returns {Promise<void>} A promise that resolves when the results are emitted.
     */
    _emitResults(provider: JsonRpcApiProvider<any>, results: Array<any>): Promise<void>;
}
//# sourceMappingURL=subscriber-filterid.d.ts.map