/**
 * One of the most common ways to interact with the blockchain is by a node running a JSON-RPC interface which can be
 * connected to, based on the transport, using:
 *
 * - HTTP or HTTPS - {@link JsonRpcProvider | **JsonRpcProvider**}
 * - WebSocket - {@link WebSocketProvider | **WebSocketProvider**}
 * - IPC - {@link IpcSocketProvider | **IpcSocketProvider**}
 */
import { QuaiTransactionLike } from '../transaction/index.js';
import { FetchRequest } from '../utils/index.js';
import { AbstractProvider } from './abstract-provider.js';
import { Network } from './network.js';
import type { TxInput, TxOutput } from '../transaction/index.js';
import type { PerformActionRequest, Subscriber, Subscription } from './abstract-provider.js';
import type { Networkish } from './network.js';
import type { Provider, QuaiTransactionRequest, TransactionRequest, TransactionResponse } from './provider.js';
import { Shard } from '../constants/index.js';
import { TypedDataDomain, TypedDataField } from '../hash/index.js';
import { AbstractSigner, Signer } from '../signers/index.js';
/**
 * A JSON-RPC payload, which are sent to a JSON-RPC server.
 *
 * @category Providers
 */
export type JsonRpcPayload = {
    /**
     * The JSON-RPC request ID.
     */
    id: number;
    /**
     * The JSON-RPC request method.
     */
    method: string;
    /**
     * The JSON-RPC request parameters.
     */
    params: Array<any> | Record<string, any>;
    /**
     * A required constant in the JSON-RPC specification.
     */
    jsonrpc: '2.0';
};
/**
 * A JSON-RPC result, which are returned on success from a JSON-RPC server.
 *
 * @category Providers
 */
export type JsonRpcResult = {
    /**
     * The response ID to match it to the relevant request.
     */
    id: number;
    /**
     * The response result.
     */
    result: any;
};
/**
 * A JSON-RPC error, which are returned on failure from a JSON-RPC server.
 *
 * @category Providers
 */
export type JsonRpcError = {
    /**
     * The response ID to match it to the relevant request.
     */
    id: number;
    /**
     * The response error.
     */
    error: {
        code: number;
        message?: string;
        data?: any;
        shard?: Shard;
    };
};
/**
 * When subscribing to the `"debug"` event, the Listener will receive this object as the first parameter.
 *
 * @category Providers
 */
export type DebugEventJsonRpcApiProvider = {
    action: 'sendRpcPayload';
    payload: JsonRpcPayload | Array<JsonRpcPayload>;
} | {
    action: 'receiveRpcResult';
    result: Array<JsonRpcResult | JsonRpcError>;
} | {
    action: 'receiveRpcError';
    error: Error;
};
/**
 * Options for configuring a {@link JsonRpcApiProvider | **JsonRpcApiProvider**}. Much of this is targeted towards
 * sub-classes, which often will not expose any of these options to their consumers.
 *
 * **`polling`** - use the polling strategy is used immediately for events; otherwise, attempt to use filters and fall
 * back onto polling (default: `false`)
 *
 * **`staticNetwork`** - do not request chain ID on requests to validate the underlying chain has not changed (default:
 * `null`)
 *
 * This should **ONLY** be used if it is **certain** that the network cannot change, such as when using INFURA (since
 * the URL dictates the network). If the network is assumed static and it does change, this can have tragic
 * consequences. For example, this **CANNOT** be used with MetaMask, since the used can select a new network from the
 * drop-down at any time.
 *
 * **`batchStallTime`** - how long (ms) to aggregate requests into a single batch. `0` indicates batching will only
 * encompass the current event loop. If `batchMaxCount = 1`, this is ignored. (default: `10`)
 *
 * **`batchMaxSize`** - target maximum size (bytes) to allow per batch request (default: 1Mb)
 *
 * **`batchMaxCount`** - maximum number of requests to allow in a batch. If `batchMaxCount = 1`, then batching is
 * disabled. (default: `100`)
 *
 * **`cacheTimeout`** - passed as {@link AbstractProviderOptions | **AbstractProviderOptions**}.
 *
 * @category Providers
 */
export type JsonRpcApiProviderOptions = {
    staticNetwork?: null | Network | boolean;
    batchStallTime?: number;
    batchMaxSize?: number;
    batchMaxCount?: number;
    cacheTimeout?: number;
    usePathing?: boolean;
};
export interface AbstractJsonRpcTransactionRequest {
    /**
     * The chain ID the transaction is valid on.
     */
    chainId?: string;
    /**
     * The [EIP-2718](https://eips.ethereum.org/EIPS/eip-2718) transaction type.
     */
    type?: string;
}
export type JsonRpcTransactionRequest = QiJsonRpcTransactionRequest | QuaiJsonRpcTransactionRequest;
export interface QiJsonRpcTransactionRequest extends AbstractJsonRpcTransactionRequest {
    txInputs?: Array<TxInput>;
    txOutputs?: Array<TxOutput>;
}
/**
 * A **JsonRpcTransactionRequest** is formatted as needed by the JSON-RPC Ethereum API specification.
 *
 * @category Providers
 */
export interface QuaiJsonRpcTransactionRequest extends AbstractJsonRpcTransactionRequest {
    /**
     * The sender address to use when signing.
     */
    from?: string;
    /**
     * The target address.
     */
    to?: string;
    /**
     * The transaction data.
     */
    data?: string;
    /**
     * The maximum amount of gas to allow a transaction to consume.
     *
     * In most other places in quais, this is called `gasLimit` which differs from the JSON-RPC Ethereum API
     * specification.
     */
    gas?: string;
    /**
     * The maximum fee per gas for [EIP-1559](https://eips.ethereum.org/EIPS/eip-1559) transactions.
     */
    gasPrice?: string;
    /**
     * The nonce for the transaction.
     */
    nonce?: string;
    /**
     * The transaction value (in wei).
     */
    value?: string;
    /**
     * The transaction access list.
     */
    accessList?: Array<{
        address: string;
        storageKeys: Array<string>;
    }>;
}
/**
 * A signer that uses JSON-RPC to sign transactions and messages.
 *
 * @category Providers
 */
export declare class JsonRpcSigner extends AbstractSigner<JsonRpcApiProvider> {
    address: string;
    /**
     * Creates a new JsonRpcSigner instance.
     *
     * @param {JsonRpcApiProvider<any>} provider - The JSON-RPC provider.
     * @param {string} address - The address of the signer.
     */
    constructor(provider: JsonRpcApiProvider<any>, address: string);
    /**
     * Connects the signer to a provider.
     *
     * @param {null | Provider} provider - The provider to connect to.
     * @returns {Signer} The connected signer.
     * @throws {Error} If the signer cannot be reconnected.
     */
    connect(provider: null | Provider): Signer;
    /**
     * Gets the address of the signer.
     *
     * @returns {Promise<string>} The address of the signer.
     */
    getAddress(): Promise<string>;
    /**
     * Populates a Quai transaction.
     *
     * @ignore
     * @param {QuaiTransactionRequest} tx - The transaction request.
     * @returns {Promise<QuaiTransactionLike>} The populated transaction.
     */
    populateQuaiTransaction(tx: QuaiTransactionRequest): Promise<QuaiTransactionLike>;
    /**
     * Sends an unchecked transaction.
     *
     * @ignore
     * @param {TransactionRequest} _tx - The transaction request.
     * @returns {Promise<string>} The transaction hash.
     */
    sendUncheckedTransaction(_tx: TransactionRequest): Promise<string>;
    /**
     * Sends a transaction.
     *
     * @param {TransactionRequest} tx - The transaction request.
     * @returns {Promise<TransactionResponse>} The transaction response.
     * @throws {Error} If the transaction cannot be sent.
     */
    sendTransaction(tx: TransactionRequest): Promise<TransactionResponse>;
    /**
     * Signs a transaction.
     *
     * @param {TransactionRequest} _tx - The transaction request.
     * @returns {Promise<string>} The signed transaction.
     * @throws {Error} If the transaction cannot be signed.
     */
    signTransaction(_tx: TransactionRequest): Promise<string>;
    /**
     * Signs a message.
     *
     * @param {string | Uint8Array} _message - The message to sign.
     * @returns {Promise<string>} The signed message.
     */
    signMessage(_message: string | Uint8Array): Promise<string>;
    /**
     * Signs typed data.
     *
     * @param {TypedDataDomain} domain - The domain of the typed data.
     * @param {Record<string, TypedDataField[]>} types - The types of the typed data.
     * @param {Record<string, any>} _value - The value of the typed data.
     * @returns {Promise<string>} The signed typed data.
     */
    signTypedData(domain: TypedDataDomain, types: Record<string, Array<TypedDataField>>, _value: Record<string, any>): Promise<string>;
    /**
     * Unlocks the account.
     *
     * @param {string} password - The password to unlock the account.
     * @returns {Promise<boolean>} True if the account is unlocked, false otherwise.
     */
    unlock(password: string): Promise<boolean>;
    /**
     * Signs a message using the legacy method.
     *
     * @ignore
     * @param {string | Uint8Array} _message - The message to sign.
     * @returns {Promise<string>} The signed message.
     */
    _legacySignMessage(_message: string | Uint8Array): Promise<string>;
}
/**
 * The JsonRpcApiProvider is an abstract class and **MUST** be sub-classed.
 *
 * It provides the base for all JSON-RPC-based Provider interaction.
 *
 * Sub-classing Notes:
 *
 * - A sub-class MUST override _send
 * - A sub-class MUST call the `_start()` method once connected
 *
 * @category Providers
 */
export declare abstract class JsonRpcApiProvider<C = FetchRequest> extends AbstractProvider<C> {
    #private;
    /**
     * Creates a new JsonRpcApiProvider instance.
     *
     * @param {Networkish} [network] - The network to connect to.
     * @param {JsonRpcApiProviderOptions} [options] - The options for the provider.
     */
    constructor(network?: Networkish, options?: JsonRpcApiProviderOptions);
    /**
     * Returns the value associated with the option `key`.
     *
     * Sub-classes can use this to inquire about configuration options.
     *
     * @ignore
     * @param {keyof JsonRpcApiProviderOptions} key - The option key.
     * @returns {JsonRpcApiProviderOptions[key]} The option value.
     */
    _getOption<K extends keyof JsonRpcApiProviderOptions>(key: K): JsonRpcApiProviderOptions[K];
    /**
     * Gets the {@link Network | **Network**} this provider has committed to. On each call, the network is detected, and
     * if it has changed, the call will reject.
     *
     * @ignore
     * @returns {Network} The network.
     * @throws {Error} If the network is not available yet.
     */
    get _network(): Network;
    /**
     * Sends a JSON-RPC `payload` (or a batch) to the underlying channel.
     *
     * Sub-classes **MUST** override this.
     *
     * @ignore
     * @param {JsonRpcPayload | JsonRpcPayload[]} payload - The JSON-RPC payload.
     * @param {Shard} [shard] - The shard to send the request to.
     * @param {boolean} [now] - Whether to send the request immediately.
     * @returns {Promise<(JsonRpcResult | JsonRpcError)[]>} The JSON-RPC result.
     * @throws {Error} If the request fails.
     */
    abstract _send(payload: JsonRpcPayload | Array<JsonRpcPayload>, shard?: Shard, now?: boolean): Promise<Array<JsonRpcResult | JsonRpcError>>;
    /**
     * Resolves to the non-normalized value by performing `req`.
     *
     * Sub-classes may override this to modify behavior of actions, and should generally call `super._perform` as a
     * fallback.
     *
     * @ignore
     * @param {PerformActionRequest} req - The request to perform.
     * @returns {Promise<any>} The result of the request.
     * @throws {Error} If the request fails.
     */
    _perform(req: PerformActionRequest): Promise<any>;
    /**
     * Sub-classes may override this; it detects the _actual_ network that we are **currently** connected to.
     *
     * Keep in mind that {@link JsonRpcApiProvider.send | **send**} may only be used once
     * {@link JsonRpcApiProvider.ready | **ready**}, otherwise the _send primitive must be used instead.
     *
     * @ignore
     * @returns {Promise<Network>} The detected network.
     * @throws {Error} If network detection fails.
     */
    _detectNetwork(): Promise<Network>;
    /**
     * Sub-classes **MUST** call this. Until {@link JsonRpcApiProvider._start | **_start**} has been called, no calls
     * will be passed to {@link JsonRpcApiProvider._send | **_send**} from {@link JsonRpcApiProvider.send | **send**} . If
     * it is overridden, then `super._start()` **MUST** be called.
     *
     * Calling it multiple times is safe and has no effect.
     *
     * @ignore
     */
    _start(): void;
    /**
     * Resolves once the {@link JsonRpcApiProvider._start | **_start**} has been called. This can be used in sub-classes
     * to defer sending data until the connection has been established.
     *
     * @ignore
     * @returns {Promise<void>} A promise that resolves once the provider is ready.
     */
    _waitUntilReady(): Promise<void>;
    /**
     * Return a Subscriber that will manage the `sub`.
     *
     * Sub-classes may override this to modify the behavior of subscription management.
     *
     * @ignore
     * @param {Subscription} sub - The subscription to manage.
     * @returns {Subscriber} The subscriber that will manage the subscription.
     */
    _getSubscriber(sub: Subscription): Subscriber;
    /**
     * Returns true only if the {@link JsonRpcApiProvider._start | **_start**} has been called.
     *
     * @returns {boolean} True if the provider is ready.
     */
    get ready(): boolean;
    /**
     * Returns `tx` as a normalized JSON-RPC transaction request, which has all values hexlified and any numeric values
     * converted to Quantity values.
     *
     * @ignore
     * @param {TransactionRequest} tx - The transaction to normalize.
     * @returns {JsonRpcTransactionRequest} The normalized transaction.
     * @throws {Error} If the transaction is invalid.
     */
    getRpcTransaction(tx: TransactionRequest): JsonRpcTransactionRequest;
    /**
     * Returns the request method and arguments required to perform `req`.
     *
     * @ignore
     * @param {PerformActionRequest} req - The request to perform.
     * @returns {null | { method: string; args: any[] }} The method and arguments to use.
     * @throws {Error} If the request is not supported or invalid.
     */
    getRpcRequest(req: PerformActionRequest): null | {
        method: string;
        args: Array<any>;
    };
    /**
     * Returns an quais-style Error for the given JSON-RPC error `payload`, coalescing the various strings and error
     * shapes that different nodes return, coercing them into a machine-readable standardized error.
     *
     * @ignore
     * @param {JsonRpcPayload} payload - The payload that was sent.
     * @param {JsonRpcError} _error - The error that was received.
     * @returns {Error} The coalesced error.
     */
    getRpcError(payload: JsonRpcPayload, _error: JsonRpcError, shard?: Shard): Error;
    /**
     * Requests the `method` with `params` via the JSON-RPC protocol over the underlying channel. This can be used to
     * call methods on the backend that do not have a high-level API within the Provider API.
     *
     * This method queues requests according to the batch constraints in the options, assigns the request a unique ID.
     *
     * **Do NOT override** this method in sub-classes; instead override {@link JsonRpcApiProvider._send | **_send**} or
     * force the options values in the call to the constructor to modify this method's behavior.
     *
     * @param {string} method - The method to call.
     * @param {any[] | Record<string, any>} params - The parameters to pass to the method.
     * @param {Shard} shard - The shard to send the request to.
     * @param {boolean} now - If true, the request will be sent immediately.
     * @returns {Promise<any>} A promise that resolves to the result of the method call.
     */
    send(method: string, params: Array<any> | Record<string, any>, shard?: Shard, now?: boolean): Promise<any>;
    /**
     * Returns a JsonRpcSigner for the given address.
     *
     * @param {number | string} [address] - The address or index of the account.
     * @returns {Promise<JsonRpcSigner>} A promise that resolves to the JsonRpcSigner.
     * @throws {Error} If the account is invalid.
     */
    getSigner(address?: number | string): Promise<JsonRpcSigner>;
    /**
     * Returns a list of JsonRpcSigners for all accounts.
     *
     * @returns {Promise<JsonRpcSigner[]>} A promise that resolves to an array of JsonRpcSigners.
     */
    listAccounts(): Promise<Array<JsonRpcSigner>>;
    /**
     * Destroys the provider, stopping all processing and canceling all pending requests.
     */
    destroy(): void;
}
/**
 * The JsonRpcProvider is one of the most common Providers, which performs all operations over HTTP (or HTTPS) requests.
 *
 * Events are processed by polling the backend for the current block number; when it advances, all block-base events are
 * then checked for updates.
 *
 * @category Providers
 */
export declare class JsonRpcProvider extends JsonRpcApiProvider {
    constructor(urls?: string | string[] | FetchRequest, network?: Networkish, options?: JsonRpcApiProviderOptions);
    _getSubscriber(sub: Subscription): Subscriber;
    _getConnection(shard?: Shard): FetchRequest;
    send(method: string, params: Array<any> | Record<string, any>, shard?: Shard, now?: boolean): Promise<any>;
    _send(payload: JsonRpcPayload | Array<JsonRpcPayload>, shard?: Shard, now?: boolean): Promise<Array<JsonRpcResult | JsonRpcError>>;
}
//# sourceMappingURL=provider-jsonrpc.d.ts.map