/**
 * The available providers should suffice for most developers purposes, but the
 * {@link AbstractProvider | **AbstractProvider**} class has many features which enable sub-classing it for specific
 * purposes.
 */
import { Shard, Zone } from '../constants/index.js';
import { Outpoint, OutpointDeltas, TxInputJson, TxOutputJson } from '../transaction/utxo.js';
import { FetchRequest } from '../utils/index.js';
import type { txpoolContentResponse, txpoolInspectResponse } from './txpool.js';
import { Network } from './network.js';
import { Block, FeeData, Log, TransactionReceipt, TransactionResponse, QiPreparedTransactionRequest, QuaiPreparedTransactionRequest, QuaiTransactionRequest, AccessesFilter, ExternalTransactionResponse } from './provider.js';
import type { AddressLike } from '../address/index.js';
import type { BigNumberish } from '../utils/index.js';
import type { Listener } from '../utils/index.js';
import type { Networkish } from './network.js';
import type { BlockParams, LogParams, TransactionReceiptParams } from './formatting.js';
import type { BlockTag, EventFilter, Filter, FilterByBlockHash, NodeLocation, OrphanFilter, Provider, ProviderEvent, TransactionRequest } from './provider.js';
import { WorkObjectLike } from '../transaction/work-object.js';
import { AccessList } from '../transaction/index.js';
/**
 * The value passed to the {@link AbstractProvider._getSubscriber | **AbstractProvider._getSubscriber**} method.
 *
 * Only developers sub-classing {@link AbstractProvider | **AbstractProvider**} will care about this, if they are
 * modifying a low-level feature of how subscriptions operate.
 *
 * @category Providers
 */
export type Subscription = {
    type: 'close' | 'debug' | 'error' | 'finalized' | 'network' | 'safe';
    tag: string;
    zone?: Zone;
} | {
    type: 'block' | 'pending';
    tag: string;
    zone: Zone;
} | {
    type: 'transaction';
    tag: string;
    hash: string;
    zone: Zone;
} | {
    type: 'accesses';
    tag: string;
    filter: AccessesFilter;
    zone: Zone;
} | {
    type: 'qiTransaction';
    tag: string;
    hash: string;
    zone: Zone;
} | {
    type: 'event';
    tag: string;
    filter: EventFilter;
    zone: Zone;
} | {
    type: 'orphan';
    tag: string;
    filter: OrphanFilter;
    zone: Zone;
};
/**
 * A **Subscriber** manages a subscription.
 *
 * Only developers sub-classing {@link AbstractProvider | **AbstractProvider**} will care about this, if they are
 * modifying a low-level feature of how subscriptions operate.
 *
 * @category Providers
 */
export interface Subscriber {
    /**
     * Called initially when a subscriber is added the first time.
     */
    start(): void;
    /**
     * Called when there are no more subscribers to the event.
     */
    stop(): void;
    /**
     * Called when the subscription should pause.
     *
     * If `dropWhilePaused`, events that occur while paused should not be emitted
     * {@link Subscriber.resume | **Subscriber.resume**}.
     *
     * @param {boolean} [dropWhilePaused] - If `true`, events that occur while paused
     */
    pause(dropWhilePaused?: boolean): void;
    /**
     * Resume a paused subscriber.
     */
    resume(): void;
    /**
     * The frequency (in ms) to poll for events, if polling is used by the subscriber.
     *
     * For non-polling subscribers, this must return `undefined`.
     */
    pollingInterval?: number;
}
/**
 * An **UnmanagedSubscriber** is useful for events which do not require any additional management, such as `"debug"`
 * which only requires emit in synchronous event loop triggered calls.
 *
 * @category Providers
 */
export declare class UnmanagedSubscriber implements Subscriber {
    /**
     * The name of the event.
     */
    name: string;
    /**
     * Create a new UnmanagedSubscriber with `name`.
     *
     * @param {string} name - The name of the event.
     */
    constructor(name: string);
    start(): void;
    stop(): void;
    pause(dropWhilePaused?: boolean): void;
    resume(): void;
}
/**
 * A normalized filter used for {@link PerformActionRequest | **PerformActionRequest**} objects.
 *
 * @category Providers
 */
export type PerformActionFilter = {
    address?: string | Array<string>;
    topics?: Array<null | string | Array<string>>;
    fromBlock?: BlockTag;
    toBlock?: BlockTag;
    nodeLocation: NodeLocation;
} | {
    address?: string | Array<string>;
    topics?: Array<null | string | Array<string>>;
    blockHash?: string;
    nodeLocation: NodeLocation;
};
/**
 * A normalized transactions used for {@link PerformActionRequest | **PerformActionRequest**} objects.
 *
 * @category Providers
 */
export type PerformActionTransaction = QuaiPerformActionTransaction | QiPerformActionTransaction;
/**
 * @category Providers
 */
export interface QuaiPerformActionTransaction extends QuaiPreparedTransactionRequest {
    /**
     * The `to` address of the transaction.
     */
    to?: string;
    /**
     * The sender of the transaction.
     */
    from: string;
    [key: string]: any;
}
/**
 * @category Providers
 */
export interface QiPerformActionTransaction extends QiPreparedTransactionRequest {
    /**
     * The transaction type. Always 2 for UTXO transactions.
     */
    txType: number;
    /**
     * The `inputs` of the UTXO transaction.
     */
    txIn: Array<TxInputJson>;
    /**
     * The `outputs` of the UTXO transaction.
     */
    txOut: Array<TxOutputJson>;
    [key: string]: any;
}
/**
 * The {@link AbstractProvider | **AbstractProvider**} methods will normalize all values and pass this type to
 * {@link AbstractProvider._perform | **AbstractProvider._perform**}.
 *
 * @category Providers
 */
export type PerformActionRequest = {
    method: 'broadcastTransaction';
    signedTransaction: string;
    zone: Zone;
} | {
    method: 'call';
    transaction: PerformActionTransaction;
    blockTag: BlockTag;
    zone?: Zone;
} | {
    method: 'chainId';
    zone?: Zone;
} | {
    method: 'estimateGas';
    transaction: PerformActionTransaction;
    zone?: Zone;
} | {
    method: 'estimateFeeForQi';
    transaction: QiPerformActionTransaction;
    zone?: Zone;
} | {
    method: 'createAccessList';
    transaction: PerformActionTransaction;
    zone?: Zone;
} | {
    method: 'getBalance';
    address: string;
    blockTag: BlockTag;
    zone: Zone;
} | {
    method: 'getLockedBalance';
    address: string;
    zone: Zone;
} | {
    method: 'getOutpointsByAddress';
    address: string;
    zone: Zone;
} | {
    method: 'getBlock';
    blockTag: BlockTag;
    includeTransactions: boolean;
    shard: Shard;
} | {
    method: 'getBlock';
    blockHash: string;
    includeTransactions: boolean;
    shard: Shard;
} | {
    method: 'getBlockNumber';
    shard?: Shard;
} | {
    method: 'getCode';
    address: string;
    blockTag: BlockTag;
    zone: Zone;
} | {
    method: 'getGasPrice';
    txType: boolean;
    zone?: Zone;
} | {
    method: 'getLogs';
    filter: PerformActionFilter;
    zone: Zone;
} | {
    method: 'getStorage';
    address: string;
    position: bigint;
    blockTag: BlockTag;
    zone: Zone;
} | {
    method: 'getTransaction';
    hash: string;
    zone: Zone;
} | {
    method: 'getTransactionCount';
    address: string;
    blockTag: BlockTag;
    zone: Zone;
} | {
    method: 'getTransactionReceipt';
    hash: string;
    zone: Zone;
} | {
    method: 'getTransactionResult';
    hash: string;
    zone: Zone;
} | {
    method: 'getRunningLocations';
    shard?: Shard;
    now: boolean;
} | {
    method: 'getProtocolTrieExpansionCount';
    shard: Shard;
} | {
    method: 'getQiRateAtBlock';
    blockTag: BlockTag;
    amt: string;
    zone: Zone;
} | {
    method: 'getQuaiRateAtBlock';
    blockTag: BlockTag;
    amt: string;
    zone: Zone;
} | {
    method: 'getProtocolExpansionNumber';
} | {
    method: 'getPendingHeader';
} | {
    method: 'getTxPoolContent';
    zone: Zone;
} | {
    method: 'txPoolInspect';
    zone: Zone;
} | {
    method: 'getOutpointDeltasForAddressesInRange';
    addresses: string[];
    startHash: string;
    endHash: string;
    zone: Zone;
};
/**
 * Options for configuring some internal aspects of an {@link AbstractProvider | **AbstractProvider**}.
 *
 * **`cacheTimeout`** - how long to cache a low-level `_perform` for, based on input parameters. This reduces the number
 * of calls to getChainId and getBlockNumber, but may break test chains which can perform operations (internally)
 * synchronously. Use `-1` to disable, `0` will only buffer within the same event loop and any other value is in ms.
 * (default: `250`)
 *
 * @category Providers
 */
export type AbstractProviderOptions = {
    cacheTimeout?: number;
    pollingInterval?: number;
    usePathing?: boolean;
};
/**
 * An **AbstractProvider** provides a base class for other sub-classes to implement the {@link Provider | **Provider**}
 * API by normalizing input arguments and formatting output results as well as tracking events for consistent behaviour
 * on an eventually-consistent network.
 *
 * @category Providers
 */
export declare class AbstractProvider<C = FetchRequest> implements Provider {
    #private;
    /**
     * @ignore
     */
    _urlMap: Map<Shard, C>;
    _initFailed: boolean;
    initResolvePromise: null | ((value: void) => void);
    initRejectPromise: null | ((reason?: any) => void);
    initPromise: Promise<void>;
    attemptConnect: boolean;
    /**
     * Create a new **AbstractProvider** connected to `network`, or use the various network detection capabilities to
     * discover the {@link Network | **Network**} if necessary.
     *
     * @param _network - The network to connect to, or `"any"` to
     * @param options - The options to configure the provider.
     */
    constructor(_network?: 'any' | Networkish, options?: AbstractProviderOptions);
    /**
     * Initialize the URL map with the provided URLs.
     *
     * @param {U} urls - The URLs to initialize the map with.
     * @returns {Promise<void>} A promise that resolves when the map is initialized.
     */
    initialize<U = string[] | FetchRequest>(urls: U): Promise<void>;
    /**
     * Get the list of connected FetchRequests.
     *
     * @returns {FetchRequest[]} The list of connected FetchRequests.
     */
    get connect(): FetchRequest[];
    /**
     * Get the zone from an address.
     *
     * @param {AddressLike} _address - The address to get the zone from.
     * @returns {Promise<Zone>} A promise that resolves to the zone.
     */
    zoneFromAddress(_address: AddressLike): Promise<Zone>;
    /**
     * Get the shard from a hash.
     *
     * @param {string} hash - The hash to get the shard from.
     * @returns {Shard} The shard.
     */
    shardFromHash(hash: string): Shard;
    /**
     * Get the zone from a hash.
     *
     * @param {string} hash - The hash to get the zone from.
     * @returns {Zone} The zone.
     */
    zoneFromHash(hash: string): Zone;
    /**
     * Get the latest Quai rate for a zone.
     *
     * @param {Zone} zone - The zone to get the rate for.
     * @param {number} [amt=1] - The amount in quais to get the rate for. Default is `1`
     * @returns {Promise<bigint>} A promise that resolves to the latest Quai -> Qi rate for the given amount.
     */
    getLatestQuaiRate(zone: Zone, amt: bigint): Promise<bigint>;
    /**
     * Get the Quai rate at a specific block.
     *
     * @param {Zone} zone - The zone to get the rate for.
     * @param {BlockTag} blockTag - The block tag to get the rate at.
     * @param {number} [amt=1] - The amount to get the rate for. Default is `1`
     * @returns {Promise<bigint>} A promise that resolves to the Quai rate at the specified block.
     */
    getQuaiRateAtBlock(zone: Zone, blockTag: BlockTag, amt: bigint): Promise<bigint>;
    /**
     * Get the protocol expansion number.
     *
     * @returns {Promise<number>} A promise that resolves to the protocol expansion number.
     */
    getProtocolExpansionNumber(): Promise<number>;
    /**
     * Get the active region shards based on the protocol expansion number.
     *
     * @returns {Promise<Shard[]>} A promise that resolves to the active shards.
     */
    getActiveRegions(): Promise<Shard[]>;
    /**
     * Get the active zones for a shard based on the protocol expansion number.
     *
     * @returns {Promise<Zone[]>} A promise that resolves to the active zones.
     */
    getActiveZones(): Promise<Zone[]>;
    /**
     * Get the latest Qi rate for a zone.
     *
     * @param {Zone} zone - The zone to get the rate for.
     * @param {number} [amt=1] - The amount to get the rate for. Default is `1`
     * @returns {Promise<bigint>} A promise that resolves to the latest Qi rate.
     */
    getLatestQiRate(zone: Zone, amt: bigint): Promise<bigint>;
    /**
     * Get the Qi rate at a specific block.
     *
     * @param {Zone} zone - The zone to get the rate for.
     * @param {BlockTag} blockTag - The block tag to get the rate at.
     * @param {number} [amt=1] - The amount to get the rate for. Default is `1`
     * @returns {Promise<bigint>} A promise that resolves to the Qi rate at the specified block.
     */
    getQiRateAtBlock(zone: Zone, blockTag: BlockTag, amt: bigint): Promise<bigint>;
    /**
     * Get the polling interval.
     *
     * @returns {number} The polling interval.
     */
    get pollingInterval(): number;
    /**
     * Returns `this`, to allow an **AbstractProvider** to implement the [Contract Runner](../classes/ContractRunner)
     * interface.
     *
     * @returns {this} The provider instance.
     */
    get provider(): this;
    /**
     * Provides the opportunity for a sub-class to wrap a block before returning it, to add additional properties or an
     * alternate sub-class of {@link Block | **Block**}.
     *
     * @ignore
     * @param {BlockParams} value - The block to wrap.
     * @param {Network} network - The network the block was on.
     * @returns {Block} The wrapped block.
     */
    _wrapBlock(value: BlockParams, network: Network): Block;
    /**
     * Provides the opportunity for a sub-class to wrap a log before returning it, to add additional properties or an
     * alternate sub-class of {@link Log | **Log**}.
     *
     * @ignore
     * @param {LogParams} value - The log to wrap.
     * @param {Network} network - The network the log was on.
     * @returns {Log} The wrapped log.
     */
    _wrapLog(value: LogParams, network: Network): Log;
    /**
     * Provides the opportunity for a sub-class to wrap a transaction receipt before returning it, to add additional
     * properties or an {@link TransactionReceipt | **TransactionReceipt**}.
     *
     * @ignore
     * @param {TransactionReceiptParams} value - The transaction receipt to wrap.
     * @param {Network} network - The network the transaction was on.
     * @returns {TransactionReceipt} The wrapped transaction receipt.
     */
    _wrapTransactionReceipt(value: TransactionReceiptParams, network: Network): TransactionReceipt;
    /**
     * Provides the opportunity for a sub-class to wrap a transaction response before returning it, to add additional
     * properties or an alternate sub-class of {@link TransactionResponse | **TransactionResponse**}.
     *
     * @ignore
     * @param {TransactionResponseParams} tx - The transaction response to wrap.
     * @param {Network} network - The network the transaction was on.
     * @returns {TransactionResponse} The wrapped transaction response.
     */
    _wrapTransactionResponse(tx: any, network: Network): TransactionResponse | ExternalTransactionResponse;
    /**
     * Resolves to the Network, forcing a network detection using whatever technique the sub-class requires.
     *
     * Sub-classes **must** override this.
     *
     * @ignore
     * @param {Shard} [shard] - The shard to use for the network detection.
     * @returns {Promise<Network>} A promise resolving to the network.
     */
    _detectNetwork(): Promise<Network>;
    /**
     * Sub-classes should use this to perform all built-in operations. All methods sanitizes and normalizes the values
     * passed into this.
     *
     * Sub-classes **must** override this.
     *
     * @ignore
     * @param {PerformActionRequest} req - The request to perform.
     * @returns {Promise<T>} A promise resolving to the result of the operation.
     */
    _perform<T = any>(req: PerformActionRequest): Promise<T>;
    getBlockNumber(shard: Shard): Promise<number>;
    /**
     * Returns or resolves to the address for `address`, resolving {@link Addressable | **Addressable**} objects and
     * returning if already an address.
     *
     * @ignore
     * @param {AddressLike} address - The address to normalize.
     * @returns {string | Promise<string>} The normalized address.
     */
    _getAddress(address: AddressLike): string | Promise<string>;
    /**
     * Returns or resolves to a valid block tag for `blockTag`, resolving negative values and returning if already a
     * valid block tag.
     *
     * @ignore
     * @param {Shard} [shard] - The shard to use for the block tag.
     * @param {BlockTag} [blockTag] - The block tag to normalize.
     * @returns {string | Promise<string>} A promise that resolves to a valid block tag.
     */
    _getBlockTag(shard: Shard, blockTag?: BlockTag): string | Promise<string>;
    /**
     * Returns or resolves to a filter for `filter`, resolving any {@link Addressable | **Addressable**} object and
     * returning if already a valid filter.
     *
     * @ignore
     * @param {Filter | FilterByBlockHash} filter - The filter to normalize.
     * @returns {PerformActionFilter | Promise<PerformActionFilter>} A promise that resolves to a valid filter.
     */
    _getFilter(filter: Filter | FilterByBlockHash): PerformActionFilter | Promise<PerformActionFilter>;
    /**
     * Returns or resovles to a transaction for `request`, resolving any {@link Addressable | **Addressable**} and
     * returning if already a valid transaction.
     *
     * @ignore
     * @param {PerformActionTransaction} _request - The transaction to normalize.
     * @returns {PerformActionTransaction | Promise<PerformActionTransaction>} A promise that resolves to a valid
     *   transaction.
     */
    _getTransactionRequest(_request: TransactionRequest): PerformActionTransaction | Promise<PerformActionTransaction>;
    getNetwork(): Promise<Network>;
    protected _waitGetRunningLocations(shard: Shard, now: boolean): Promise<number[][]>;
    protected _getRunningLocations(shard?: Shard, now?: boolean): Promise<number[][]>;
    getRunningLocations(shard?: Shard): Promise<number[][]>;
    getProtocolTrieExpansionCount(shard: Shard): Promise<number>;
    getFeeData(zone?: Zone, txType?: boolean): Promise<FeeData>;
    estimateGas(_tx: TransactionRequest): Promise<bigint>;
    estimateFeeForQi(_tx: QiPerformActionTransaction): Promise<bigint>;
    createAccessList(_tx: TransactionRequest): Promise<AccessList>;
    call(_tx: QuaiTransactionRequest): Promise<string>;
    getBalance(address: AddressLike, blockTag?: BlockTag): Promise<bigint>;
    getLockedBalance(address: AddressLike): Promise<bigint>;
    getOutpointsByAddress(address: AddressLike): Promise<Outpoint[]>;
    getTransactionCount(address: AddressLike, blockTag?: BlockTag): Promise<number>;
    getCode(address: AddressLike, blockTag?: BlockTag): Promise<string>;
    getStorage(address: AddressLike, _position: BigNumberish, blockTag?: BlockTag): Promise<string>;
    getPendingHeader(): Promise<WorkObjectLike>;
    getTxPoolContent(zone: Zone): Promise<txpoolContentResponse>;
    txPoolInspect(zone: Zone): Promise<txpoolInspectResponse>;
    broadcastTransaction(zone: Zone, signedTx: string): Promise<TransactionResponse>;
    validateUrl(url: string): void;
    getBlock(shard: Shard, block: BlockTag | string, prefetchTxs?: boolean): Promise<null | Block>;
    getTransaction(hash: string): Promise<null | TransactionResponse | ExternalTransactionResponse>;
    getTransactionReceipt(hash: string): Promise<null | TransactionReceipt>;
    getTransactionResult(hash: string): Promise<null | string>;
    getOutpointDeltas(addresses: string[], startHash: string, endHash?: string): Promise<OutpointDeltas>;
    getLogs(_filter: Filter | FilterByBlockHash): Promise<Array<Log>>;
    /**
     * @ignore
     */
    _getProvider(chainId: number): AbstractProvider;
    waitForTransaction(hash: string, _confirms?: null | number, timeout?: null | number): Promise<null | TransactionReceipt>;
    waitForBlock(shard: Shard, blockTag?: BlockTag): Promise<Block>;
    /**
     * Clear a timer created using the {@link AbstractProvider._setTimeout | **_setTimeout**} method.
     *
     * @param {number} timerId - The ID of the timer to clear.
     */
    _clearTimeout(timerId: number): void;
    /**
     * Create a timer that will execute `func` after at least `timeout` (in ms). If `timeout` is unspecified, then
     * `func` will execute in the next event loop.
     *
     * {@link AbstractProvider.pause | **Pausing**} the provider will pause any associated timers.
     *
     * @ignore
     * @ignore
     * @param {() => void} _func - The function to execute.
     * @param {number} [timeout] - The time to wait before executing `func`.
     * @returns {number} The ID of the timer.
     */
    _setTimeout(_func: () => void, timeout?: number): number;
    /**
     * Perform `func` on each subscriber.
     *
     * @ignore
     * @param {(s: Subscriber) => void} func - The function to perform.
     */
    _forEachSubscriber(func: (s: Subscriber) => void): void;
    /**
     * Sub-classes may override this to customize subscription implementations.
     *
     * @ignore
     * @param {Subscription} sub - The subscription to get the subscriber for.
     */
    _getSubscriber(sub: Subscription): Subscriber;
    /**
     * If a {@link Subscriber | **Subscriber**} fails and needs to replace itself, this method may be used.
     *
     * For example, this is used for providers when using the `quai_getFilterChanges` method, which can return null if
     * state filters are not supported by the backend, allowing the Subscriber to swap in a `PollingEventSubscriber`.
     *
     * @ignore
     * @param {Subscriber} oldSub - The subscriber to replace.
     * @param {Subscriber} newSub - The new subscriber.
     */
    _recoverSubscriber(oldSub: Subscriber, newSub: Subscriber): void;
    startZoneSubscriptions(zone: Zone): Promise<void>;
    on(event: ProviderEvent, listener: Listener, zone?: Zone): Promise<this>;
    once(event: ProviderEvent, listener: Listener, zone?: Zone): Promise<this>;
    emit(event: ProviderEvent, zone?: Zone, ...args: Array<any>): Promise<boolean>;
    listenerCount(event?: ProviderEvent): Promise<number>;
    listeners(event?: ProviderEvent): Promise<Array<Listener>>;
    off(event: ProviderEvent, listener?: Listener, zone?: Zone): Promise<this>;
    removeAllListeners(event?: ProviderEvent): Promise<this>;
    addListener(event: ProviderEvent, listener: Listener, zone?: Zone): Promise<this>;
    removeListener(event: ProviderEvent, listener: Listener, zone?: Zone): Promise<this>;
    /**
     * If this provider has been destroyed using the {@link AbstractProvider.destroy | **destroy**} method.
     *
     * Once destroyed, all resources are reclaimed, internal event loops and timers are cleaned up and no further
     * requests may be sent to the provider.
     */
    get destroyed(): boolean;
    /**
     * Sub-classes may use this to shutdown any sockets or release their resources and reject any pending requests.
     *
     * Sub-classes **must** call `super.destroy()`.
     */
    destroy(): void;
    /**
     * Whether the provider is currently paused.
     *
     * A paused provider will not emit any events, and generally should not make any requests to the network, but that
     * is up to sub-classes to manage.
     *
     * Setting `paused = true` is identical to calling `.pause(false)`, which will buffer any events that occur while
     * paused until the provider is unpaused.
     *
     * @returns {boolean} Whether the provider is paused.
     */
    get paused(): boolean;
    set paused(pause: boolean);
    /**
     * Pause the provider. If `dropWhilePaused`, any events that occur while paused are dropped, otherwise all events
     * will be emitted once the provider is unpaused.
     *
     * @param {boolean} [dropWhilePaused] - Whether to drop events while paused.
     */
    pause(dropWhilePaused?: boolean): void;
    /**
     * Resume the provider.
     */
    resume(): void;
}
//# sourceMappingURL=abstract-provider.d.ts.map