import { SocketProvider } from './provider-socket.js';
import type { JsonRpcApiProviderOptions } from './provider-jsonrpc.js';
import type { Networkish } from './network.js';
import { Shard } from '../constants/index.js';
/**
 * A generic interface to a Websocket-like object.
 *
 * @category Providers
 */
export interface WebSocketLike {
    onopen: null | ((...args: Array<any>) => any);
    onmessage: null | ((...args: Array<any>) => any);
    onerror: null | ((...args: Array<any>) => any);
    onclose: null | ((...args: Array<any>) => any);
    readyState: number;
    get url(): string;
    send(payload: any): void;
    close(code?: number, reason?: string): void;
}
/**
 * A function which can be used to re-create a WebSocket connection on disconnect.
 *
 * @category Providers
 */
export type WebSocketCreator = () => WebSocketLike;
/**
 * A JSON-RPC provider which is backed by a WebSocket.
 *
 * WebSockets are often preferred because they retain a live connection to a server, which permits more instant access
 * to events.
 *
 * However, this incurs higher server infrastructure costs, so additional resources may be required to host your own
 * WebSocket nodes and many third-party services charge additional fees for WebSocket endpoints.
 *
 * @category Providers
 * @extends SocketProvider
 */
export declare class WebSocketProvider extends SocketProvider {
    #private;
    /**
     * A map to track the readiness of each shard.
     *
     * @type {Map<Shard, boolean>}
     */
    readyMap: Map<Shard, boolean>;
    /**
     * Get the array of WebSocketLike objects.
     *
     * @returns {WebSocketLike[]} The array of WebSocketLike objects.
     * @throws {Error} If the websocket is closed.
     */
    get websocket(): WebSocketLike[];
    /**
     * Create a new WebSocketProvider.
     *
     * @param {string | string[] | WebSocketLike | WebSocketCreator} url - The URL(s) or WebSocket object or creator.
     * @param {Networkish} [network] - The network to connect to.
     * @param {JsonRpcApiProviderOptions} [options] - The options for the JSON-RPC API provider.
     */
    constructor(url: string | string[] | WebSocketLike | WebSocketCreator, network?: Networkish, options?: JsonRpcApiProviderOptions);
    /**
     * Initialize a WebSocket connection for a shard.
     *
     * @ignore
     * @param {WebSocketLike} websocket - The WebSocket object.
     * @param {Shard} shard - The shard identifier.
     */
    initWebSocket(websocket: WebSocketLike, shard: Shard, port: number): void;
    /**
     * Wait until the shard is ready. Max wait time is ~8 seconds.
     *
     * @param {Shard} shard - The shard identifier.
     * @returns {Promise<void>} A promise that resolves when the shard is ready.
     * @throws {Error} If the shard is not ready within the timeout period.
     */
    waitShardReady(shard: Shard): Promise<void>;
    createWebSocket: (baseUrl: string, suffix: string) => WebSocketLike;
    /**
     * Initialize the URL map with WebSocket connections.
     *
     * @ignore
     * @param {U} urls - The URLs or WebSocket object or creator.
     * @returns {Promise<void>} A promise that resolves when the URL map is initialized.
     */
    initialize<U = string[] | WebSocketLike | WebSocketCreator>(urls: U): Promise<void>;
    /**
     * Write a message to the WebSocket.
     *
     * @ignore
     * @param {string} message - The message to send.
     * @param {Shard} [shard] - The shard identifier.
     * @returns {Promise<void>} A promise that resolves when the message is sent.
     * @throws {Error} If the WebSocket is closed or the shard is not found.
     */
    _write(message: string, shard?: Shard): Promise<void>;
    /**
     * Destroy the WebSocket connections and clean up resources.
     *
     * @returns {Promise<void>} A promise that resolves when the WebSocket connections are closed.
     */
    destroy(): Promise<void>;
}
//# sourceMappingURL=provider-websocket.d.ts.map