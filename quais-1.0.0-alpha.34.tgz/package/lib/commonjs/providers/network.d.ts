/**
 * A **Network** encapsulates the various properties required to interact with a specific chain.
 *
 * @category Providers
 */
import type { BigNumberish } from '../utils/index.js';
/**
 * A Networkish can be used to allude to a Network, by specifying:
 *
 * - A {@link Network} object
 * - A well-known (or registered) network name
 * - A well-known (or registered) chain ID
 * - An object with sufficient details to describe a network
 *
 * @category Providers
 */
export type Networkish = Network | number | bigint | string | {
    name?: string;
    chainId?: number;
};
/**
 * A **Network** provides access to a chain's properties and allows for plug-ins to extend functionality.
 *
 * @category Providers
 */
export declare class Network {
    #private;
    /**
     * Creates a new **Network** for `name` and `chainId`.
     *
     * @param {string} name - The network name.
     * @param {BigNumberish} chainId - The network chain ID.
     */
    constructor(name: string, chainId: BigNumberish);
    /**
     * Returns a JSON-compatible representation of a Network.
     *
     * @returns {Object} The JSON representation of the network.
     */
    toJSON(): any;
    /**
     * The network common name.
     *
     * This is the canonical name, as networks might have multiple names.
     *
     * @returns {string} The network name.
     */
    get name(): string;
    /**
     * Sets the network name.
     *
     * @param {string} value - The new network name.
     */
    set name(value: string);
    /**
     * The network chain ID.
     *
     * @returns {bigint} The network chain ID.
     */
    get chainId(): bigint;
    /**
     * Sets the network chain ID.
     *
     * @param {BigNumberish} value - The new network chain ID.
     */
    set chainId(value: BigNumberish);
    /**
     * Returns true if `other` matches this network. Any chain ID must match, and if no chain ID is present, the name
     * must match.
     *
     * This method does not currently check for additional properties, such as plug-in compatibility.
     *
     * @ignore
     * @param {Networkish} other - The network to compare.
     * @returns {boolean} True if the networks match.
     */
    matches(other: Networkish): boolean;
    /**
     * Create a copy of this Network.
     *
     * @returns {Network} A new Network instance.
     */
    clone(): Network;
    /**
     * Returns a new Network for the `network` name or chainId.
     *
     * @param {Networkish} [network] - The network to get.
     * @returns {Network} The Network instance.
     * @throws {Error} If the network is invalid.
     */
    static from(network?: Networkish): Network;
    /**
     * Register `nameOrChainId` with a function which returns an instance of a Network representing that chain.
     *
     * @param {string | number | bigint} nameOrChainId - The name or chain ID to register.
     * @param {() => Network} networkFunc - The function to create the Network.
     * @throws {Error} If a network is already registered for `nameOrChainId`.
     */
    static register(nameOrChainId: string | number | bigint, networkFunc: () => Network): void;
}
//# sourceMappingURL=network.d.ts.map