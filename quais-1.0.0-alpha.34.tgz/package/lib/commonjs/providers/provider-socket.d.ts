import { JsonRpcApiProvider } from './provider-jsonrpc.js';
import type { Subscriber, Subscription } from './abstract-provider.js';
import type { AccessesFilter, EventFilter } from './provider.js';
import type { JsonRpcApiProviderOptions, JsonRpcError, JsonRpcPayload, JsonRpcResult } from './provider-jsonrpc.js';
import type { Networkish } from './network.js';
import type { WebSocketLike } from './provider-websocket.js';
import { Shard, Zone } from '../constants/index.js';
/**
 * A **SocketSubscriber** uses a socket transport to handle events and should use
 * {@link SocketSubscriber._emit | **_emit**} to manage the events.
 *
 * - A sub-class MUST call the `_start()` method once connected
 * - A sub-class MUST override the `_write(string)` method
 * - A sub-class MUST call `_processMessage(string)` for each message
 *
 * @category Providers
 */
export declare class SocketSubscriber implements Subscriber {
    #private;
    /**
     * The filter.
     *
     * @type {any[]}
     */
    get filter(): Array<any>;
    protected zone: Zone;
    protected shard: Shard;
    /**
     * Creates a new **SocketSubscriber** attached to `provider` listening to `filter`.
     *
     * @param {SocketProvider} provider - The socket provider.
     * @param {any[]} filter - The filter.
     */
    constructor(provider: SocketProvider, filter: Array<any>, zone: Zone);
    /**
     * Start the subscriber.
     */
    start(): void;
    /**
     * Stop the subscriber.
     */
    stop(): void;
    /**
     * Pause the subscriber.
     *
     * @param {boolean} [dropWhilePaused] - Whether to drop logs while paused.
     */
    pause(dropWhilePaused?: boolean): void;
    /**
     * Resume the subscriber.
     */
    resume(): void;
    /**
     * Handle incoming messages.
     *
     * @ignore
     * @param {any} message - The message to handle.
     */
    _handleMessage(message: any): void;
    /**
     * Sub-classes **must** override this to emit the events on the provider.
     *
     * @abstract
     * @param {SocketProvider} provider - The socket provider.
     * @param {any} message - The message to emit.
     * @returns {Promise<void>}
     */
    _emit(provider: SocketProvider, message: any): Promise<void>;
}
/**
 * A **SocketBlockSubscriber** listens for `newHeads` events and emits `"block"` events.
 *
 * @category Providers
 */
export declare class SocketBlockSubscriber extends SocketSubscriber {
    /**
     * Creates a new **SocketBlockSubscriber**.
     *
     * @ignore
     * @param {SocketProvider} provider - The socket provider.
     */
    constructor(provider: SocketProvider, zone: Zone);
    /**
     * Emit the block event.
     *
     * @ignore
     * @param {SocketProvider} provider - The socket provider.
     * @param {any} message - The message to emit.
     * @returns {Promise<void>}
     */
    _emit(provider: SocketProvider, message: any): Promise<void>;
}
/**
 * A **SocketAccessesSubscriber** listens for `acceses` events and emits `accesses` events.
 *
 * @category Providers
 */
export declare class SocketAccessesSubscriber extends SocketSubscriber {
    #private;
    get accessesFilter(): AccessesFilter;
    /**
     * Creates a new **SocketBlockSubscriber**.
     *
     * @ignore
     * @param {SocketProvider} provider - The socket provider.
     * @param filter
     * @param zone
     */
    constructor(provider: SocketProvider, filter: AccessesFilter, zone: Zone);
    /**
     * Emit the block event.
     *
     * @ignore
     * @param {SocketProvider} provider - The socket provider.
     * @param {any} message - The message to emit.
     * @returns {Promise<void>}
     */
    _emit(provider: SocketProvider, message: any): Promise<void>;
}
/**
 * A **SocketPendingSubscriber** listens for pending transactions and emits `"pending"` events.
 *
 * @category Providers
 */
export declare class SocketPendingSubscriber extends SocketSubscriber {
    /**
     * Creates a new **SocketPendingSubscriber**.
     *
     * @ignore
     * @param {SocketProvider} provider - The socket provider.
     */
    constructor(provider: SocketProvider, zone: Zone);
    /**
     * Emit the pending event.
     *
     * @ignore
     * @param {SocketProvider} provider - The socket provider.
     * @param {any} message - The message to emit.
     * @returns {Promise<void>}
     */
    _emit(provider: SocketProvider, message: any): Promise<void>;
}
/**
 * A **SocketEventSubscriber** listens for event logs.
 *
 * @category Providers
 */
export declare class SocketEventSubscriber extends SocketSubscriber {
    #private;
    /**
     * The filter.
     *
     * @type {EventFilter}
     */
    get logFilter(): EventFilter;
    /**
     * Creates a new **SocketEventSubscriber**.
     *
     * @ignore
     * @param {SocketProvider} provider - The socket provider.
     * @param {EventFilter} filter - The event filter.
     */
    constructor(provider: SocketProvider, filter: EventFilter, zone: Zone);
    /**
     * Emit the event log.
     *
     * @ignore
     * @param {SocketProvider} provider - The socket provider.
     * @param {any} message - The message to emit.
     * @returns {Promise<void>}
     */
    _emit(provider: SocketProvider, message: any): Promise<void>;
}
/**
 * A **SocketProvider** is backed by a long-lived connection over a socket, which can subscribe and receive real-time
 * messages over its communication channel.
 *
 * @category Providers
 */
export declare class SocketProvider extends JsonRpcApiProvider<WebSocketLike> {
    #private;
    /**
     * Creates a new **SocketProvider** connected to `network`.
     *
     * If unspecified, the network will be discovered.
     *
     * @param {Networkish} [network] - The network to connect to.
     * @param {JsonRpcApiProviderOptions} [_options] - The options for the provider.
     */
    constructor(network?: Networkish, _options?: JsonRpcApiProviderOptions);
    /**
     * Get the subscriber for a given subscription.
     *
     * @ignore
     * @param {Subscription} sub - The subscription.
     * @returns {Subscriber} The subscriber.
     */
    _getSubscriber(sub: Subscription): Subscriber;
    /**
     * Register a new subscriber. This is used internally by Subscribers and generally is unnecessary unless extending
     * capabilities.
     *
     * @ignore
     * @param {number | string} filterId - The filter ID.
     * @param {SocketSubscriber} subscriber - The subscriber.
     */
    _register(filterId: number | string, subscriber: SocketSubscriber): void;
    /**
     * Send a JSON-RPC payload.
     *
     * @ignore
     * @param {JsonRpcPayload | JsonRpcPayload[]} payload - The payload to send.
     * @param {Shard} [shard] - The shard.
     * @param {boolean} [now] - Whether to send immediately.
     * @returns {Promise<(JsonRpcResult | JsonRpcError)[]>} The result or error.
     */
    _send(payload: JsonRpcPayload | Array<JsonRpcPayload>, shard?: Shard, now?: boolean): Promise<Array<JsonRpcResult | JsonRpcError>>;
    /**
     * Sub-classes **must** call this with messages received over their transport to be processed and dispatched.
     *
     * @ignore
     * @param {string} message - The message to process.
     */
    _processMessage(message: string): Promise<void>;
    /**
     * Sub-classes **must** override this to send `message` over their transport.
     *
     * @ignore
     * @param {string} message - The message to send.
     * @param {Shard} [shard] - The shard.
     * @returns {Promise<void>}
     */
    _write(message: string, shard?: Shard): Promise<void>;
    validateUrl(url: string): void;
}
//# sourceMappingURL=provider-socket.d.ts.map