import { Zone } from '../constants/zones.js';
import type { Subscriber } from './abstract-provider.js';
import type { Provider } from './provider.js';
/**
 * Interface for Connection RPC Provider.
 *
 * @category Providers
 * @interface
 */
export interface ConnectionRpcProvider extends Provider {
    /**
     * Subscribe to a specific event.
     *
     * @ignore
     * @param {any[]} param - The parameters for the subscription.
     * @param {function(any): void} processFunc - The function to process the result.
     * @returns {number} The subscription ID.
     */
    _subscribe(param: Array<any>, processFunc: (result: any) => void): number;
    /**
     * Unsubscribe from a specific event.
     *
     * @ignore
     * @param {number} filterId - The subscription ID to unsubscribe.
     * @returns {void}
     */
    _unsubscribe(filterId: number): void;
}
/**
 * Class for subscribing to block connections.
 *
 * @category Providers
 * @class
 * @implements {Subscriber}
 */
export declare class BlockConnectionSubscriber implements Subscriber {
    #private;
    /**
     * @ignore
     * @class
     * @param {ConnectionRpcProvider} provider - The provider for the connection.
     */
    constructor(provider: ConnectionRpcProvider, zone: Zone);
    /**
     * Start the block connection subscription.
     *
     * @returns {void}
     */
    start(): void;
    /**
     * Stop the block connection subscription.
     *
     * @returns {void}
     */
    stop(): void;
    /**
     * Pause the block connection subscription.
     *
     * @param {boolean} [dropWhilePaused=false] - Whether to drop blocks while paused. Default is `false`
     * @returns {void}
     */
    pause(dropWhilePaused?: boolean): void;
    /**
     * Resume the block connection subscription.
     *
     * @returns {void}
     */
    resume(): void;
}
//# sourceMappingURL=subscriber-connection.d.ts.map