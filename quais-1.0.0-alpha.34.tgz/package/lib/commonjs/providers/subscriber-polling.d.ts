import { Zone } from '../constants/index.js';
import { type EventFilter, type OrphanFilter, type ProviderEvent } from './provider.js';
import type { AbstractProvider, Subscriber } from './abstract-provider.js';
/**
 * Return the polling subscriber for common events.
 *
 * @category Providers
 * @param {AbstractProvider} provider - The provider to attach the subscriber to.
 * @param {ProviderEvent} event - The event to subscribe to.
 * @returns {Subscriber} The polling subscriber.
 * @throws {Error} If the event is unsupported.
 */
export declare function getPollingSubscriber(provider: AbstractProvider, event: ProviderEvent, zone: Zone): Subscriber;
/**
 * A **PollingBlockSubscriber** polls at a regular interval for a change in the block number.
 *
 * @category Providers
 */
export declare class PollingBlockSubscriber implements Subscriber {
    #private;
    /**
     * Create a new **PollingBlockSubscriber** attached to `provider`.
     *
     * @ignore
     */
    constructor(provider: AbstractProvider, zone: Zone);
    /**
     * The polling interval.
     *
     * @returns {number} The current polling interval.
     */
    get pollingInterval(): number;
    /**
     * Sets the polling interval.
     *
     * @param {number} value - The new polling interval.
     */
    set pollingInterval(value: number);
    /**
     * Starts the polling process.
     */
    start(): void;
    /**
     * Stops the polling process.
     */
    stop(): void;
    /**
     * Pauses the polling process.
     *
     * @param {boolean} [dropWhilePaused] - Whether to drop the block number while paused.
     */
    pause(dropWhilePaused?: boolean): void;
    /**
     * Resumes the polling process.
     */
    resume(): void;
}
/**
 * An **OnBlockSubscriber** can be sub-classed, with a {@link OnBlockSubscriber._poll | **_poll**} implementation which
 * will be called on every new block.
 *
 * @category Providers
 */
export declare class OnBlockSubscriber implements Subscriber {
    #private;
    /**
     * Create a new **OnBlockSubscriber** attached to `provider`.
     *
     * @ignore
     */
    constructor(provider: AbstractProvider, zone: Zone);
    /**
     * Called on every new block.
     *
     * @ignore
     * @param {number} blockNumber - The block number.
     * @param {AbstractProvider} provider - The provider.
     * @returns {Promise<void>} A promise that resolves when the poll is complete.
     * @throws {Error} If the method is not overridden by a subclass.
     */
    _poll(blockNumber: number, provider: AbstractProvider): Promise<void>;
    /**
     * Starts the subscriber.
     */
    start(): void;
    /**
     * Stops the subscriber.
     */
    stop(): void;
    /**
     * Pauses the subscriber.
     *
     * @param {boolean} [dropWhilePaused] - Whether to drop the block number while paused.
     */
    pause(dropWhilePaused?: boolean): void;
    /**
     * Resumes the subscriber.
     */
    resume(): void;
}
/**
 * @ignore
 */
export declare class PollingOrphanSubscriber extends OnBlockSubscriber {
    #private;
    /**
     * Create a new **PollingOrphanSubscriber** attached to `provider`, listening for `filter`.
     *
     * @ignore
     */
    constructor(provider: AbstractProvider, filter: OrphanFilter, zone: Zone);
    /**
     * Polls for orphaned blocks.
     *
     * @ignore
     * @param {number} blockNumber - The block number.
     * @param {AbstractProvider} provider - The provider.
     * @returns {Promise<void>} A promise that resolves when the poll is complete.
     * @throws {Error} If the method is not implemented.
     */
    _poll(blockNumber: number, provider: AbstractProvider): Promise<void>;
}
/**
 * A **PollingTransactionSubscriber** will poll for a given transaction hash for its receipt.
 *
 * @category Providers
 */
export declare class PollingTransactionSubscriber extends OnBlockSubscriber {
    #private;
    /**
     * Create a new **PollingTransactionSubscriber** attached to `provider`, listening for `hash`.
     *
     * @ignore
     */
    constructor(provider: AbstractProvider, hash: string, zone: Zone);
    /**
     * Polls for the transaction receipt.
     *
     * @ignore
     * @param {number} blockNumber - The block number.
     * @param {AbstractProvider} provider - The provider.
     * @returns {Promise<void>} A promise that resolves when the poll is complete.
     */
    _poll(blockNumber: number, provider: AbstractProvider): Promise<void>;
}
export declare class PollingQiTransactionSubscriber extends OnBlockSubscriber {
    #private;
    constructor(provider: AbstractProvider, hash: string, zone: Zone);
    _poll(blockNumber: number, provider: AbstractProvider): Promise<void>;
}
/**
 * A **PollingEventSubscriber** will poll for a given filter for its logs.
 *
 * @category Providers
 */
export declare class PollingEventSubscriber implements Subscriber {
    #private;
    /**
     * Create a new **PollingEventSubscriber** attached to `provider`, listening for `filter`.
     *
     * @ignore
     */
    constructor(provider: AbstractProvider, filter: EventFilter);
    /**
     * Starts the subscriber.
     */
    start(): void;
    /**
     * Stops the subscriber.
     */
    stop(): void;
    /**
     * Pauses the subscriber.
     *
     * @param {boolean} [dropWhilePaused] - Whether to drop the block number while paused.
     */
    pause(dropWhilePaused?: boolean): void;
    /**
     * Resumes the subscriber.
     */
    resume(): void;
}
//# sourceMappingURL=subscriber-polling.d.ts.map