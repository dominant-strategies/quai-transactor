export type txpoolContentResponse = {
    pending: {
        [address: string]: {
            [nonce: string]: {
                blockHash: string | null;
                blockNumber: string | null;
                from: string;
                gas: string;
                gasPrice: string;
                hash: string;
                input: string;
                nonce: string;
                to: string;
                transactionIndex: string | null;
                value: string;
                type: string;
                accessList: Array<any>;
                chainId: string;
                v: string;
                r: string;
                s: string;
            };
        };
    };
    queued: {
        [address: string]: {
            [nonce: string]: {
                blockHash: string | null;
                blockNumber: string | null;
                from: string;
                gas: string;
                gasPrice: string;
                hash: string;
                input: string;
                nonce: string;
                to: string;
                transactionIndex: string | null;
                value: string;
                type: string;
                accessList: Array<any>;
                chainId: string;
                v: string;
                r: string;
                s: string;
            };
        };
    };
};
export type txpoolInspectResponse = {
    pending: {
        [address: string]: {
            [nonce: string]: string;
        };
    };
    queued: {
        [address: string]: {
            [nonce: string]: string;
        };
    };
};
//# sourceMappingURL=txpool.d.ts.map