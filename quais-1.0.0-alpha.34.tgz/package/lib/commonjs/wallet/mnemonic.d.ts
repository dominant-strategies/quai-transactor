import type { BytesLike } from '../utils/index.js';
import type { Wordlist } from '../wordlists/index.js';
/**
 * A **Mnemonic** wraps all properties required to compute [BIP-39](https://en.bitcoin.it/wiki/BIP_0039) seeds and
 * convert between phrases and entropy.
 *
 * @category Wallet
 */
export declare class Mnemonic {
    /**
     * The mnemonic phrase of 12, 15, 18, 21 or 24 words.
     *
     * Use the {@link wordlist | **wordlist**} `split` method to get the individual words.
     */
    readonly phrase: string;
    /**
     * The password used for this mnemonic. If no password is used this is the empty string (i.e. `""`) as per the
     * specification.
     */
    readonly password: string;
    /**
     * The wordlist for this mnemonic.
     */
    readonly wordlist: Wordlist;
    /**
     * The underlying entropy which the mnemonic encodes.
     */
    readonly entropy: string;
    /**
     * @param {any} guard - The guard object.
     * @param {string} entropy - The entropy.
     * @param {string} phrase - The mnemonic phrase.
     * @param {string} [password] - The password for the mnemonic.
     * @param {Wordlist} [wordlist] - The wordlist for the mnemonic.
     */
    constructor(guard: any, entropy: string, phrase: string, password?: null | string, wordlist?: null | Wordlist);
    /**
     * Returns the seed for the mnemonic.
     *
     * @returns {string} The seed.
     */
    computeSeed(): string;
    /**
     * Creates a new Mnemonic for the `phrase`.
     *
     * The default `password` is the empty string and the default wordlist is the {@link LangEn | **English wordlist**}.
     *
     * @param {string} phrase - The mnemonic phrase.
     * @param {string} [password] - The password for the mnemonic.
     * @param {Wordlist} [wordlist] - The wordlist for the mnemonic.
     * @returns {Mnemonic} The new Mnemonic object.
     */
    static fromPhrase(phrase: string, password?: null | string, wordlist?: null | Wordlist): Mnemonic;
    /**
     * Create a new **Mnemonic** from the `entropy`.
     *
     * The default `password` is the empty string and the default wordlist is the [{@link LangEn | **English wordlist**}.
     *
     * @param {BytesLike} _entropy - The entropy for the mnemonic.
     * @param {string} [password] - The password for the mnemonic.
     * @param {Wordlist} [wordlist] - The wordlist for the mnemonic.
     * @returns {Mnemonic} The new Mnemonic object.
     */
    static fromEntropy(_entropy: BytesLike, password?: null | string, wordlist?: null | Wordlist): Mnemonic;
    /**
     * Returns the phrase for `mnemonic`.
     *
     * @param {BytesLike} _entropy - The entropy for the mnemonic.
     * @param {Wordlist} [wordlist] - The wordlist for the mnemonic.
     * @returns {string} The mnemonic phrase.
     */
    static entropyToPhrase(_entropy: BytesLike, wordlist?: null | Wordlist): string;
    /**
     * Returns the entropy for `phrase`.
     *
     * @param {string} phrase - The mnemonic phrase.
     * @param {Wordlist} [wordlist] - The wordlist for the mnemonic.
     * @returns {string} The entropy.
     */
    static phraseToEntropy(phrase: string, wordlist?: null | Wordlist): string;
    /**
     * Returns true if `phrase` is a valid [BIP-39](https://en.bitcoin.it/wiki/BIP_0039) phrase.
     *
     * This checks all the provided words belong to the `wordlist`, that the length is valid and the checksum is
     * correct.
     *
     * @param {string} phrase - The mnemonic phrase.
     * @param {Wordlist} [wordlist] - The wordlist for the mnemonic.
     * @returns {boolean} True if the phrase is valid.
     * @throws {Error} If the phrase is invalid.
     */
    static isValidMnemonic(phrase: string, wordlist?: null | Wordlist): boolean;
}
//# sourceMappingURL=mnemonic.d.ts.map