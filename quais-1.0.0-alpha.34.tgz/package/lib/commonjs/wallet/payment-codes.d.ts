import { BIP32API, BIP32Interface, HDNodeBIP32Adapter } from './bip32/types.js';
import type { TinySecp256k1Interface } from './bip32/types.js';
export declare const PC_VERSION = 71;
export declare class PaymentCodePublic {
    protected readonly ecc: TinySecp256k1Interface;
    protected readonly bip32: BIP32API;
    protected readonly buf: Uint8Array;
    root: BIP32Interface;
    hasPrivKeys: boolean;
    /**
     * Constructor for the PaymentCode class.
     *
     * @param {TinySecp256k1Interface} ecc - Implementation of secp256k1 elliptic curve
     * @param {BIP32API} bip32 - Bip32 instance
     * @param {Uint8Array} buf - The buffer representing the payment code.
     * @throws {Error} Invalid buffer length - If the length of the buffer is not 80.
     * @throws {Error} Only payment codes version 1 are supported - If the version of the payment code is not 1.
     */
    constructor(ecc: TinySecp256k1Interface, bip32: BIP32API, buf: Uint8Array);
    /**
     * Get the features of PaymentCode.
     *
     * @returns {Uint8Array} The features as a Uint8Array object.
     */
    get features(): Uint8Array;
    /**
     * Returns the public key.
     *
     * @returns {Uint8Array} The public key as a Uint8Array.
     */
    get pubKey(): Uint8Array;
    /**
     * Retrieves the chain code of the payment code.
     *
     * @returns {Uint8Array} - The extracted chain code as a Uint8Array.
     */
    get chainCode(): Uint8Array;
    /**
     * Retrieves the payment code buffer.
     *
     * @returns {Uint8Array} The payment code buffer.
     */
    get paymentCode(): Uint8Array;
    /**
     * Creates a base58 representation of the payment code.
     *
     * @returns {string} - The Base58 representation of PaymentCode.
     */
    toBase58(): string;
    /**
     * Derives a child from the root BIP32 node at the specified index.
     *
     * @param {number} index - The index of the child BIP32Interface object to be derived.
     * @returns {BIP32Interface} - The derived child BIP32Interface object.
     */
    derive(index: number): BIP32Interface;
    /**
     * Retrieves the public key for notification.
     *
     * @returns {Uint8Array} The public key for notification.
     */
    getNotificationPublicKey(): Uint8Array;
    /**
     * Derives a public key from the shared secret.
     *
     * @param {Uint8Array} B - Public key
     * @param {Uint8Array} S - Shared secret point
     * @returns {Uint8Array} The derived public key.
     * @throws {Error} If the shared secret is invalid or unable to derive the public key.
     */
    derivePublicKeyFromSharedSecret(B: Uint8Array, S: Uint8Array): Uint8Array;
    /**
     * Derives a payment public key based on the given public payment code.
     *
     * @param {PaymentCodePublic} paymentCode - The public payment code to derive the payment public key from.
     * @param {number} idx - The index used for derivation.
     * @returns {Uint8Array} The derived payment public key.
     * @throws {Error} If the payment code does not contain a valid public key, or if any step in the derivation process
     *   fails.
     */
    derivePaymentPublicKey(paymentCode: PaymentCodePrivate, idx: number): Uint8Array;
    /**
     * Retrieves the address from a given public key.
     *
     * @param {Uint8Array} pubKey - The public key.
     * @returns {string} The generated address.
     * @throws {Error} - When unsupported address type is passed
     * @protected
     */
    protected getAddressFromPubkey(pubKey: Uint8Array): string;
    /**
     * Retrieves a payment address based on the provided parameters.
     *
     * @param {PaymentCodePublic} paymentCode - The public payment code to derive the payment address from.
     * @param {number} idx - The index used in the derivation process.
     * @returns {string} - The generated payment address.
     * @throws {Error} - If unable to derive public key or if an unknown address type is specified.
     */
    getPaymentAddress(paymentCode: PaymentCodePrivate, idx: number): string;
}
export declare class PaymentCodePrivate extends PaymentCodePublic {
    /**
     * Constructor for the PaymentCodePrivate class.
     *
     * @param {HDNodeBIP32Adapter} root - The root HDNodeWallet as a HDNodeBIP32Adapter.
     * @param {TinySecp256k1Interface} ecc - Implementation of secp256k1 elliptic curve.
     * @param {BIP32API} bip32 - An instance implementing the bip32 API methods.
     * @param {Uint8Array} buf - The buffer representing the payment code.
     */
    constructor(root: HDNodeBIP32Adapter, ecc: TinySecp256k1Interface, bip32: BIP32API, buf: Uint8Array);
    /**
     * Derives a payment public key based on the given public payment code.
     *
     * @param {PaymentCodePublic} paymentCode - The public payment code to derive the payment public key from.
     * @param {number} idx - The index used for derivation.
     * @returns {Uint8Array} The derived payment public key.
     * @throws {Error} If the payment code does not contain a valid public key or unable to derive the node with private
     *   key.
     */
    derivePaymentPublicKey(paymentCode: PaymentCodePublic, idx: number): Uint8Array;
    /**
     * Retrieves a payment address based on the provided parameters.
     *
     * @param {PaymentCodePublic} paymentCode - The public payment code to derive the payment address from.
     * @param {number} idx - The index used in the derivation process.
     * @returns {string} - The generated payment address.
     * @throws {Error} - If unable to derive public key or if an unknown address type is specified.
     */
    getPaymentAddress(paymentCode: PaymentCodePublic, idx: number): string;
    /**
     * Derives a payment private key based on the given public payment code.
     *
     * @param {PaymentCodePublic} paymentCodePublic - The public payment code to derive the payment private key from.
     * @param {number} idx - The index used for derivation.
     * @returns {Uint8Array} The derived payment private key.
     * @throws {Error} If the payment code does not contain a valid public key, unable to derive the node without
     *   private key, unable to compute the resulting point, or invalid shared secret.
     */
    derivePaymentPrivateKey(paymentCodePublic: PaymentCodePublic, idx: number): Uint8Array;
    /**
     * Retrieves the notification private key.
     *
     * @returns {Uint8Array} The notification private key.
     */
    getNotificationPrivateKey(): Uint8Array;
}
/**
 * Validates a payment code base58 encoded string.
 *
 * @param {string} paymentCode - The payment code to validate.
 * @throws {Error} If the payment code is invalid.
 */
export declare function validatePaymentCode(paymentCode: string): boolean;
//# sourceMappingURL=payment-codes.d.ts.map