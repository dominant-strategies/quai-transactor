export declare const bs58check: import("@scure/base").BytesCoder;
export declare function hash160(buffer: Uint8Array): Uint8Array;
export declare function hmacSHA512(key: Uint8Array | string, data: Uint8Array | string): Uint8Array;
//# sourceMappingURL=crypto.d.ts.map