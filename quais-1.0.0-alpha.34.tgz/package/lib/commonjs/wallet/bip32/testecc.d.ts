export declare function testEcc(ecc: any): void;
//# sourceMappingURL=testecc.d.ts.map