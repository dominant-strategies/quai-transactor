import { BIP32API } from './types.js';
export declare function BIP32Factory(ecc: any): BIP32API;
//# sourceMappingURL=bip32.d.ts.map