/**
 * Uint8Array comparison
 */
export declare function areUint8ArraysEqual(a: Uint8Array, b: Uint8Array): boolean;
//# sourceMappingURL=uint8array-utils.d.ts.map