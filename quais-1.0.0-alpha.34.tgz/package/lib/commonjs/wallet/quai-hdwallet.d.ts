import { AbstractHDWallet, NeuteredAddressInfo } from './hdwallet.js';
import { HDNodeWallet } from './hdnodewallet.js';
import { QuaiTransactionRequest, Provider, TransactionResponse } from '../providers/index.js';
import { AllowedCoinType, Zone } from '../constants/index.js';
import { SerializedHDWallet } from './hdwallet.js';
import { TypedDataDomain, TypedDataField } from '../hash/index.js';
export interface SerializedQuaiHDWallet extends SerializedHDWallet {
    addresses: Array<NeuteredAddressInfo>;
}
/**
 * The Quai HD wallet is a BIP44-compliant hierarchical deterministic wallet used for managing a set of addresses in the
 * Quai ledger. This is the easiest way to manage the interaction of managing accounts and addresses on the Quai
 * network, however, if your use case requires a single address Quai address, you can use the {@link Wallet} class.
 *
 * The Quai HD wallet supports:
 *
 * - Adding accounts to the wallet heierchy
 * - Generating addresses for a specific account in any {@link Zone}
 * - Signing and sending transactions for any address in the wallet
 * - Signing and verifying EIP1193 typed data for any address in the wallet.
 * - Serializing the wallet to JSON and deserializing it back to a wallet instance.
 *
 * @category Wallet
 * @example
 *
 * ```ts
 * import { QuaiHDWallet, Zone } from 'quais';
 *
 * const wallet = new QuaiHDWallet();
 * const cyrpus1Address = await wallet.getNextAddress(0, Zone.Cyrpus1); // get the first address in the Cyrpus1 zone
 * await wallet.sendTransaction({ from: address, to: '0x...', value: 100 }); // send a transaction
 * const serializedWallet = wallet.serialize(); // serialize current (account/address) state of the wallet
 * .
 * .
 * .
 * const deserializedWallet = QuaiHDWallet.deserialize(serializedWallet); // create a new wallet instance from the serialized data
 * ```
 */
export declare class QuaiHDWallet extends AbstractHDWallet<NeuteredAddressInfo> {
    /**
     * The version of the wallet.
     *
     * @type {number}
     * @static
     */
    protected static _version: number;
    /**
     * The coin type for the wallet.
     *
     * @type {AllowedCoinType}
     * @static
     */
    protected static _coinType: AllowedCoinType;
    /**
     * Create a QuaiHDWallet instance.
     *
     * @param {HDNodeWallet} root - The root HD node wallet.
     * @param {Provider} [provider] - The provider.
     */
    constructor(guard: any, root: HDNodeWallet, provider?: Provider);
    /**
     * Sign a transaction.
     *
     * @param {QuaiTransactionRequest} tx - The transaction request.
     * @returns {Promise<string>} A promise that resolves to the signed transaction.
     */
    signTransaction(tx: QuaiTransactionRequest): Promise<string>;
    /**
     * Send a transaction.
     *
     * @param {QuaiTransactionRequest} tx - The transaction request.
     * @returns {Promise<TransactionResponse>} A promise that resolves to the transaction response.
     * @throws {Error} If the provider is not set.
     */
    sendTransaction(tx: QuaiTransactionRequest): Promise<TransactionResponse>;
    /**
     * Sign a message.
     *
     * @param {string} address - The address.
     * @param {string | Uint8Array} message - The message to sign.
     * @returns {Promise<string>} A promise that resolves to the signed message.
     */
    signMessage(address: string, message: string | Uint8Array): Promise<string>;
    /**
     * Serializes the QuaiHDWallet state into a format suitable for storage or transmission.
     *
     * This method extends the serialization from the parent class (AbstractHDWallet) and includes additional
     * QuaiHDWallet-specific data, such as the addresses.
     *
     * @example Const wallet = new QuaiHDWallet(); const serializedData = wallet.serialize(); // serializedData can now
     * be stored or transmitted
     *
     * @returns {SerializedQuaiHDWallet} An object representing the serialized state of the QuaiHDWallet, including
     *   addresses and other inherited properties from the parent wallet.
     */
    serialize(): SerializedQuaiHDWallet;
    protected validateAddressDerivation(info: NeuteredAddressInfo): void;
    /**
     * Deserializes the given serialized HD wallet data into an instance of QuaiHDWallet.
     *
     * @async
     * @param {SerializedHDWallet} serialized - The serialized wallet data to be deserialized.
     * @returns {Promise<QuaiHDWallet>} A promise that resolves to an instance of QuaiHDWallet.
     * @throws {Error} If validation of the serialized wallet data fails or if deserialization fails.
     * @public
     * @static
     */
    static deserialize(serialized: SerializedQuaiHDWallet): Promise<QuaiHDWallet>;
    /**
     * Signs typed data using the private key associated with the given address.
     *
     * @param {string} address - The address for which the typed data is to be signed.
     * @param {TypedDataDomain} domain - The domain information of the typed data, defining the scope of the signature.
     * @param {Record<string, TypedDataField[]>} types - The types of the data to be signed, mapping each data type name
     *   to its fields.
     * @param {Record<string, unknown>} value - The actual data to be signed.
     * @returns {Promise<string>} A promise that resolves to the signed data in string format.
     * @throws {Error} If the address does not correspond to a valid HD node or if signing fails.
     */
    signTypedData(address: string, domain: TypedDataDomain, types: Record<string, Array<TypedDataField>>, value: Record<string, unknown>): Promise<string>;
    /**
     * Adds an address to the wallet.
     *
     * @param {number} account - The account number.
     * @param {number} addressIndex - The address index.
     * @returns {NeuteredAddressInfo} The added address info.
     */
    addAddress(account: number, addressIndex: number): NeuteredAddressInfo;
    /**
     * Helper method to add an address to the wallet address map.
     *
     * @param {Map<string, NeuteredAddressInfo>} addressMap - The address map.
     * @param {number} account - The account number.
     * @param {number} addressIndex - The address index.
     * @returns {NeuteredAddressInfo} The added address info.
     * @throws {Error} If the address for the index already exists.
     */
    protected _addAddress(account: number, addressIndex: number): NeuteredAddressInfo;
    /**
     * Promise that resolves to the next address for the specified account and zone.
     *
     * @param {number} account - The index of the account for which to retrieve the next address.
     * @param {Zone} zone - The zone in which to retrieve the next address.
     * @returns {Promise<T>} The next neutered address information.
     */
    getNextAddress(account: number, zone: Zone): Promise<NeuteredAddressInfo>;
    /**
     * Synchronously retrieves the next address for the specified account and zone.
     *
     * @param {number} account - The index of the account for which to retrieve the next address.
     * @param {Zone} zone - The zone in which to retrieve the next address.
     * @returns {T} The next neutered address information.
     */
    getNextAddressSync(account: number, zone: Zone): NeuteredAddressInfo;
    /**
     * Derives and returns the next address information for the specified account and zone.
     *
     * @param {number} accountIndex - The index of the account for which the address is being generated.
     * @param {Zone} zone - The zone in which the address is to be used.
     * @param {Map<string, NeuteredAddressInfo>} addressMap - A map storing the neutered address information.
     * @returns {T} The derived neutered address information.
     * @throws {Error} If the zone is invalid.
     */
    protected _getNextAddress(accountIndex: number, zone: Zone): NeuteredAddressInfo;
    /**
     * Creates and stores address information in the address map for a specified account, zone, and change type.
     *
     * This method constructs a NeuteredAddressInfo object using the provided HDNodeWallet and other parameters, then
     * stores this information in the provided address map.
     *
     * @param {HDNodeWallet} addressNode - The HDNodeWallet object containing the address and public key information.
     * @param {number} account - The account number to associate with the address.
     * @param {Zone} zone - The specific zone to associate with the address.
     * @param {Map<string, NeuteredAddressInfo>} addressMap - The map to store the created NeuteredAddressInfo, with the
     *   address as the key.
     * @returns {NeuteredAddressInfo} - The created NeuteredAddressInfo object.
     * @protected
     */
    private _createAndStoreNeuteredAddressInfo;
    /**
     * Gets the address info for a given address.
     *
     * @param {string} address - The address.
     * @returns {T | null} The address info or null if not found.
     */
    getAddressInfo(address: string): NeuteredAddressInfo | null;
    /**
     * Returns the private key for a given address. This method should be used with caution as it exposes the private
     * key to the user.
     *
     * @param {string} address - The address associated with the desired private key.
     * @returns {string} The private key.
     */
    getPrivateKey(address: string): string;
    /**
     * Derives and returns the Hierarchical Deterministic (HD) node wallet associated with a given address.
     *
     * This method fetches the account and address information from the wallet's internal storage, derives the
     * appropriate change node based on whether the address is a change address, and further derives the final HD node
     * using the address index.
     *
     * @param {string} addr - The address for which to derive the HD node.
     * @returns {HDNodeWallet} The derived HD node wallet corresponding to the given address.
     * @throws {Error} If the given address is not known to the wallet.
     * @throws {Error} If the account associated with the address is not found.
     */
    protected _getHDNodeForAddress(addr: string): HDNodeWallet;
    /**
     * Gets the addresses for a given zone.
     *
     * @param {Zone} zone - The zone.
     * @returns {NeuteredAddressInfo[]} The addresses for the zone.
     */
    getAddressesForZone(zone: Zone): NeuteredAddressInfo[];
    /**
     * Gets the addresses for a given account.
     *
     * @param {number} account - The account number.
     * @returns {NeuteredAddressInfo[]} The addresses for the account.
     */
    getAddressesForAccount(account: number): NeuteredAddressInfo[];
    protected _findLastUsedIndex(addresses: NeuteredAddressInfo[] | undefined, account: number, zone: Zone): number;
}
//# sourceMappingURL=quai-hdwallet.d.ts.map