/**
 * @module wallet/utils
 */
import { BytesLike } from '../utils/index.js';
/**
 * Converts a hex string to a Uint8Array. If the string does not start with '0x', it adds it.
 *
 * @param {string} hexString - The hex string to convert.
 * @returns {Uint8Array} The resulting byte array.
 */
export declare function looseArrayify(hexString: string): Uint8Array;
/**
 * Converts a password to a Uint8Array. If the password is a string, it converts it to UTF-8 bytes.
 *
 * @param {string | Uint8Array} password - The password to convert.
 * @returns {Uint8Array} The resulting byte array.
 */
export declare function getPassword(password: string | Uint8Array): Uint8Array;
/**
 * Traverses an object based on a path and returns the value at that path.
 *
 * @param {any} object - The object to traverse.
 * @param {string} _path - The path to traverse.
 * @returns {T} The value at the specified path.
 */
export declare function spelunk<T>(object: any, _path: string): T;
/**
 * "Bitcoin seed"
 */
export declare const MasterSecret: Uint8Array;
/**
 * Hardened bit constant
 */
export declare const HardenedBit = 2147483648;
/**
 * Constant N used in cryptographic operations
 */
export declare const N: bigint;
/**
 * Hexadecimal characters
 */
export declare const Nibbles = "0123456789abcdef";
/**
 * Pads a value with leading zeros to a specified length.
 *
 * @param {string | number} value - The value to pad.
 * @param {number} length - The desired length.
 * @returns {string} The padded value.
 */
export declare function zpad(value: string | number, length: number): string;
/**
 * Encodes a value using Base58Check encoding.
 *
 * @param {BytesLike} _value - The value to encode.
 * @returns {string} The Base58Check encoded string.
 */
export declare function encodeBase58Check(_value: BytesLike): string;
/**
 * Serializes an index, chain code, public key, and private key into a pair of derived keys.
 *
 * @param {number} index - The index to serialize.
 * @param {string} chainCode - The chain code.
 * @param {string} publicKey - The public key.
 * @param {null | string} privateKey - The private key.
 * @returns {{ IL: Uint8Array; IR: Uint8Array }} The derived keys.
 */
export declare function ser_I(index: number, chainCode: string, publicKey: string, privateKey: null | string): {
    IL: Uint8Array;
    IR: Uint8Array;
};
//# sourceMappingURL=utils.d.ts.map