import { HDNodeWallet } from './hdnodewallet.js';
import { Mnemonic } from './mnemonic.js';
import type { Wordlist } from '../wordlists/index.js';
import { Zone } from '../constants/index.js';
import { TransactionRequest, Provider } from '../providers/index.js';
import { AllowedCoinType } from '../constants/index.js';
export declare const HARDENED_OFFSET: number;
/**
 * Interface representing information about a neutered address.
 */
export interface NeuteredAddressInfo {
    pubKey: string;
    address: string;
    account: number;
    index: number;
    zone: Zone;
}
/**
 * Interface representing the serialized state of an HD wallet.
 */
export interface SerializedHDWallet {
    version: number;
    phrase: string;
    coinType: AllowedCoinType;
}
/**
 * Constant to represent the maximum attempt to derive an address.
 */
export declare const MAX_ADDRESS_DERIVATION_ATTEMPTS = 10000000;
export declare const _guard: {};
/**
 * Abstract class representing a Hierarchical Deterministic (HD) wallet.
 */
export declare abstract class AbstractHDWallet<T extends NeuteredAddressInfo = NeuteredAddressInfo> {
    protected static _version: number;
    protected static _coinType?: AllowedCoinType;
    protected _addresses: Map<string, NeuteredAddressInfo>;
    /**
     * Root node of the HD wallet.
     */
    protected _root: HDNodeWallet;
    protected provider?: Provider;
    /**
     * @param {HDNodeWallet} root - The root node of the HD wallet.
     * @param {Provider} [provider] - The provider for the HD wallet.
     */
    constructor(guard: any, root: HDNodeWallet, provider?: Provider);
    /**
     * Returns the parent path for a given coin type.
     *
     * @param {number} coinType - The coin type.
     * @returns {string} The parent path.
     */
    protected static parentPath(coinType: number): string;
    /**
     * Returns the coin type of the wallet.
     *
     * @returns {AllowedCoinType} The coin type.
     */
    protected coinType(): AllowedCoinType;
    /**
     * Returns the extended public key of the root node of the HD wallet.
     *
     * @returns {string} The extended public key.
     */
    get xPub(): string;
    protected isValidAddressForZone(address: string, zone: Zone): boolean;
    /**
     * Gets the BIP44 change node for a given account and change flag.
     *
     * @param {number} account - The account number.
     * @param {boolean} change - Whether to get the change node.
     * @returns {HDNodeWallet} The change node.
     */
    protected _getChangeNode(account: number, change: boolean): HDNodeWallet;
    /**
     * Gets the BIP44 address node for a given account, change flag, and address index.
     *
     * @param {number} account - The account number.
     * @param {boolean} change - Whether to get the change node.
     * @param {number} addressIndex - The address index.
     * @returns {HDNodeWallet} The address node.
     */
    protected _getAddressNode(account: number, change: boolean, addressIndex: number): HDNodeWallet;
    /**
     * Derives the next valid address node for a specified account, starting index, and zone. The method ensures the
     * derived address belongs to the correct shard and ledger, as defined by the Quai blockchain specifications.
     *
     * @param {number} account - The account number from which to derive the address node.
     * @param {number} startingIndex - The index from which to start deriving addresses.
     * @param {Zone} zone - The zone (shard) for which the address should be valid.
     * @param {boolean} [isChange=false] - Whether to derive a change address. Default is `false`
     * @returns {HDNodeWallet} - The derived HD node wallet containing a valid address for the specified zone.
     * @throws {Error} If a valid address for the specified zone cannot be derived within the allowed attempts.
     */
    protected deriveNextAddressNode(account: number, startingIndex: number, zone: Zone, isChange?: boolean): HDNodeWallet;
    /**
     * Adds an address to the wallet for a given account and address index.
     *
     * @param {number} account - The account number to add the address to
     * @param {number} addressIndex - The index of the address to add
     * @returns {T | null} The address info object if successful, null otherwise
     */
    abstract addAddress(account: number, addressIndex: number): T | null;
    /**
     * Gets the next available address for a given account and zone.
     *
     * @param {number} account - The account number to get the next address for
     * @param {Zone} zone - The zone to get the next address in
     * @returns {Promise<T>} Promise that resolves to the next address info
     */
    abstract getNextAddress(account: number, zone: Zone): Promise<T>;
    /**
     * Synchronously gets the next available address for a given account and zone.
     *
     * @param {number} account - The account number to get the next address for
     * @param {Zone} zone - The zone to get the next address in
     * @returns {T} The next address info
     */
    abstract getNextAddressSync(account: number, zone: Zone): T;
    /**
     * Gets the address info for a given address string.
     *
     * @param {string} address - The address to get info for
     * @returns {T | null} The address info if found, null otherwise
     */
    abstract getAddressInfo(address: string): T | null;
    /**
     * Gets the private key for a given address.
     *
     * @param {string} address - The address to get the private key for
     * @returns {string} The private key as a hex string
     */
    abstract getPrivateKey(address: string): string;
    /**
     * Gets all addresses belonging to a specific zone.
     *
     * @param {Zone} zone - The zone to get addresses for
     * @returns {T[]} Array of address info objects in the zone
     */
    abstract getAddressesForZone(zone: Zone): T[];
    /**
     * Gets all addresses belonging to a specific account.
     *
     * @param {number} account - The account number to get addresses for
     * @returns {T[]} Array of address info objects in the account
     */
    abstract getAddressesForAccount(account: number): T[];
    /**
     * Finds the highest used index for a given account and zone.
     *
     * @param {T[] | undefined} addresses - Array of address info objects to search
     * @param {number} account - The account number to find the last index for
     * @param {Zone} zone - The zone to find the last index in
     * @returns {number} The highest used index, or -1 if none found
     * @protected
     */
    protected abstract _findLastUsedIndex(addresses: T[] | undefined, account: number, zone: Zone): number;
    /**
     * Abstract method to sign a message using the private key associated with the given address.
     *
     * @param {string} address - The address for which the message is to be signed.
     * @param {string | Uint8Array} message - The message to be signed, either as a string or Uint8Array.
     * @returns {Promise<string>} A promise that resolves to the signature of the message in hexadecimal string format.
     * @throws {Error} If the method is not implemented in the subclass.
     */
    abstract signMessage(address: string, message: string | Uint8Array): Promise<string>;
    /**
     * Abstract method to sign a transaction.
     *
     * @param {TransactionRequest} tx - The transaction request.
     * @returns {Promise<string>} A promise that resolves to the signed transaction.
     */
    abstract signTransaction(tx: TransactionRequest): Promise<string>;
    /**
     * Creates an instance of the HD wallet.
     *
     * @param {new (root: HDNodeWallet) => T} this - The constructor of the HD wallet.
     * @param {Mnemonic} mnemonic - The mnemonic.
     * @returns {T} The created instance.
     */
    protected static createInstance<T extends AbstractHDWallet>(this: new (guard: any, root: HDNodeWallet) => T, mnemonic: Mnemonic): T;
    /**
     * Creates an HD wallet from a mnemonic.
     *
     * @param {new (root: HDNodeWallet) => T} this - The constructor of the HD wallet.
     * @param {Mnemonic} mnemonic - The mnemonic.
     * @returns {T} The created instance.
     */
    static fromMnemonic<T extends AbstractHDWallet>(this: new (guard: any, root: HDNodeWallet) => T, mnemonic: Mnemonic): T;
    /**
     * Creates a random HD wallet.
     *
     * @param {new (root: HDNodeWallet) => T} this - The constructor of the HD wallet.
     * @param {string} [password] - The password.
     * @param {Wordlist} [wordlist] - The wordlist.
     * @returns {T} The created instance.
     */
    static createRandom<T extends AbstractHDWallet>(this: new (guard: any, root: HDNodeWallet) => T, password?: string, wordlist?: Wordlist): T;
    /**
     * Creates an HD wallet from a phrase.
     *
     * @param {new (root: HDNodeWallet) => T} this - The constructor of the HD wallet.
     * @param {string} phrase - The phrase.
     * @param {string} [password] - The password.
     * @param {Wordlist} [wordlist] - The wordlist.
     * @returns {T} The created instance.
     */
    static fromPhrase<T extends AbstractHDWallet>(this: new (guard: any, root: HDNodeWallet) => T, phrase: string, password?: string, wordlist?: Wordlist): T;
    /**
     * Connects the wallet to a provider.
     *
     * @param {Provider} provider - The provider.
     */
    connect(provider: Provider): void;
    /**
     * Validates the zone.
     *
     * @param {Zone} zone - The zone.
     * @throws {Error} If the zone is invalid.
     */
    protected validateZone(zone: Zone): void;
    /**
     * Serializes the HD wallet state into a format suitable for storage or transmission.
     *
     * @returns {SerializedHDWallet} An object representing the serialized state of the HD wallet, including version,
     *   mnemonic phrase, coin type, and addresses.
     */
    serialize(): SerializedHDWallet;
    /**
     * Deserializes a serialized HD wallet object and reconstructs the wallet instance. This method must be implemented
     * in the subclass.
     *
     * @param {SerializedHDWallet} _serialized - The serialized object representing the state of an HD wallet.
     * @returns {AbstractHDWallet} An instance of AbstractHDWallet.
     * @throws {Error} This method must be implemented in the subclass.
     */
    static deserialize(_serialized: SerializedHDWallet): Promise<AbstractHDWallet>;
    /**
     * Validates an address info object, including basic properties and address derivation.
     *
     * @param {T} info - The address info to validate
     * @throws {Error} If validation fails
     * @protected
     */
    protected validateAddressInfo(info: T): void;
    /**
     * Validates the NeuteredAddressInfo object.
     *
     * @param {NeuteredAddressInfo} info - The NeuteredAddressInfo object to be validated.
     * @throws {Error} If the NeuteredAddressInfo object is invalid.
     * @protected
     */
    protected validateBaseAddressInfo(info: NeuteredAddressInfo): void;
    /**
     * Validates that the address, pubKey and zone match what would be derived from the other properties.
     *
     * @param {T} info - The address info to validate
     * @throws {Error} If validation fails
     * @protected
     */
    protected abstract validateAddressDerivation(info: T): void;
    /**
     * Hook for subclasses to add their own validation logic. Base implementation does nothing.
     *
     * @param {T} _info - The address info to validate
     * @protected
     */
    protected validateExtendedProperties(_info: T): void;
    /**
     * Validates the version and coinType of the serialized wallet.
     *
     * @param {SerializedHDWallet} serialized - The serialized wallet data to be validated.
     * @throws {Error} If the version or coinType of the serialized wallet does not match the expected values.
     * @protected
     * @static
     */
    protected static validateSerializedWallet(serialized: SerializedHDWallet): void;
}
//# sourceMappingURL=hdwallet.d.ts.map