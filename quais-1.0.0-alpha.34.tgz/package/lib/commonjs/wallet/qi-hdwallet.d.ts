import { AbstractHDWallet, NeuteredAddressInfo, SerializedHDWallet } from './hdwallet.js';
import { HDNodeWallet } from './hdnodewallet.js';
import { QiTransactionRequest, Provider, TransactionResponse } from '../providers/index.js';
import { Outpoint } from '../transaction/utxo.js';
import { AllowedCoinType, Zone } from '../constants/index.js';
/**
 * @property {Outpoint} outpoint - The outpoint object.
 * @property {string} address - The address associated with the outpoint.
 * @property {Zone} zone - The zone of the outpoint.
 * @property {number} [account] - The account number (optional).
 * @interface OutpointInfo
 */
export interface OutpointInfo {
    outpoint: Outpoint;
    address: string;
    zone: Zone;
    account?: number;
}
/**
 * Enum representing the status of an address in the wallet.
 *
 * @enum {string}
 */
export declare enum AddressStatus {
    USED = "USED",
    UNUSED = "UNUSED",
    ATTEMPTED_USE = "ATTEMPTED_USE",
    UNKNOWN = "UNKNOWN"
}
/**
 * Type representing the derivation path of an address in the wallet.
 *
 * @type {string}
 */
type DerivationPath = 'BIP44:external' | 'BIP44:change' | string;
export type LastSyncedBlock = {
    hash: string;
    number: number;
};
/**
 * Interface representing an address in the Qi HD wallet.
 *
 * @extends NeuteredAddressInfo
 */
export interface QiAddressInfo extends NeuteredAddressInfo {
    change: boolean;
    status: AddressStatus;
    derivationPath: DerivationPath;
    lastSyncedBlock: LastSyncedBlock | null;
}
/**
 * @extends SerializedHDWallet
 * @property {OutpointInfo[]} outpoints - Array of outpoint information.
 * @property {QiAddressInfo[]} addresses - Array of Qi address information.
 * @property {Record<string, QiAddressInfo[]>} senderPaymentCodeInfo - Map of payment code to array ofQi address
 *   information.
 * @interface SerializedQiHDWallet
 */
export interface SerializedQiHDWallet extends SerializedHDWallet {
    addresses: Array<QiAddressInfo>;
    senderPaymentCodeInfo: {
        [key: string]: QiAddressInfo[];
    };
}
type AddressUsageCallback = (address: string) => Promise<boolean>;
type OutpointDeltaResponse = {
    [address: string]: Outpoint[];
};
type OutpointsCallback = (outpoints: OutpointDeltaResponse) => Promise<void>;
/**
 * Current known issues:
 *
 * - When generating send addresses we are not checking if the address has already been used before
 * - When syncing is seems like we are adding way too many change addresses
 * - Bip44 external and change address maps also have gap addresses in them
 * - It is unclear if we have checked if addresses have been used and if they are used
 * - We should always check all addresses that were previously included in a transaction to see if they have been used
 */
/**
 * The Qi HD wallet is a BIP44-compliant hierarchical deterministic wallet used for managing a set of addresses in the
 * Qi ledger. This is wallet implementation is the primary way to interact with the Qi UTXO ledger on the Quai network.
 *
 * The Qi HD wallet supports:
 *
 * - Adding accounts to the wallet heierchy
 * - Generating addresses for a specific account in any {@link Zone}
 * - Signing and sending transactions for any address in the wallet
 * - Serializing the wallet to JSON and deserializing it back to a wallet instance.
 *
 * @category Wallet
 * @example
 *
 * ```ts
 * import { QiHDWallet, Zone } from 'quais';
 * import { Outpoint } from '../../lib/commonjs/transaction/utxo';
 *
 * const wallet = new QiHDWallet();
 * const cyrpus1Address = await wallet.getNextAddress(0, Zone.Cyrpus1); // get the first address in the Cyrpus1 zone
 * await wallet.sendTransaction({ txInputs: [...], txOutputs: [...] }); // send a transaction
 * const serializedWallet = wallet.serialize(); // serialize current (account/address) state of the wallet
 * .
 * .
 * .
 * const deserializedWallet = QiHDWallet.deserialize(serializedWallet); // create a new wallet instance from the serialized data
 * ```
 */
export declare class QiHDWallet extends AbstractHDWallet<QiAddressInfo> {
    /**
     * @ignore
     * @type {number}
     */
    protected static _version: number;
    /**
     * @ignore
     * @type {number}
     */
    protected static _GAP_LIMIT: number;
    /**
     * @ignore
     * @type {AllowedCoinType}
     */
    protected static _coinType: AllowedCoinType;
    /**
     * @ignore
     * @type {string}
     */
    private static readonly PRIVATE_KEYS_PATH;
    /**
     * A map containing address information for all addresses known to the wallet. This includes:
     *
     * - BIP44 derived addresses (external)
     * - BIP44 derived change addresses
     * - BIP47 payment code derived addresses for receiving funds
     *
     * The key is the derivation path or payment code, and the value is an array of QiAddressInfo objects.
     *
     * @private
     * @type {Map<DerivationPath, QiAddressInfo[]>}
     */
    private _addressesMap;
    /**
     * Array of outpoint information.
     *
     * @ignore
     * @type {OutpointInfo[]}
     */
    protected _availableOutpoints: Map<string, OutpointInfo>;
    /**
     * @ignore
     * @type {AddressUsageCallback}
     */
    protected _addressUseChecker: AddressUsageCallback | undefined;
    /**
     * A map containing address information for sending funds to counterparties using BIP47 payment codes.
     *
     * @remarks
     * The key is the receiver's payment code, and the value is an array of QiAddressInfo objects. These addresses are
     * derived from the receiver's payment code and are used only for sending funds. They are not part of the set of
     * addresses that this wallet can control or spend from. This map is used to keep track of addresses generated for
     * each payment channel to ensure proper address rotation and avoid address reuse when sending funds.
     * @private
     * @type {Map<string, QiAddressInfo[]>}
     */
    private _paymentCodeSendAddressMap;
    /**
     * @ignore
     * @param {HDNodeWallet} root - The root HDNodeWallet.
     * @param {Provider} [provider] - The provider (optional).
     */
    constructor(guard: any, root: HDNodeWallet, provider?: Provider);
    /**
     * Gets the payment codes for all open channels.
     *
     * @returns {string[]} The payment codes for all open channels.
     */
    get openChannels(): string[];
    /**
     * Sets the address use checker. The provided callback function should accept an address as input and return a
     * boolean indicating whether the address is in use. If the callback returns true, the address is considered used
     * and if it returns false, the address is considered unused.
     *
     * @param {AddressUsageCallback} checker - The address use checker.
     */
    setAddressUseChecker(checker: AddressUsageCallback): void;
    /**
     * Finds the last used index in an array of QiAddressInfo objects. If no index is found, returns -1.
     *
     * @param {QiAddressInfo[]} addresses - The array of QiAddressInfo objects.
     * @returns {number} The last used index.
     */
    protected _findLastUsedIndex(addresses: QiAddressInfo[] | undefined, account: number, zone: Zone): number;
    /**
     * Derives the next Qi BIP 44 address for the specified account and zone.
     *
     * @param {number} account - The account number.
     * @param {Zone} zone - The zone.
     * @param {boolean} isChange - Whether to derive a change address.
     * @returns {QiAddressInfo} The next Qi address information.
     */
    private _getNextQiAddress;
    private _createAndStoreQiAddressInfo;
    /**
     * Promise that resolves to the next address for the specified account and zone.
     *
     * @param {number} account - The account number.
     * @param {Zone} zone - The zone.
     * @returns {Promise<QiAddressInfo>} The next Qi address information.
     */
    getNextAddress(account: number, zone: Zone): Promise<QiAddressInfo>;
    /**
     * Synchronously retrieves the next address for the specified account and zone.
     *
     * @param {number} account - The account number.
     * @param {Zone} zone - The zone.
     * @returns {QiAddressInfo} The next Qi address information.
     */
    getNextAddressSync(account: number, zone: Zone): QiAddressInfo;
    /**
     * Promise that resolves to the next change address for the specified account and zone.
     *
     * @param {number} account - The index of the account for which to retrieve the next change address.
     * @param {Zone} zone - The zone in which to retrieve the next change address.
     * @returns {Promise<NeuteredAddressInfo>} The next change neutered address information.
     */
    getNextChangeAddress(account: number, zone: Zone): Promise<QiAddressInfo>;
    /**
     * Synchronously retrieves the next change address for the specified account and zone.
     *
     * @param {number} account - The index of the account for which to retrieve the next change address.
     * @param {Zone} zone - The zone in which to retrieve the next change address.
     * @returns {NeuteredAddressInfo} The next change neutered address information.
     */
    getNextChangeAddressSync(account: number, zone: Zone): QiAddressInfo;
    /**
     * Imports an array of outpoints.
     *
     * @param {OutpointInfo[]} outpoints - The outpoints to import.
     */
    importOutpoints(outpoints: OutpointInfo[]): void;
    /**
     * Gets the outpoints for the specified zone.
     *
     * @param {Zone} zone - The zone.
     * @returns {OutpointInfo[]} The outpoints for the zone.
     */
    getOutpoints(zone: Zone): OutpointInfo[];
    /**
     * Signs a Qi transaction and returns the serialized transaction.
     *
     * @param {QiTransactionRequest} tx - The transaction to sign.
     * @returns {Promise<string>} The serialized transaction.
     * @throws {Error} If the UTXO transaction is invalid.
     */
    signTransaction(tx: QiTransactionRequest): Promise<string>;
    /**
     * Locates the address information for the given address, searching through standard addresses, change addresses,
     * and payment channel addresses.
     *
     * @param {string} address - The address to locate.
     * @returns {QiAddressInfo | null} The address info or null if not found.
     */
    locateAddressInfo(address: string): QiAddressInfo | null;
    /**
     * Gets the total balance for the specified zone, including locked UTXOs.
     *
     * @param {Zone} zone - The zone to get the balance for.
     * @param {number} [blockNumber] - The block number to use for the lock check.
     * @param {boolean} useAvailableOutpoints - Whether to use available outpoints to calculate the balance.
     * @returns {Promise<bigint>} The total balance for the zone.
     */
    getBalanceForZone(zone: Zone, blockNumber?: number, useAvailableOutpoints?: boolean): Promise<bigint>;
    /**
     * Gets the **spendable** balance for the specified zone by calling {@link getBalance} for all known addresses in the
     * zone.
     *
     * @param {Zone} zone - The zone to get the balance for.
     * @param {boolean} useAvailableOutpoints - Whether to use available outpoints to calculate the balance.
     * @returns {bigint} The spendable balance for the zone.
     */
    getSpendableBalanceForZone(zone: Zone, blockNumber?: number, useAvailableOutpoints?: boolean): Promise<bigint>;
    /**
     * Gets the **locked** balance for the specified zone by calling {@link getLockedBalance} for all known addresses in
     * the zone.
     *
     * @param {Zone} zone - The zone to get the balance for.
     * @param {boolean} useAvailableOutpoints - Whether to use available outpoints to calculate the balance.
     * @returns {bigint} The locked balance for the zone.
     */
    getLockedBalanceForZone(zone: Zone, blockNumber?: number, useAvailableOutpoints?: boolean): Promise<bigint>;
    /**
     * Gets the spendable balance for the specified zone by calling {@link getBalance} for all known addresses in the
     * zone.
     *
     * @param {Zone} zone - The zone to get the spendable balance for.
     * @returns {bigint} The spendable balance for the zone.
     */
    private _fetchSpendableBalanceForZone;
    /**
     * Gets the locked balance for the specified zone by calling {@link getLockedBalance} for all known addresses in the
     * zone.
     *
     * @param {Zone} zone - The zone to get the locked balance for.
     * @returns {bigint} The locked balance for the zone.
     */
    private _fetchLockedBalanceForZone;
    /**
     * Fetches the balance for the specified zone by calling the provided balance method for all known addresses in the
     * zone.
     *
     * @param {Zone} zone - The zone to get the balance for.
     * @param {Function} balanceMethod - The method to call to get the balance for each address.
     * @returns {Promise<bigint>} The balance for the zone.
     */
    private _fetchBalanceForZone;
    /**
     * Gets the spendable balance for the specified zone using the available outpoints.
     *
     * @param {Zone} zone - The zone to get the spendable balance for.
     * @param {number} [blockNumber] - The block number to use for the lock check.
     * @returns {bigint} The spendable balance for the zone.
     */
    private _calculateAvailableOutpointSpendableBalanceForZone;
    /**
     * Gets the locked balance for the specified zone using the available outpoints.
     *
     * @param {Zone} zone - The zone to get the locked balance for.
     * @param {number} [blockNumber] - The block number to use for the lock check.
     * @returns {bigint} The locked balance for the zone.
     */
    private _calculateAvailableOutpointLockedBalanceForZone;
    /**
     * Converts outpoints for a specific zone to UTXO format.
     *
     * @param {Zone} zone - The zone to filter outpoints for.
     * @returns {UTXO[]} An array of UTXO objects.
     */
    private outpointsToUTXOs;
    /**
     * Converts an amount of Qi to Quai and sends it to a specified Quai address.
     *
     * @param {string} destinationAddress - The Quai address to send the converted Quai to.
     * @param {bigint} amount - The amount of Qi to convert to Quai.
     * @returns {Promise<TransactionResponse>} A promise that resolves to the transaction response.
     * @throws {Error} If the destination address is invalid, the amount is zero, or the conversion fails.
     */
    convertToQuai(destinationAddress: string, amount: bigint): Promise<TransactionResponse>;
    /**
     * Sends a transaction to a specified recipient payment code in a specified zone.
     *
     * @param {string} recipientPaymentCode - The payment code of the recipient.
     * @param {bigint} amount - The amount of Qi to send.
     * @param {Zone} originZone - The zone where the transaction originates.
     * @param {Zone} destinationZone - The zone where the transaction is sent.
     * @returns {Promise<TransactionResponse>} A promise that resolves to the transaction response.
     * @throws {Error} If the payment code is invalid, the amount is zero, or the zones are invalid.
     */
    sendTransaction(recipientPaymentCode: string, amount: bigint, originZone: Zone, destinationZone: Zone): Promise<TransactionResponse>;
    /**
     * Aggregates all the available UTXOs for the specified zone and account. This method creates a new transaction with
     * all the available UTXOs as inputs and as fewest outputs as possible.
     *
     * @param {Zone} zone - The zone to aggregate the balance for.
     * @returns {Promise<TransactionResponse>} The transaction response.
     */
    aggregate(zone: Zone): Promise<TransactionResponse>;
    /**
     * Prepares and sends a transaction with the specified parameters.
     *
     * @private
     * @param {bigint} amount - The amount of Qi to send.
     * @param {Zone} originZone - The zone where the transaction originates.
     * @param {Function} getDestinationAddresses - A function that returns a promise resolving to an array of
     *   destination addresses.
     * @returns {Promise<TransactionResponse>} A promise that resolves to the transaction response.
     * @throws {Error} If provider is not set, insufficient balance, no available UTXOs, or insufficient spendable
     *   balance.
     */
    private prepareAndSendTransaction;
    /**
     * Prepares a transaction with the specified parameters.
     *
     * @private
     * @param {SelectedCoinsResult} selection - The selected coins result.
     * @param {string[]} inputPubKeys - The public keys of the inputs.
     * @param {string[]} sendAddresses - The addresses to send to.
     * @param {string[]} changeAddresses - The addresses to change to.
     * @param {number} chainId - The chain ID.
     * @returns {Promise<QiTransaction>} A promise that resolves to the prepared transaction.
     */
    private prepareTransaction;
    /**
     * Prepares a fee estimation transaction with the specified parameters.
     *
     * @private
     * @param {SelectedCoinsResult} selection - The selected coins result.
     * @param {string[]} inputPubKeys - The public keys of the inputs.
     * @param {string[]} sendAddresses - The addresses to send to.
     * @param {string[]} changeAddresses - The addresses to change to.
     * @returns {QiPerformActionTransaction} The prepared transaction.
     */
    private prepareFeeEstimationTransaction;
    /**
     * Gets a set of unused BIP44 addresses from the specified derivation path. It first checks if there are any unused
     * addresses available in the _addressesMap and uses those if possible. If there are not enough unused addresses, it
     * will generate new ones.
     *
     * @param amount - The number of addresses to get.
     * @param path - The derivation path to get addresses from.
     * @param zone - The zone to get addresses from.
     * @returns An array of addresses.
     */
    private _getUnusedBIP44Addresses;
    /**
     * Returns a schnorr signature for the given message and private key.
     *
     * @ignore
     * @param {TxInput} input - The transaction input.
     * @param {Uint8Array} hash - The hash of the message.
     * @returns {string} The schnorr signature.
     */
    private createSchnorrSignature;
    /**
     * Returns a MuSig signature for the given message and private keys corresponding to the input addresses.
     *
     * @ignore
     * @param {QiTransaction} tx - The Qi transaction.
     * @param {Uint8Array} hash - The hash of the message.
     * @returns {string} The MuSig signature.
     */
    private createMuSigSignature;
    /**
     * Retrieves the private key for a given transaction input.
     *
     * This method derives the private key for a transaction input by locating the address info and then deriving the
     * private key based on where the address info was found:
     *
     * - For BIP44 addresses (standard or change), it uses the HD wallet to derive the private key.
     * - For payment channel addresses (BIP47), it uses PaymentCodePrivate to derive the private key.
     *
     * @param {TxInput} input - The transaction input containing the public key.
     * @returns {string} The private key corresponding to the transaction input.
     * @throws {Error} If the input does not contain a public key or if the address information cannot be found.
     */
    private getPrivateKeyForTxInput;
    /**
     * Returns the private key for a given address. This method should be used with caution as it exposes the private
     * key to the user.
     *
     * @param {string} address - The address associated with the desired private key.
     * @returns {string} The private key.
     */
    getPrivateKey(address: string): string;
    /**
     * Scans the specified zone for addresses with unspent outputs. Starting at index 0, it will generate new addresses
     * until the gap limit is reached for external and change BIP44 addresses and payment channel addresses.
     *
     * @param {Zone} zone - The zone in which to scan for addresses.
     * @param {number} [account=0] - The index of the account to scan. Default is `0`
     * @returns {Promise<void>} A promise that resolves when the scan is complete.
     * @throws {Error} If the zone is invalid.
     */
    scan(zone: Zone, account?: number): Promise<void>;
    /**
     * Scans the specified zone for addresses with unspent outputs. Starting at the last address index, it will generate
     * new addresses until the gap limit is reached for external and change BIP44 addresses and payment channel
     * addresses.
     *
     * @param {Zone} zone - The zone in which to sync addresses.
     * @param {number} [account=0] - The index of the account to sync. Default is `0`
     * @returns {Promise<void>} A promise that resolves when the sync is complete.
     * @throws {Error} If the zone is invalid.
     */
    sync(zone: Zone, account?: number, onOutpointsCreated?: OutpointsCallback, onOutpointsDeleted?: OutpointsCallback): Promise<void>;
    /**
     * Internal method to scan the specified zone for addresses with unspent outputs. This method handles the actual
     * scanning logic, generating new addresses until the gap limit is reached for both gap and change addresses.
     *
     * @param {Zone} zone - The zone in which to scan for addresses.
     * @param {number} [account=0] - The index of the account to scan. Default is `0`
     * @param {Function} [onCreate] - A callback function that is called when a new address is created.
     * @param {Function} [onDelete] - A callback function that is called when an address is deleted.
     * @returns {Promise<void>} A promise that resolves when the scan is complete.
     * @throws {Error} If the provider is not set.
     */
    private _scan;
    /**
     * Scans for the next address in the specified zone and account, checking for associated outpoints, and updates the
     * address count and gap addresses accordingly.
     *
     * @param {Zone} zone - The zone in which the address is being scanned.
     * @param {number} account - The index of the account for which the address is being scanned.
     * @param {boolean} isChange - A flag indicating whether the address is a change address.
     * @returns {Promise<void>} A promise that resolves when the scan is complete.
     * @throws {Error} If an error occurs during the address scanning or outpoints retrieval process.
     */
    private _scanDerivationPath;
    /**
     * Queries the network node for the outpoints of the specified address.
     *
     * @ignore
     * @param {string} address - The address to query.
     * @returns {Promise<Outpoint[]>} The outpoints for the address.
     * @throws {Error} If the query fails.
     */
    private getOutpointsByAddress;
    /**
     * Checks if the specified address is used by querying the network node for the outpoints of the address. If the
     * address is used, the outpoints are imported into the wallet.
     *
     * @param {string} address - The address to check.
     * @returns {Promise<{ isUsed: boolean; outpoints: Outpoint[] }>} A promise that resolves to an object containing a
     *   boolean indicating whether the address is used and an array of outpoints.
     * @throws {Error} If the query fails.
     */
    private checkAddressUse;
    /**
     * Gets the addresses for the specified zone.
     *
     * @param {Zone} zone - The zone.
     * @returns {QiAddressInfo[]} The addresses for the zone.
     */
    getAddressesForZone(zone: Zone): QiAddressInfo[];
    /**
     * Gets the change addresses for the specified zone.
     *
     * @param {Zone} zone - The zone.
     * @returns {QiAddressInfo[]} The change addresses for the zone.
     */
    getChangeAddressesForZone(zone: Zone): QiAddressInfo[];
    /**
     * Gets the gap addresses for the specified zone.
     *
     * @param {Zone} zone - The zone.
     * @returns {QiAddressInfo[]} The gap addresses for the zone.
     */
    getGapAddressesForZone(zone: Zone): QiAddressInfo[];
    /**
     * Gets the gap change addresses for the specified zone.
     *
     * @param {Zone} zone - The zone.
     * @returns {QiAddressInfo[]} The gap change addresses for the zone.
     */
    getGapChangeAddressesForZone(zone: Zone): QiAddressInfo[];
    /**
     * Gets the payment channel addresses for the specified zone.
     *
     * @param {string} paymentCode - The payment code.
     * @param {Zone} zone - The zone.
     * @returns {QiAddressInfo[]} The payment channel addresses for the zone.
     */
    getPaymentChannelAddressesForZone(paymentCode: string, zone: Zone): QiAddressInfo[];
    /**
     * Gets the gap payment channel addresses for the specified payment code.
     *
     * @param {string} paymentCode - The payment code.
     * @returns {QiAddressInfo[]} The gap payment channel addresses for the payment code.
     */
    getGapPaymentChannelAddressesForZone(paymentCode: string, zone: Zone): QiAddressInfo[];
    /**
     * Signs a message using the private key associated with the given address.
     *
     * @param {string} address - The address for which the message is to be signed.
     * @param {string | Uint8Array} message - The message to be signed, either as a string or Uint8Array.
     * @returns {Promise<string>} A promise that resolves to the signature of the message in hexadecimal string format.
     * @throws {Error} If the address does not correspond to a valid HD node or if signing fails.
     */
    signMessage(address: string, message: string | Uint8Array): Promise<string>;
    /**
     * Serializes the HD wallet state into a format suitable for storage or transmission.
     *
     * @returns {SerializedQiHDWallet} An object representing the serialized state of the HD wallet, including
     *   outpoints, change addresses, gap addresses, and other inherited properties.
     */
    serialize(): SerializedQiHDWallet;
    /**
     * Deserializes a serialized QiHDWallet object and reconstructs the wallet instance.
     *
     * @param {SerializedQiHDWallet} serialized - The serialized object representing the state of a QiHDWallet.
     * @returns {Promise<QiHDWallet>} A promise that resolves to a reconstructed QiHDWallet instance.
     * @throws {Error} If the serialized data is invalid or if any addresses in the gap addresses or gap change
     *   addresses do not exist in the wallet.
     */
    static deserialize(serialized: SerializedQiHDWallet): Promise<QiHDWallet>;
    protected validateAddressDerivation(info: QiAddressInfo): void;
    protected validateExtendedProperties(info: QiAddressInfo): void;
    /**
     * Validates that the derivation path is either a BIP44 path or a valid payment code.
     *
     * @private
     * @param {string} path - The derivation path to validate
     * @param {boolean} isChange - Whether this is a change address
     * @throws {Error} If the path is invalid
     */
    private validateDerivationPath;
    /**
     * Validates an array of OutpointInfo objects. This method checks the validity of each OutpointInfo object by
     * performing the following validations:
     *
     * - Validates the zone using the `validateZone` method.
     * - Checks if the address exists in the wallet.
     * - Checks if the account (if provided) exists in the wallet.
     * - Validates the Outpoint by ensuring that `Txhash`, `Index`, and `Denomination` are not null.
     *
     * @ignore
     * @param {OutpointInfo[]} outpointInfo - An array of OutpointInfo objects to be validated.
     * @throws {Error} If any of the validations fail, an error is thrown with a descriptive message.
     */
    private validateOutpointInfo;
    private validateAddressAndAccount;
    /**
     * Creates a new BIP47 payment code for the specified account. The payment code is derived from the account's BIP32
     * root key.
     *
     * @param {number} account - The account index to derive the payment code from.
     * @returns {Promise<string>} A promise that resolves to the Base58-encoded BIP47 payment code.
     */
    getPaymentCode(account?: number): string;
    /**
     * Generates a BIP47 private payment code for the specified account. The payment code is created by combining the
     * account's public key and chain code.
     *
     * @private
     * @param {number} account - The account index for which to generate the private payment code.
     * @returns {Promise<PaymentCodePrivate>} A promise that resolves to the PaymentCodePrivate instance.
     */
    private _getPaymentCodePrivate;
    /**
     * Generates a payment address for sending funds to the specified receiver's BIP47 payment code. Uses Diffie-Hellman
     * key exchange to derive the address from the receiver's public key and sender's private key.
     *
     * @param {string} receiverPaymentCode - The Base58-encoded BIP47 payment code of the receiver.
     * @returns {Promise<string>} A promise that resolves to the payment address for sending funds.
     * @throws {Error} Throws an error if the payment code version is invalid.
     */
    getNextSendAddress(receiverPaymentCode: string, zone: Zone, account?: number): QiAddressInfo;
    /**
     * Generates a payment address for receiving funds from the specified sender's BIP47 payment code. Uses
     * Diffie-Hellman key exchange to derive the address from the sender's public key and receiver's private key.
     *
     * @param {string} senderPaymentCode - The Base58-encoded BIP47 payment code of the sender.
     * @returns {Promise<string>} A promise that resolves to the payment address for receiving funds.
     * @throws {Error} Throws an error if the payment code version is invalid.
     */
    getNextReceiveAddress(senderPaymentCode: string, zone: Zone, account?: number): QiAddressInfo;
    /**
     * Receives a payment code and stores it in the wallet for future use. If the payment code is already in the wallet,
     * it will be ignored.
     *
     * @param {string} paymentCode - The payment code to store.
     */
    openChannel(paymentCode: string): void;
    channelIsOpen(paymentCode: string): boolean;
    /**
     * Gets the address info for a given address.
     *
     * @param {string} address - The address.
     * @returns {QiAddressInfo | null} The address info or null if not found.
     */
    getAddressInfo(address: string): QiAddressInfo | null;
    /**
     * Gets the address info for a given address.
     *
     * @param {string} address - The address.
     * @returns {QiAddressInfo | null} The address info or null if not found.
     */
    getChangeAddressInfo(address: string): QiAddressInfo | null;
    /**
     * Imports a private key and adds it to the wallet.
     *
     * @param {string} privateKey - The private key to import (hex string)
     * @returns {Promise<QiAddressInfo>} The address information for the imported key
     * @throws {Error} If the private key is invalid or the address is already in use
     */
    importPrivateKey(privateKey: string): Promise<QiAddressInfo>;
    /**
     * Gets all addresses that were imported via private keys.
     *
     * @param {Zone} [zone] - Optional zone to filter addresses by
     * @returns {QiAddressInfo[]} Array of address info objects for imported addresses
     */
    getImportedAddresses(zone?: Zone): QiAddressInfo[];
    /**
     * Adds a new address to the wallet.
     *
     * @param {number} account - The account number.
     * @param {number} addressIndex - The address index.
     * @returns {QiAddressInfo} The address info for the new address.
     */
    addAddress(account: number, addressIndex: number): QiAddressInfo;
    /**
     * Adds a new change address to the wallet.
     *
     * @param {number} account - The account number.
     * @param {number} addressIndex - The address index.
     * @returns {QiAddressInfo} The address info for the new address.
     */
    addChangeAddress(account: number, addressIndex: number): QiAddressInfo;
    private _addAddress;
    /**
     * Gets the addresses for a given account.
     *
     * @param {number} account - The account number.
     * @returns {QiAddressInfo[]} The addresses for the account.
     */
    getAddressesForAccount(account: number): QiAddressInfo[];
}
export {};
//# sourceMappingURL=qi-hdwallet.d.ts.map