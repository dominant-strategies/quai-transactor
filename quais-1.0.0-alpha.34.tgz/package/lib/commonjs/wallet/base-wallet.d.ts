import { AbstractSigner } from '../signers/index.js';
import type { SigningKey } from '../crypto/index.js';
import type { TypedDataDomain, TypedDataField } from '../hash/index.js';
import type { Provider } from '../providers/index.js';
import { QuaiTransactionRequest } from '../providers/provider.js';
/**
 * The **BaseWallet** is a stream-lined implementation of a {@link AbstractSigner} that operates with a private key.
 *
 * It is preferred to use the {@link Wallet} class, as it offers additional functionality and simplifies loading a
 * variety of JSON formats, Mnemonic Phrases, etc.
 *
 * This class may be of use for those attempting to implement a minimal Signer.
 *
 * @category Wallet
 */
export declare class BaseWallet extends AbstractSigner {
    #private;
    /**
     * Creates a new BaseWallet for `privateKey`, optionally connected to `provider`.
     *
     * If `provider` is not specified, only offline methods can be used.
     *
     * @param {SigningKey} privateKey - The private key for the wallet.
     * @param {null | Provider} [provider] - The provider to connect to.
     */
    constructor(privateKey: SigningKey, provider?: null | Provider);
    /**
     * The address of this wallet.
     *
     * @type {string}
     * @readonly
     */
    get address(): string;
    /**
     * The {@link SigningKey | **SigningKey**} used for signing payloads.
     *
     * @type {SigningKey}
     * @readonly
     */
    get signingKey(): SigningKey;
    /**
     * The private key for this wallet.
     *
     * @type {string}
     * @readonly
     */
    get privateKey(): string;
    /**
     * Returns the address of this wallet.
     *
     * @param {string} [_zone] - The zone (optional).
     * @returns {Promise<string>} The wallet address.
     */
    getAddress(_zone?: string): Promise<string>;
    /**
     * Connects the wallet to a provider.
     *
     * @param {null | Provider} provider - The provider to connect to.
     * @returns {BaseWallet} The connected wallet.
     */
    connect(provider: null | Provider): BaseWallet;
    /**
     * Signs a transaction.
     *
     * @param {QuaiTransactionRequest} tx - The transaction request.
     * @returns {Promise<string>} The signed transaction.
     */
    signTransaction(tx: QuaiTransactionRequest): Promise<string>;
    /**
     * Signs a message.
     *
     * @async
     * @param {string | Uint8Array} message - The message to sign.
     * @returns {Promise<string>} The signed message.
     */
    signMessage(message: string | Uint8Array): Promise<string>;
    /**
     * Returns the signature for `message` signed with this wallet.
     *
     * @param {string | Uint8Array} message - The message to sign.
     * @returns {string} The serialized signature.
     */
    signMessageSync(message: string | Uint8Array): string;
    /**
     * Signs typed data.
     *
     * @async
     * @param {TypedDataDomain} domain - The domain of the typed data.
     * @param {Record<string, TypedDataField[]>} types - The types of the typed data.
     * @param {Record<string, any>} value - The value of the typed data.
     * @returns {Promise<string>} The signed typed data.
     */
    signTypedData(domain: TypedDataDomain, types: Record<string, Array<TypedDataField>>, value: Record<string, any>): Promise<string>;
}
//# sourceMappingURL=base-wallet.d.ts.map