/**
 * A constant for the ether symbol (normalized using NFKC).
 *
 * (**i.e.** `"\\u039e"`)
 *
 * @category Constants
 */
export declare const quaisymbol: string;
/**
 * A constant for the Quai Network equivalent of the [EIP-191](https://eips.ethereum.org/EIPS/eip-191) personal message
 * prefix.
 *
 * (**i.e.** `"\\x19Quai Signed Message:\\n"`)
 *
 * @category Constants
 */
export declare const MessagePrefix: string;
//# sourceMappingURL=strings.d.ts.map