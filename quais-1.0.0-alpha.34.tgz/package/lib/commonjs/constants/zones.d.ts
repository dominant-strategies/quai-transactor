/**
 * A zone is the lowest level shard within the Quai network hierarchy. Zones are the only shards in the network that
 * accept user transactions. The value is a hexadecimal string representing the encoded value of the zone. Read more
 * [here](https://github.com/quai-network/qips/blob/master/qip-0002.md).
 *
 * @category Constants
 */
export declare enum Zone {
    Cyprus1 = "0x00",
    Cyprus2 = "0x01",
    Cyprus3 = "0x02",
    Paxos1 = "0x10",
    Paxos2 = "0x11",
    Paxos3 = "0x12",
    Hydra1 = "0x20",
    Hydra2 = "0x21",
    Hydra3 = "0x22"
}
export declare enum Ledger {
    Quai = 0,
    Qi = 1
}
export declare const ZoneData: {
    name: string;
    nickname: string;
    shard: string;
    context: number;
    byte: string;
}[];
export declare function toZone(shard: string): Zone;
export declare function fromZone(zone: Zone, key: 'name' | 'nickname' | 'shard' | 'byte'): string;
//# sourceMappingURL=zones.d.ts.map