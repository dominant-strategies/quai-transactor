/**
 * A constant for the zero address.
 *
 * (**i.e.** `"0x0000000000000000000000000000000000000000"`)
 *
 * @category Constants
 */
export declare const ZeroAddress: string;
//# sourceMappingURL=addresses.d.ts.map