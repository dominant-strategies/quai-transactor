/**
 * A constant for the order N for the secp256k1 curve.
 *
 * (**i.e.** `0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n`)
 *
 * @category Constants
 */
export declare const N: bigint;
/**
 * A constant for the number of wei in a single ether.
 *
 * (**i.e.** `1000000000000000000n`)
 *
 * @category Constants
 */
export declare const WeiPerEther: bigint;
/**
 * A constant for the maximum value for a `uint256`.
 *
 * (**i.e.** `0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffn`)
 *
 * @category Constants
 */
export declare const MaxUint256: bigint;
/**
 * A constant for the minimum value for an `int256`.
 *
 * (**i.e.** `-8000000000000000000000000000000000000000000000000000000000000000n`)
 *
 * @category Constants
 */
export declare const MinInt256: bigint;
/**
 * A constant for the maximum value for an `int256`.
 *
 * (**i.e.** `0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffn`)
 *
 * @category Constants
 */
export declare const MaxInt256: bigint;
//# sourceMappingURL=numbers.d.ts.map