/**
 * A shard represents a chain within the Quai network hierarchy. A shard refer to the Prime chain, a region under the
 * Prime chain, or a Zone within a region. The value is a hexadecimal string representing the encoded value of the
 * shard. Read more [here](https://github.com/quai-network/qips/blob/master/qip-0002.md).
 *
 * @category Constants
 */
export declare enum Shard {
    Cyprus = "0x0",
    Cyprus1 = "0x00",
    Cyprus2 = "0x01",
    Cyprus3 = "0x02",
    Paxos = "0x1",
    Paxos1 = "0x10",
    Paxos2 = "0x11",
    Paxos3 = "0x12",
    Hydra = "0x2",
    Hydra1 = "0x20",
    Hydra2 = "0x21",
    Hydra3 = "0x22",
    Prime = "0x"
}
/**
 * Constant data that defines each shard within the network.
 *
 * @category Constants
 */
export declare const ShardData: {
    name: string;
    nickname: string;
    shard: string;
    context: number;
    byte: string;
}[];
export declare function toShard(shard: string): Shard;
export declare function fromShard(shard: Shard, key: 'name' | 'nickname' | 'shard' | 'byte'): string;
//# sourceMappingURL=shards.d.ts.map