/**
 * When sending values to or receiving values from a [Contract](../classes/Contract), the data is generally encoded
 * using the [ABI
 * Specification](https://docs.soliditylang.org/en/v0.8.19/abi-spec.html#formal-specification-of-the-encoding).
 *
 * The AbiCoder provides a utility to encode values to ABI data and decode values from ABI data.
 *
 * Most of the time, developers should favor the [Contract](../classes/Contract) class, which further abstracts the
 * finer details of ABI data.
 *
 * @category Application Binary Interface
 */
import { Result } from './coders/abstract-coder.js';
import { ParamType } from './fragments.js';
import type { BytesLike, CallExceptionAction, CallExceptionError } from '../utils/index.js';
/**
 * The **AbiCoder** is a low-level class responsible for encoding JavaScript values into binary data and decoding binary
 * data into JavaScript values.
 *
 * @category Application Binary Interface
 */
export declare class AbiCoder {
    #private;
    /**
     * Get the default values for the given types. For example, a `uint` is by default `0` and `bool` is by default
     * `false`.
     *
     * @param {(string | ParamType)[]} types - Array of parameter types to get default values for.
     * @returns {Result} The default values corresponding to the given types.
     */
    getDefaultValue(types: ReadonlyArray<string | ParamType>): Result;
    /**
     * Encode the values as the specified types into ABI data.
     *
     * @param {(string | ParamType)[]} types - Array of parameter types.
     * @param {any[]} values - Array of values to encode.
     * @returns {string} The encoded data in hexadecimal format.
     */
    encode(types: ReadonlyArray<string | ParamType>, values: ReadonlyArray<any>): string;
    /**
     * Decode the ABI data as the types into values.
     *
     * If loose decoding is enabled, then strict padding is not enforced. Some older versions of Solidity incorrectly
     * padded event data emitted from `external` functions.
     *
     * @param {(string | ParamType)[]} types - Array of parameter types.
     * @param {BytesLike} data - The ABI data to decode.
     * @param {boolean} [loose=false] - Enable loose decoding. Default is `false`
     * @returns {Result} The decoded values.
     */
    decode(types: ReadonlyArray<string | ParamType>, data: BytesLike, loose?: boolean): Result;
    /**
     * Set the default maximum inflation factor.
     *
     * @ignore
     * @param {number} value - The new inflation factor.
     */
    static _setDefaultMaxInflation(value: number): void;
    /**
     * Returns the shared singleton instance of a default {@link AbiCoder | **AbiCoder**}.
     *
     * On the first call, the instance is created internally.
     *
     * @returns {AbiCoder} The default ABI coder instance.
     */
    static defaultAbiCoder(): AbiCoder;
    /**
     * Returns a quais-compatible {@link CallExceptionError | **CallExceptionError**} for the given result data.
     *
     * @param {CallExceptionAction} action - The action that triggered the exception.
     * @param {Object} tx - The transaction information.
     * @param {BytesLike | null} data - The data associated with the call exception.
     * @returns {CallExceptionError} The corresponding call exception error.
     */
    static getBuiltinCallException(action: CallExceptionAction, tx: {
        to?: null | string;
        from?: null | string;
        data?: string;
    }, data: null | BytesLike): CallExceptionError;
}
//# sourceMappingURL=abi-coder.d.ts.map