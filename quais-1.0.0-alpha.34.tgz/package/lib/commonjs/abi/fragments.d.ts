/**
 * A fragment is a single item from an ABI, which may represent any of:
 *
 * - {@link FunctionFragment | Functions}
 * - {@link EventFragment | Events}
 * - {@link ConstructorFragment | Constructors}
 * - Custom {@link ErrorFragment | Errors}
 * - {@link FallbackFragment | Fallback or Recieve} functions
 *
 * @category Application Binary Interface
 */
/**
 * A Type description in a [JSON ABI format](https://docs.soliditylang.org/en/v0.8.19/abi-spec.html#json).
 *
 * @category Application Binary Interface
 */
export interface JsonFragmentType {
    /**
     * The parameter name.
     */
    readonly name?: string;
    /**
     * If the parameter is indexed.
     */
    readonly indexed?: boolean;
    /**
     * The type of the parameter.
     */
    readonly type?: string;
    /**
     * The internal Solidity type.
     */
    readonly internalType?: string;
    /**
     * The components for a tuple.
     */
    readonly components?: ReadonlyArray<JsonFragmentType>;
}
/**
 * A fragment for a method, event or error in a [JSON ABI
 * format](https://docs.soliditylang.org/en/v0.8.19/abi-spec.html#json)
 *
 * @category Application Binary Interface
 */
export interface JsonFragment {
    /**
     * The name of the error, event, function, etc.
     */
    readonly name?: string;
    /**
     * The type of the fragment (e.g. `event`, `"function"`, etc.)
     */
    readonly type?: string;
    /**
     * If the event is anonymous.
     */
    readonly anonymous?: boolean;
    /**
     * If the function is payable.
     */
    readonly payable?: boolean;
    /**
     * If the function is constant.
     */
    readonly constant?: boolean;
    /**
     * The mutability state of the function.
     */
    readonly stateMutability?: string;
    /**
     * The input parameters.
     */
    readonly inputs?: ReadonlyArray<JsonFragmentType>;
    /**
     * The output parameters.
     */
    readonly outputs?: ReadonlyArray<JsonFragmentType>;
    /**
     * The gas limit to use when sending a transaction for this function.
     */
    readonly gas?: string;
}
/**
 * The format to serialize the output as.
 *
 * **`sighash`** - the bare formatting, used to compute the selector or topic hash; this format cannot be reversed (as
 * it discards `indexed`) so cannot by used to export an [Interface](../classes/Interface).
 *
 * **`minimal`** - Human-Readable ABI with minimal spacing and without names, so it is compact, but will result in
 * Result objects that cannot be accessed by name.
 *
 * **`full`** - Full Human-Readable ABI, with readable spacing and names intact; this is generally the recommended
 * format.
 *
 * **`json`** - The [ABI JSON Specification](https://docs.soliditylang.org/en/v0.8.19/abi-spec.html#json).
 *
 * @category Application Binary Interface
 */
export type FormatType = 'sighash' | 'minimal' | 'full' | 'json';
/**
 * When {@link ParamType.walk | **walking**} a {@link ParamType | **ParamType**}, this is called on each component.
 *
 * @category Application Binary Interface
 */
export type ParamTypeWalkFunc = (type: string, value: any) => any;
/**
 * When {@link ParamType.walkAsync | **walking asynchronously**} a {@link ParamType | **ParamType**}, this is called on
 * each component.
 *
 * @category Application Binary Interface
 */
export type ParamTypeWalkAsyncFunc = (type: string, value: any) => any | Promise<any>;
/**
 * Each input and output of a {@link Fragment | **Fragment**} is an Array of {@link ParamType | **ParamType**}.
 *
 * @category Application Binary Interface
 */
export declare class ParamType {
    #private;
    /**
     * The local name of the parameter (or `""` if unbound)
     */
    readonly name: string;
    /**
     * The fully qualified type (e.g. `"address"`, `"tuple(address)"`, `"uint256[3][]"`)
     */
    readonly type: string;
    /**
     * The base type (e.g. `"address"`, `"tuple"`, `"array"`)
     */
    readonly baseType: string;
    /**
     * True if the parameters is indexed.
     *
     * For non-indexable types this is `null`.
     */
    readonly indexed: null | boolean;
    /**
     * The components for the tuple.
     *
     * For non-tuple types this is `null`.
     */
    readonly components: null | ReadonlyArray<ParamType>;
    /**
     * The array length, or `-1` for dynamic-lengthed arrays.
     *
     * For non-array types this is `null`.
     */
    readonly arrayLength: null | number;
    /**
     * The type of each child in the array.
     *
     * For non-array types this is `null`.
     */
    readonly arrayChildren: null | ParamType;
    /**
     * @ignore
     */
    constructor(guard: any, name: string, type: string, baseType: string, indexed: null | boolean, components: null | ReadonlyArray<ParamType>, arrayLength: null | number, arrayChildren: null | ParamType);
    /**
     * Return a string representation of this type.
     *
     * For example,
     *
     * `sighash" => "(uint256,address)"`
     *
     * `"minimal" => "tuple(uint256,address) indexed"`
     *
     * `"full" => "tuple(uint256 foo, address bar) indexed baz"`
     *
     * @returns {string} The formatted type.
     */
    format(format?: FormatType): string;
    /**
     * This provides a type guard ensuring that {@link arrayChildren | **arrayChildren**} and
     * {@link arrayLength | **arrayLength**} are non-null.
     *
     * @returns {boolean} True if this is an Array type.
     */
    isArray(): this is ParamType & {
        arrayChildren: ParamType;
        arrayLength: number;
    };
    /**
     * This provides a type guard ensuring that {@link components | **components**} is non-null.
     *
     * @returns {boolean} True if this is a Tuple type.
     */
    isTuple(): this is ParamType & {
        components: ReadonlyArray<ParamType>;
    };
    /**
     * This provides a type guard ensuring that {@link indexed | **indexed**} is non-null.
     *
     * @returns {boolean} True if this is an Indexable type.
     */
    isIndexable(): this is ParamType & {
        indexed: boolean;
    };
    /**
     * Walks the **ParamType** with `value`, calling `process` on each type, destructing the `value` recursively.
     */
    walk(value: any, process: ParamTypeWalkFunc): any;
    /**
     * Walks the **ParamType** with `value`, asynchronously calling `process` on each type, destructing the `value`
     * recursively.
     *
     * This can be used to resolve ENS naes by walking and resolving each `"address"` type.
     */
    walkAsync(value: any, process: ParamTypeWalkAsyncFunc): Promise<any>;
    /**
     * Creates a new **ParamType** for `obj`.
     *
     * If `allowIndexed` then the `indexed` keyword is permitted, otherwise the `indexed` keyword will throw an error.
     */
    static from(obj: any, allowIndexed?: boolean): ParamType;
    /**
     * Returns true if `value` is a **ParamType**.
     */
    static isParamType(value: any): value is ParamType;
}
/**
 * The type of a {@link Fragment | **Fragment**}.
 *
 * @category Application Binary Interface
 */
export type FragmentType = 'constructor' | 'error' | 'event' | 'fallback' | 'function' | 'struct';
/**
 * An abstract class to represent An individual fragment from a parse ABI.
 *
 * @category Application Binary Interface
 */
export declare abstract class Fragment {
    /**
     * The type of the fragment.
     */
    readonly type: FragmentType;
    /**
     * The inputs for the fragment.
     */
    readonly inputs: ReadonlyArray<ParamType>;
    /**
     * @ignore
     */
    constructor(guard: any, type: FragmentType, inputs: ReadonlyArray<ParamType>);
    /**
     * Returns a string representation of this fragment as `format`.
     */
    abstract format(format?: FormatType): string;
    /**
     * Creates a new **Fragment** for `obj`, wich can be any supported ABI frgament type.
     */
    static from(obj: any): Fragment;
    /**
     * Returns true if `value` is a {@link ConstructorFragment | **ConstructorFragment**}.
     */
    static isConstructor(value: any): value is ConstructorFragment;
    /**
     * Returns true if `value` is an {@link ErrorFragment | **ErrorFragment**}.
     */
    static isError(value: any): value is ErrorFragment;
    /**
     * Returns true if `value` is an {@link EventFragment | **EventFragment**}.
     */
    static isEvent(value: any): value is EventFragment;
    /**
     * Returns true if `value` is a {@link FunctionFragment | **FunctionFragment**}.
     */
    static isFunction(value: any): value is FunctionFragment;
    /**
     * Returns true if `value` is a {@link StructFragment | **StructFragment**}.
     */
    static isStruct(value: any): value is StructFragment;
}
/**
 * An abstract class to represent An individual fragment which has a name from a parse ABI.
 *
 * @category Application Binary Interface
 */
export declare abstract class NamedFragment extends Fragment {
    /**
     * The name of the fragment.
     */
    readonly name: string;
    /**
     * @ignore
     */
    constructor(guard: any, type: FragmentType, name: string, inputs: ReadonlyArray<ParamType>);
}
/**
 * A Fragment which represents a _Custom Error_.
 *
 * @category Application Binary Interface
 */
export declare class ErrorFragment extends NamedFragment {
    /**
     * @ignore
     */
    constructor(guard: any, name: string, inputs: ReadonlyArray<ParamType>);
    /**
     * The Custom Error selector.
     */
    get selector(): string;
    /**
     * Returns a string representation of this fragment as `format`.
     */
    format(format?: FormatType): string;
    /**
     * Returns a new **ErrorFragment** for `obj`.
     */
    static from(obj: any): ErrorFragment;
    /**
     * Returns `true` and provides a type guard if `value` is an **ErrorFragment**.
     */
    static isFragment(value: any): value is ErrorFragment;
}
/**
 * A Fragment which represents an Event.
 *
 * @category Application Binary Interface
 */
export declare class EventFragment extends NamedFragment {
    /**
     * Whether this event is anonymous.
     */
    readonly anonymous: boolean;
    /**
     * @ignore
     */
    constructor(guard: any, name: string, inputs: ReadonlyArray<ParamType>, anonymous: boolean);
    /**
     * The Event topic hash.
     */
    get topicHash(): string;
    /**
     * Returns a string representation of this event as `format`.
     */
    format(format?: FormatType): string;
    /**
     * Return the topic hash for an event with `name` and `params`.
     */
    static getTopicHash(name: string, params?: Array<any>): string;
    /**
     * Returns a new **EventFragment** for `obj`.
     */
    static from(obj: any): EventFragment;
    /**
     * Returns `true` and provides a type guard if `value` is an **EventFragment**.
     */
    static isFragment(value: any): value is EventFragment;
}
/**
 * A Fragment which represents a constructor.
 *
 * @category Application Binary Interface
 */
export declare class ConstructorFragment extends Fragment {
    /**
     * Whether the constructor can receive an endowment.
     */
    readonly payable: boolean;
    /**
     * The recommended gas limit for deployment or `null`.
     */
    readonly gas: null | bigint;
    /**
     * @ignore
     */
    constructor(guard: any, type: FragmentType, inputs: ReadonlyArray<ParamType>, payable: boolean, gas: null | bigint);
    /**
     * Returns a string representation of this constructor as `format`.
     */
    format(format?: FormatType): string;
    /**
     * Returns a new **ConstructorFragment** for `obj`.
     */
    static from(obj: any): ConstructorFragment;
    /**
     * Returns `true` and provides a type guard if `value` is a **ConstructorFragment**.
     */
    static isFragment(value: any): value is ConstructorFragment;
}
/**
 * A Fragment which represents a method.
 *
 * @category Application Binary Interface
 */
export declare class FallbackFragment extends Fragment {
    /**
     * If the function can be sent value during invocation.
     */
    readonly payable: boolean;
    constructor(guard: any, inputs: ReadonlyArray<ParamType>, payable: boolean);
    /**
     * Returns a string representation of this fallback as `format`.
     */
    format(format?: FormatType): string;
    /**
     * Returns a new **FallbackFragment** for `obj`.
     */
    static from(obj: any): FallbackFragment;
    /**
     * Returns `true` and provides a type guard if `value` is a **FallbackFragment**.
     */
    static isFragment(value: any): value is FallbackFragment;
}
/**
 * A Fragment which represents a method.
 *
 * @category Application Binary Interface
 */
export declare class FunctionFragment extends NamedFragment {
    /**
     * If the function is constant (e.g. `pure` or `view` functions).
     */
    readonly constant: boolean;
    /**
     * The returned types for the result of calling this function.
     */
    readonly outputs: ReadonlyArray<ParamType>;
    /**
     * The state mutability (e.g. `payable`, `nonpayable`, `view` or `pure`)
     */
    readonly stateMutability: 'payable' | 'nonpayable' | 'view' | 'pure';
    /**
     * If the function can be sent value during invocation.
     */
    readonly payable: boolean;
    /**
     * The recommended gas limit to send when calling this function.
     */
    readonly gas: null | bigint;
    /**
     * @ignore
     */
    constructor(guard: any, name: string, stateMutability: 'payable' | 'nonpayable' | 'view' | 'pure', inputs: ReadonlyArray<ParamType>, outputs: ReadonlyArray<ParamType>, gas: null | bigint);
    /**
     * The Function selector.
     */
    get selector(): string;
    /**
     * Returns a string representation of this function as `format`.
     */
    format(format?: FormatType): string;
    /**
     * Return the selector for a function with `name` and `params`.
     */
    static getSelector(name: string, params?: Array<any>): string;
    /**
     * Returns a new **FunctionFragment** for `obj`.
     */
    static from(obj: any): FunctionFragment;
    /**
     * Returns `true` and provides a type guard if `value` is a **FunctionFragment**.
     */
    static isFragment(value: any): value is FunctionFragment;
}
/**
 * A Fragment which represents a structure.
 *
 * @category Application Binary Interface
 */
export declare class StructFragment extends NamedFragment {
    /**
     * @ignore
     */
    constructor(guard: any, name: string, inputs: ReadonlyArray<ParamType>);
    /**
     * Returns a string representation of this struct as `format`.
     */
    format(): string;
    /**
     * Returns a new **StructFragment** for `obj`.
     */
    static from(obj: any): StructFragment;
    /**
     * Returns `true` and provides a type guard if `value` is a **StructFragment**.
     */
    static isFragment(value: any): value is FunctionFragment;
}
//# sourceMappingURL=fragments.d.ts.map