import { Ledger, Zone } from '../constants/zones.js';
import { NodeLocation } from '../providers/provider.js';
/**
 * Retrieves the shard information for a given address based on its byte prefix. The function parses the address to
 * extract its byte prefix, then filters the ShardData to find a matching shard entry. If no matching shard is found, it
 * returns null.
 *
 * @category Utils
 * @param {string} address - The blockchain address to be analyzed. The address should start with "0x" followed by the
 *   hexadecimal representation.
 * @returns {Object | null} An object containing the shard information, or null if no
 */
export declare function getZoneForAddress(address: string): Zone | null;
type AddressDetails = {
    zone: Zone;
    ledger: Ledger;
};
/**
 * Extracts both zone and UTXO information from a given blockchain address. This function first determines the address's
 * zone by its byte prefix, then checks the 9th bit of the address to ascertain if it's a UTXO or non-UTXO address.
 *
 * @category Utils
 * @param {string} address - The blockchain address to be analyzed, expected to start with "0x" followed by its
 *   hexadecimal representation.
 * @returns {Object | null} An object containing the zone and UTXO information, or null if no address is found.
 */
export declare function getAddressDetails(address: string): AddressDetails | null;
/**
 * Determines the transaction type based on the sender and recipient addresses. The function checks if both addresses
 * are UTXO addresses, in which case it returns 2. If only the sender address is a UTXO address, it returns 1.
 * Otherwise, it returns 0.
 *
 * @category Utils
 * @param {string | null} from - The sender address. If null, the function returns 0.
 * @param {string | null} to - The recipient address. If null, the function returns 0.
 * @returns {number} The transaction type based on the addresses.
 */
export declare function getTxType(from: string | null, to: string | null): number;
/**
 * Location of a chain within the Quai hierarchy
 *
 * Prime = [] region[0] = [0] zone[1,2] = [1, 2]
 *
 * @param shard - The shard to get the location for
 * @returns The location of the chain within the Quai hierarchy
 */
export declare function getNodeLocationFromZone(zone: Zone): NodeLocation;
export declare function getZoneFromNodeLocation(location: NodeLocation): Zone;
export {};
//# sourceMappingURL=shards.d.ts.map