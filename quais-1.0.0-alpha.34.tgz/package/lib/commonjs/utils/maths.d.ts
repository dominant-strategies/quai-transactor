import type { BytesLike } from './data.js';
/**
 * Any type that can be used where a numeric value is needed.
 *
 * @category Utils
 */
export type Numeric = number | bigint;
/**
 * Any type that can be used where a big number is needed.
 *
 * @category Utils
 */
export type BigNumberish = string | Numeric;
/**
 * Convert `value` from a twos-compliment representation of `width` bits to its value.
 *
 * If the highest bit is `1`, the result will be negative.
 *
 * @category Utils
 * @param {BigNumberish} _value - The value to convert.
 * @param {Numeric} _width - The width of the value in bits.
 * @returns {bigint} The value.
 * @throws {Error} If the value is too large for the width.
 */
export declare function fromTwos(_value: BigNumberish, _width: Numeric): bigint;
/**
 * Convert `value` to a twos-compliment representation of `width` bits.
 *
 * The result will always be positive.
 *
 * @category Utils
 * @param {BigNumberish} _value - The value to convert.
 * @param {Numeric} _width - The width of the value in bits.
 * @returns {bigint} The value.
 * @throws {Error} If the value is too large for the width.
 */
export declare function toTwos(_value: BigNumberish, _width: Numeric): bigint;
/**
 * Mask `value` with a bitmask of `bits` ones.
 *
 * @category Utils
 * @param {BigNumberish} _value - The value to mask.
 * @param {Numeric} _bits - The number of bits to mask.
 * @returns {bigint} The masked value.
 */
export declare function mask(_value: BigNumberish, _bits: Numeric): bigint;
/**
 * Gets a BigInt from `value`. If it is an invalid value for a BigInt, then an ArgumentError will be thrown for `name`.
 *
 * @category Utils
 * @param {BigNumberish} value - The value to convert.
 * @param {string} name - The name of the value.
 * @returns {bigint} The value.
 */
export declare function getBigInt(value: BigNumberish, name?: string): bigint;
/**
 * Returns absolute value of bigint `value`.
 *
 * @category Utils
 * @param {BigNumberish} value - The value to convert.
 * @returns {bigint} The absolute value.
 */
export declare function bigIntAbs(value: BigNumberish): bigint;
/**
 * Returns `value` as a bigint, validating it is valid as a bigint value and that it is positive.
 *
 * @category Utils
 * @param {BigNumberish} value - The value to convert.
 * @param {string} name - The name of the value.
 * @returns {bigint} The value.
 * @throws {Error} If the value is negative.
 */
export declare function getUint(value: BigNumberish, name?: string): bigint;
/**
 * Converts `value` to a BigInt. If `value` is a Uint8Array, it is treated as Big Endian data.
 *
 * @category Utils
 * @param {BigNumberish | Uint8Array} value - The value to convert.
 * @returns {bigint} The value.
 */
export declare function toBigInt(value: BigNumberish | Uint8Array): bigint;
/**
 * Gets a number from `value`. If it is an invalid value for a number, then an ArgumentError will be thrown for `name`.
 *
 * @category Utils
 * @param {BigNumberish} value - The value to convert.
 * @param {string} name - The name of the value.
 * @returns {number} The value.
 * @throws {Error} If the value is invalid.
 * @throws {Error} If the value is too large.
 */
export declare function getNumber(value: BigNumberish, name?: string): number;
/**
 * Converts `value` to a number. If `value` is a Uint8Array, it is treated as Big Endian data. Throws if the value is
 * not safe.
 *
 * @category Utils
 * @param {BigNumberish | Uint8Array} value - The value to convert.
 * @returns {number} The value.
 * @throws {Error} If the value is not safe to convert to a number.
 */
export declare function toNumber(value: BigNumberish | Uint8Array): number;
/**
 * Converts `value` to a Big Endian hexstring, optionally padded to `width` bytes.
 *
 * @category Utils
 * @param {BigNumberish} _value - The value to convert.
 * @param {Numeric} _width - The width of the value in bytes.
 * @returns {string} The hexstring.
 * @throws {Error} If the value exceeds the width.
 */
export declare function toBeHex(_value: BigNumberish, _width?: Numeric): string;
/**
 * Converts `value` to a Big Endian Uint8Array.
 *
 * @category Utils
 * @param {BigNumberish} _value - The value to convert.
 * @returns {Uint8Array} The value.
 */
export declare function toBeArray(_value: BigNumberish): Uint8Array;
/**
 * Returns a `HexString` for `value` safe to use as a Quantity.
 *
 * A Quantity does not have and leading 0 values unless the value is the literal value `0x0`. This is most commonly used
 * for JSSON-RPC numeric values.
 *
 * @category Utils
 * @param {BigNumberish | Uint8Array} value - The value to convert.
 * @returns {string} The quantity.
 */
export declare function toQuantity(value: BytesLike | BigNumberish): string;
//# sourceMappingURL=maths.d.ts.map