import type { BigNumberish, Numeric } from './index.js';
/**
 * Converts `value` into a decimal string, assuming `unit` decimal places. The `unit` may be the number of decimal
 * places or the name of a unit (e.g. `"gwei"` for 9 decimal places).
 *
 * @category Utils
 * @param {BigNumberish} value - The value to convert.
 * @param {string | Numeric} [unit=18] - The unit to convert to. Default is `18`
 * @returns {string} The converted value.
 * @throws {Error} If the unit is invalid.
 */
export declare function formatUnits(value: BigNumberish, unit?: string | Numeric): string;
/**
 * Converts the decimal string `value` to a BigInt, assuming `unit` decimal places. The `unit` may the number of decimal
 * places or the name of a unit (e.g. `"gwei"` for 9 decimal places).
 *
 * @category Utils
 * @param {string} value - The value to convert.
 * @param {string | Numeric} [unit=18] - The unit to convert from. Default is `18`
 * @returns {bigint} The converted value.
 * @throws {Error} If the unit is invalid.
 * @throws {Error} If the value is not a string.
 */
export declare function parseUnits(value: string, unit?: string | Numeric): bigint;
/**
 * Converts `value` into a decimal string sing 18 decimal places.
 *
 * @category Utils
 * @param {BigNumberish} wei - The value to convert.
 * @returns {string} The converted value.
 */
export declare function formatQuai(wei: BigNumberish): string;
/**
 * Converts `value` into a decimal string using 3 decimal places.
 *
 * @category Utils
 * @param {BigNumberish} value - The value to convert.
 * @returns {string} The converted value.
 */
export declare function formatQi(value: BigNumberish): string;
/**
 * Converts the decimal string `quai` to a BigInt, using 18 decimal places.
 *
 * @category Utils
 * @param {string} ether - The value to convert.
 * @returns {bigint} The converted value.
 */
export declare function parseQuai(ether: string): bigint;
/**
 * Converts `value` into a decimal string using 3 decimal places.
 *
 * @category Utils
 * @param {string} value - The value to convert.
 * @returns {bigint} The converted value.
 */
export declare function parseQi(value: string): bigint;
//# sourceMappingURL=units.d.ts.map