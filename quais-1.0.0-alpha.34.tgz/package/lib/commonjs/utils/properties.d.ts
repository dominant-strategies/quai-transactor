/**
 * Property helper functions.
 */
/**
 * Resolves to a new object that is a copy of `value`, but with all values resolved.
 *
 * @category Utils
 * @param {Object} value - The object to resolve.
 * @returns {Promise<Object>} The resolved object.
 */
export declare function resolveProperties<T>(value: {
    [P in keyof T]: T[P] | Promise<T[P]>;
}): Promise<T>;
export declare function getStatic<T>(ctor: any, key: string): T | null;
/**
 * Assigns the `values` to `target` as read-only values.
 *
 * It `types` is specified, the values are checked.
 *
 * @category Utils
 * @param {Object} target - The target object to assign to.
 * @param {Object} values - The values to assign.
 * @param {Object} types - The types to check.
 */
export declare function defineProperties<T>(target: T, values: {
    [K in keyof T]?: T[K];
}, types?: {
    [K in keyof T]?: string;
}): void;
//# sourceMappingURL=properties.d.ts.map