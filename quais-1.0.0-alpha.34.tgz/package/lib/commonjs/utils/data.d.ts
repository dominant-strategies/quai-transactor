/**
 * A {@link HexString | **HexString**} whose length is even, which ensures it is a valid representation of binary data.
 *
 * @category Utils
 */
export type DataHexString = string;
/**
 * A string which is prefixed with `0x` and followed by any number of case-agnostic hexadecimal characters.
 *
 * It must match the regular expression `/0x[0-9A-Fa-f]*\/`.
 *
 * @category Utils
 */
export type HexString = string;
/**
 * An object that can be used to represent binary data.
 *
 * @category Utils
 */
export type BytesLike = DataHexString | Uint8Array;
/**
 * Get a typed Uint8Array for `value`. If already a Uint8Array the original `value` is returned; if a copy is required
 * use {@link getBytesCopy | **getBytesCopy**}.
 *
 * @category Utils
 * @param {BytesLike} value - The value to convert to a Uint8Array.
 * @param {string} [name] - The name of the value for error context.
 * @returns {Uint8Array} The typed Uint8Array.
 */
export declare function getBytes(value: BytesLike, name?: string): Uint8Array;
/**
 * Get a typed Uint8Array for `value`, creating a copy if necessary to prevent any modifications of the returned value
 * from being reflected elsewhere.
 *
 * @category Utils
 * @param {BytesLike} value - The value to convert to a Uint8Array.
 * @param {string} [name] - The name of the value for error context.
 * @returns {Uint8Array} The typed Uint8Array.
 */
export declare function getBytesCopy(value: BytesLike, name?: string): Uint8Array;
/**
 * Returns true if `value` is a valid {@link HexString | **HexString**}.
 *
 * If `length` is `true` or a number, it also checks that `value` is a valid {@link DataHexString | **DataHexString**} of
 * `length` (if a number) bytes of data (e.g. `0x1234` is 2 bytes).
 *
 * @category Utils
 * @param {any} value - The value to check.
 * @param {number | boolean} [length] - The expected length of the data.
 * @returns {boolean} True if the value is a valid {@link HexString | **HexString**}.
 */
export declare function isHexString(value: any, length?: number | boolean): value is `0x${string}`;
/**
 * Returns true if `value` is a valid representation of arbitrary data (i.e. a valid
 * {@link DataHexString | **DataHexString**} or a Uint8Array).
 *
 * @category Utils
 * @param {any} value - The value to check.
 * @returns {boolean} True if the value is a valid {@link DataHexString | **DataHexString**}.
 */
export declare function isBytesLike(value: any): value is BytesLike;
/**
 * Returns a {@link DataHexString | **DataHexString**} representation of `data`.
 *
 * @category Utils
 * @param {BytesLike} data - The data to convert to a hex string.
 * @returns {string} The hex string.
 */
export declare function hexlify(data: BytesLike): string;
/**
 * Returns a {@link DataHexString | **DataHexString** } by concatenating all values within `data`.
 *
 * @category Utils
 * @param {ReadonlyArray<BytesLike>} datas - The data to concatenate.
 * @returns {string} The concatenated data.
 */
export declare function concat(datas: ReadonlyArray<BytesLike>): string;
/**
 * Returns the length of `data`, in bytes.
 *
 * @category Utils
 * @param {BytesLike} data - The data to get the length of.
 * @returns {number} The length of the data.
 */
export declare function dataLength(data: BytesLike): number;
/**
 * Returns a {@link DataHexString | **DataHexString** } by slicing `data` from the `start` offset to the `end` offset.
 *
 * By default `start` is 0 and `end` is the length of `data`.
 *
 * @category Utils
 * @param {BytesLike} data - The data to slice.
 * @param {number} [start] - The start offset.
 * @param {number} [end] - The end offset.
 * @returns {string} The sliced data.
 * @throws {Error} If the end offset is beyond the data bounds.
 */
export declare function dataSlice(data: BytesLike, start?: number, end?: number): string;
/**
 * Return the {@link DataHexString | **DataHexString**} result by stripping all **leading** zero bytes from `data`.
 *
 * @category Utils
 * @param {BytesLike} data - The data to strip.
 * @returns {string} The stripped data.
 */
export declare function stripZerosLeft(data: BytesLike): string;
/**
 * Return the {@link DataHexString | **DataHexString**} of `data` padded on the **left** to `length` bytes.
 *
 * If `data` already exceeds `length`, a [BufferOverrunError](../interfaces/BufferOverrunError) is thrown.
 *
 * This pads data the same as **values** are in Solidity (e.g. `uint128`).
 *
 * @category Utils
 * @param {BytesLike} data - The data to pad.
 * @param {number} length - The length to pad to.
 * @returns {string} The padded data.
 */
export declare function zeroPadValue(data: BytesLike, length: number): string;
/**
 * Return the {@link DataHexString | **DataHexString**} of `data` padded on the **right** to `length` bytes.
 *
 * If `data` already exceeds %%length%%, a [BufferOverrunError](../interfaces/BufferOverrunError) is thrown.
 *
 * This pads data the same as **bytes** are in Solidity (e.g. `bytes16`).
 *
 * @category Utils
 * @param {BytesLike} data - The data to pad.
 * @param {number} length - The length to pad to.
 * @returns {string} The padded data.
 */
export declare function zeroPadBytes(data: BytesLike, length: number): string;
/**
 * XOR two Uint8Array values.
 *
 * @category Utils
 * @param {Uint8Array} a - The first Uint8Array.
 * @param {Uint8Array} b - The second Uint8Array.
 * @returns {Uint8Array} The XOR result.
 */
export declare function xorUint8Arrays(a: Uint8Array, b: Uint8Array): Uint8Array;
//# sourceMappingURL=data.d.ts.map