import type { BytesLike } from './index.js';
/**
 * Returns the version 4 [UUID](https://www.ietf.org/rfc/rfc4122.txt) for the `randomBytes`.
 *
 * @category Utils
 * @param {BytesLike} randomBytes - The random bytes to use.
 * @returns {string} The UUID.
 */
export declare function uuidV4(randomBytes: BytesLike): string;
//# sourceMappingURL=uuid.d.ts.map