import type { BigNumberish, BytesLike, Numeric } from './index.js';
/**
 * Returns a new FixedFormat for `value`.
 *
 * If `value` is specified as a `number`, the bit-width is 128 bits and `value` is used for the `decimals`.
 *
 * A string `value` may begin with `fixed` or `ufixed` for signed and unsigned respectfully. If no other properties are
 * specified, the bit-width is 128-bits with 18 decimals.
 *
 * To specify the bit-width and demicals, append them separated by an `"x"` to the `value`.
 *
 * For example, `ufixed128x18` describes an unsigned, 128-bit wide format with 18 decimals.
 *
 * If `value` is an other object, its properties for `signed`, `width` and `decimals` are checked.
 *
 * @category Utils
 */
export type FixedFormat = number | string | {
    signed?: boolean;
    width?: number;
    decimals?: number;
};
/**
 * A FixedNumber represents a value over its {@link FixedFormat | **FixedFormat**} arithmetic field.
 *
 * A FixedNumber can be used to perform math, losslessly, on values which have decmial places.
 *
 * A FixedNumber has a fixed bit-width to store values in, and stores all values internally by multiplying the value by
 * 10 raised to the power of `decimals`.
 *
 * If operations are performed that cause a value to grow too high (close to positive infinity) or too low (close to
 * negative infinity), the value is said to overflow.
 *
 * For example, an 8-bit signed value, with 0 decimals may only be within the range `-128` to `127`; so `-128 - 1` will
 * overflow and become `127`. Likewise, `127 + 1` will overflow and become `-127`.
 *
 * Many operation have a normal and unsafe variant. The normal variant will throw a
 * [NumericFaultError](../interfaces/NumericFaultError) on any overflow, while the unsafe variant will silently allow
 * overflow, corrupting its value value.
 *
 * If operations are performed that cause a value to become too small (close to zero), the value loses precison and is
 * said to underflow.
 *
 * For example, an value with 1 decimal place may store a number as small as `0.1`, but the value of `0.1 / 2` is
 * `0.05`, which cannot fit into 1 decimal place, so underflow occurs which means precision is lost and the value
 * becomes `0`.
 *
 * Some operations have a normal and signalling variant. The normal variant will silently ignore underflow, while the
 * signalling variant will thow a [NumericFaultError](../interfaces/NumericFaultError) on underflow.
 *
 * @category Utils
 */
export declare class FixedNumber {
    #private;
    /**
     * The specific fixed-point arithmetic field for this value.
     */
    readonly format: string;
    /**
     * This is a property so console.log shows a human-meaningful value.
     *
     * @ignore
     */
    readonly _value: string;
    /**
     * @ignore
     */
    constructor(guard: any, value: bigint, format: any);
    /**
     * If true, negative values are permitted, otherwise only positive values and zero are allowed.
     */
    get signed(): boolean;
    /**
     * The number of bits available to store the value.
     */
    get width(): number;
    /**
     * The number of decimal places in the fixed-point arithment field.
     */
    get decimals(): number;
    /**
     * The value as an integer, based on the smallest unit the {@link FixedNumber.decimals | **decimals**} allow.
     */
    get value(): bigint;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} with the result of `this` added to `other`, ignoring overflow.
     *
     * @param {FixedNumber} other - The value to add to `this`.
     * @returns {FixedNumber} The result of the addition.
     */
    addUnsafe(other: FixedNumber): FixedNumber;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} with the result of `this` added to `other`. A
     * [NumericFaultError](../interfaces/NumericFaultError) is thrown if overflow occurs.
     *
     * @param {FixedNumber} other - The value to add to `this`.
     * @returns {FixedNumber} The result of the addition.
     */
    add(other: FixedNumber): FixedNumber;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} with the result of `other` subtracted from `this`, ignoring
     * overflow.
     *
     * @param {FixedNumber} other - The value to subtract from `this`.
     * @returns {FixedNumber} The result of the subtraction.
     */
    subUnsafe(other: FixedNumber): FixedNumber;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} with the result of `other` subtracted from `this`. A
     * [NumericFaultError](../interfaces/NumericFaultError) is thrown if overflow occurs.
     *
     * @param {FixedNumber} other - The value to subtract from `this`.
     * @returns {FixedNumber} The result of the subtraction.
     */
    sub(other: FixedNumber): FixedNumber;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} with the result of `this` multiplied by `other`, ignoring
     * overflow and underflow (precision loss).
     *
     * @param {FixedNumber} other - The value to multiply `this` by.
     * @returns {FixedNumber} The result of the multiplication.
     */
    mulUnsafe(other: FixedNumber): FixedNumber;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} with the result of `this` multiplied by `other`. A
     * [NumericFaultError](../interfaces/NumericFaultError) is thrown if overflow occurs.
     *
     * @param {FixedNumber} other - The value to multiply `this` by.
     * @returns {FixedNumber} The result of the multiplication.
     */
    mul(other: FixedNumber): FixedNumber;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} with the result of `this` multiplied by `other`. A
     * [NumericFaultError](../interfaces/NumericFaultError) is thrown if overflow occurs or if underflow (precision
     * loss) occurs.
     *
     * @param {FixedNumber} other - The value to multiply `this` by.
     * @returns {FixedNumber} The result of the multiplication.
     * @throws {NumericFaultError} Thrown if overflow or underflow occurs.
     * @throws {NumericFaultError} Thrown if division by 0 occurs.
     */
    mulSignal(other: FixedNumber): FixedNumber;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} with the result of `this` divided by `other`, ignoring
     * underflow (precision loss). A [NumericFaultError](../interfaces/NumericFaultError) is thrown if overflow occurs.
     *
     * @param {FixedNumber} other - The value to divide `this` by.
     * @returns {FixedNumber} The result of the division.
     */
    divUnsafe(other: FixedNumber): FixedNumber;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} with the result of `this` divided by `other`, ignoring
     * underflow (precision loss). A [NumericFaultError](../interfaces/NumericFaultError) is thrown if overflow occurs.
     *
     * @param {FixedNumber} other - The value to divide `this` by.
     * @returns {FixedNumber} The result of the division.
     */
    div(other: FixedNumber): FixedNumber;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} with the result of `this` divided by `other`. A
     * [NumericFaultError](../interfaces/NumericFaultError) is thrown if underflow (precision loss) occurs.
     *
     * @param {FixedNumber} other - The value to divide `this` by.
     * @returns {FixedNumber} The result of the division.
     * @throws {NumericFaultError} Thrown if underflow occurs.
     */
    divSignal(other: FixedNumber): FixedNumber;
    /**
     * Returns a comparison result between `this` and `other`.
     *
     * This is suitable for use in sorting, where `-1` implies `this` is smaller, `1` implies `this` is larger and `0`
     * implies both are equal.
     *
     * @param {FixedNumber} other - The value to compare to `this`.
     * @returns {number} The comparison result.
     */
    cmp(other: FixedNumber): number;
    /**
     * Returns true if `other` is equal to `this`.
     *
     * @param {FixedNumber} other - The value to compare to `this`.
     * @returns {boolean} True if `other` is equal to `this`.
     */
    eq(other: FixedNumber): boolean;
    /**
     * Returns true if `other` is less than to `this`.
     *
     * @param {FixedNumber} other - The value to compare to `this`.
     * @returns {boolean} True if `other` is less than to `this`.
     */
    lt(other: FixedNumber): boolean;
    /**
     * Returns true if `other` is less than or equal to `this`.
     *
     * @param {FixedNumber} other - The value to compare to `this`.
     * @returns {boolean} True if `other` is less than or equal to `this`.
     */
    lte(other: FixedNumber): boolean;
    /**
     * Returns true if `other` is greater than to `this`.
     *
     * @param {FixedNumber} other - The value to compare to `this`.
     * @returns {boolean} True if `other` is greater than to `this`.
     */
    gt(other: FixedNumber): boolean;
    /**
     * Returns true if `other` is greater than or equal to `this`.
     *
     * @param {FixedNumber} other - The value to compare to `this`.
     * @returns {boolean} True if `other` is greater than or equal to `this`.
     */
    gte(other: FixedNumber): boolean;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} which is the largest **integer** that is less than or equal to
     * `this`.
     *
     * The decimal component of the result will always be `0`.
     *
     * @returns {FixedNumber} The floored value.
     */
    floor(): FixedNumber;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} which is the smallest **integer** that is greater than or
     * equal to `this`.
     *
     * The decimal component of the result will always be `0`.
     *
     * @returns {FixedNumber} The ceiling value.
     */
    ceiling(): FixedNumber;
    /**
     * Returns a new {@link FixedNumber | **FixedNumber**} with the decimal component rounded up on ties at `decimals`
     * places.
     *
     * @param {number} [decimals] - The number of decimal places to round to.
     * @returns {FixedNumber} The rounded value.
     */
    round(decimals?: number): FixedNumber;
    /**
     * Returns true if `this` is equal to `0`.
     *
     * @returns {boolean} True if `this` is equal to `0`.
     */
    isZero(): boolean;
    /**
     * Returns true if `this` is less than `0`.
     *
     * @returns {boolean} True if `this` is less than `0`.
     */
    isNegative(): boolean;
    /**
     * Returns the string representation of `this`.
     *
     * @returns {string} The string representation.
     */
    toString(): string;
    /**
     * Returns a float approximation.
     *
     * Due to IEEE 754 precission (or lack thereof), this function can only return an approximation and most values will
     * contain rounding errors.
     *
     * @returns {number} The float approximation.
     */
    toUnsafeFloat(): number;
    /**
     * Return a new {@link FixedNumber | **FixedNumber**} with the same value but has had its field set to `format`.
     *
     * This will throw if the value cannot fit into `format`.
     *
     * @param {FixedFormat} format - The new format for the value.
     */
    toFormat(format: FixedFormat): FixedNumber;
    /**
     * Creates a new {@link FixedNumber | **FixedNumber**} for `value` divided by `decimal` places with `format`.
     *
     * This will throw a [NumericFaultError](../interfaces/NumericFaultError) if `value` (once adjusted for `decimals`)
     * cannot fit in `format`, either due to overflow or underflow (precision loss).
     *
     * @param {BigNumberish} _value - The value to create a FixedNumber for.
     * @param {Numeric} [_decimals] - The number of decimal places in `value`.
     * @param {FixedFormat} [_format] - The format for the FixedNumber.
     * @returns {FixedNumber} The FixedNumber for `value`.
     */
    static fromValue(_value: BigNumberish, _decimals?: Numeric, _format?: FixedFormat): FixedNumber;
    /**
     * Creates a new {@link FixedNumber | **FixedNumber**} for `value` with `format`.
     *
     * This will throw a [NumericFaultError](../interfaces/NumericFaultError) if `value` cannot fit in `format`, either
     * due to overflow or underflow (precision loss).
     *
     * @param {BigNumberish} _value - The value to create a FixedNumber for.
     * @param {FixedFormat} [_format] - The format for the FixedNumber.
     * @returns {FixedNumber} The FixedNumber for `value`.
     */
    static fromString(_value: string, _format?: FixedFormat): FixedNumber;
    /**
     * Creates a new {@link FixedNumber | **FixedNumber**} with the big-endian representation `value` with `format`.
     *
     * This will throw a [NumericFaultError](../interfaces/NumericFaultError) if `value` cannot fit in `format` due to
     * overflow.
     *
     * @param {BytesLike} _value - The big-endian representation of the value.
     * @param {FixedFormat} [_format] - The format for the FixedNumber.
     * @returns {FixedNumber} The FixedNumber for `value`.
     */
    static fromBytes(_value: BytesLike, _format?: FixedFormat): FixedNumber;
}
//# sourceMappingURL=fixednumber.d.ts.map